/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "script/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 121);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function surroundByTryCatchFactory(func, funcName) {
    //返回函数e
    return function () {
        try {
            return func.apply(func, arguments);
        } catch (e) {
            if ("[object Error]" === Object.prototype.toString.apply(e)) {
                if ("AppServiceSdkKnownError" == e.type) throw e;
                Reporter.errorReport({
                    key: "appServiceSDKScriptError",
                    error: e,
                    extend: funcName
                });
            }
        }
    };
}

function anyTypeToString(data) {
    //把e转成string并返回一个对象
    var dataType = Object.prototype.toString.call(data).split(" ")[1].split("]")[0];
    if ("Array" == dataType || "Object" == dataType) {
        try {
            data = JSON.stringify(data);
        } catch (e) {
            e.type = "AppServiceSdkKnownError";
            throw e;
        }
    } else {
        data = "String" == dataType || "Number" == dataType || "Boolean" == dataType ? data.toString() : "Date" == dataType ? data.getTime().toString() : "Undefined" == dataType ? "undefined" : "Null" == dataType ? "null" : "";
    }
    return {
        data: data,
        dataType: dataType
    };
}

function stringToAnyType(data, type) {
    //把e解码回来，和前面a相对应

    return data = "String" == type ? data : "Array" == type || "Object" == type ? JSON.parse(data) : "Number" == type ? parseFloat(data) : "Boolean" == type ? "true" == data : "Date" == type ? new Date(parseInt(data)) : "Undefined" == type ? void 0 : "Null" == type ? null : "";
}

function getDataType(data) {
    //get data type
    return Object.prototype.toString.call(data).split(" ")[1].split("]")[0];
}

function isObject(e) {
    return "Object" === getDataType(e);
}

function paramCheck(params, paramTpl) {
    //比较e\t
    var result,
        name = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "parameter",
        tplTpye = getDataType(paramTpl),
        pType = getDataType(params);
    if (pType != tplTpye) return name + " should be " + tplTpye + " instead of " + pType + ";";
    switch (result = "", tplTpye) {
        case "Object":
            for (var i in paramTpl) {
                result += paramCheck(params[i], paramTpl[i], name + "." + i);
            }break;
        case "Array":
            if (params.length < paramTpl.length) return name + " should have at least " + paramTpl.length + " item;";
            for (var a = 0; a < paramTpl.length; ++a) {
                result += paramCheck(params[a], paramTpl[a], name + "[" + a + "]");
            }}
    return result;
}

function getRealRoute(pathname, url) {
    var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
    if (n && (url = addHTMLSuffix(url)), 0 === url.indexOf("/")) return url.substr(1);
    if (0 === url.indexOf("./")) return getRealRoute(pathname, url.substr(2), !1);
    var index,
        urlArrLength,
        urlArr = url.split("/");
    for (index = 0, urlArrLength = urlArr.length; index < urlArrLength && ".." === urlArr[index]; index++) {}
    urlArr.splice(0, index);
    var newUrl = urlArr.join("/"),
        pathArr = pathname.length > 0 ? pathname.split("/") : [];
    pathArr.splice(pathArr.length - index - 1, index + 1);
    var newPathArr = pathArr.concat(urlArr);
    return newPathArr.join("/");
}

function getPlatform() {
    //return platform
    return "devtools";
}

function urlEncodeFormData(data) {
    //把对象生成queryString
    var needEncode = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    if ("object" !== (typeof data === "undefined" ? "undefined" : _typeof(data))) return data;
    var tmpArr = [];
    for (var o in data) {
        if (data.hasOwnProperty(o)) {
            if (needEncode) {
                try {
                    tmpArr.push(encodeURIComponent(o) + "=" + encodeURIComponent(data[o]));
                } catch (t) {
                    tmpArr.push(o + "=" + data[o]);
                }
            } else tmpArr.push(o + "=" + data[o]);
        }
    }return tmpArr.join("&");
}

function addQueryStringToUrl(originalUrl, newParams) {
    //生成url t:param obj
    if ("string" == typeof originalUrl && "object" === (typeof newParams === "undefined" ? "undefined" : _typeof(newParams)) && Object.keys(newParams).length > 0) {
        var urlComponents = originalUrl.split("?"),
            host = urlComponents[0],
            oldParams = (urlComponents[1] || "").split("&").reduce(function (res, cur) {
            if ("string" == typeof cur && cur.length > 0) {
                var curArr = cur.split("="),
                    key = curArr[0],
                    value = curArr[1];
                res[key] = value;
            }
            return res;
        }, {}),
            refinedNewParams = Object.keys(newParams).reduce(function (res, cur) {
            "object" === _typeof(newParams[cur]) ? res[encodeURIComponent(cur)] = encodeURIComponent(JSON.stringify(newParams[cur])) : res[encodeURIComponent(cur)] = encodeURIComponent(newParams[cur]);
            return res;
        }, {});
        return host + "?" + urlEncodeFormData(assign(oldParams, refinedNewParams));
    }
    return originalUrl;
}

function validateUrl(url) {
    return (/^(http|https):\/\/.*/i.test(url)
    );
}

function assign() {
    //endext 对象合并
    for (var argLeng = arguments.length, args = Array(argLeng), n = 0; n < argLeng; n++) {
        args[n] = arguments[n];
    }
    return args.reduce(function (res, cur) {
        for (var n in cur) {
            res[n] = cur[n];
        }
        return res;
    }, {});
}

function encodeUrlQuery(url) {
    //把url中的参数encode
    if ("string" == typeof url) {
        var urlArr = url.split("?"),
            urlPath = urlArr[0],
            queryParams = (urlArr[1] || "").split("&").reduce(function (res, cur) {
            if ("string" == typeof cur && cur.length > 0) {
                var curArr = cur.split("="),
                    key = curArr[0],
                    value = curArr[1];
                res[key] = value;
            }
            return res;
        }, {}),
            urlQueryArr = [];
        for (var i in queryParams) {
            queryParams.hasOwnProperty(i) && urlQueryArr.push(i + "=" + encodeURIComponent(queryParams[i]));
        }
        return urlQueryArr.length > 0 ? urlPath + "?" + urlQueryArr.join("&") : url;
    }
    return url;
}

function addHTMLSuffix(url) {
    //给url加上。html的扩展名
    if ("string" != typeof url) throw new A("wd.redirectTo: invalid url:" + url);
    var urlArr = url.split("?");
    urlArr[0] += ".html";
    return "undefined" != typeof urlArr[1] ? urlArr[0] + "?" + urlArr[1] : urlArr[0];
}

function extend(target, obj) {
    //t合并到e对象
    for (var n in obj) {
        target[n] = obj[n];
    }return target;
}

function arrayBufferToBase64(buffer) {
    for (var res = "", arr = new Uint8Array(buffer), arrLeng = arr.byteLength, r = 0; r < arrLeng; r++) {
        res += String.fromCharCode(arr[r]);
    }
    return btoa(res);
}

function base64ToArrayBuffer(str) {
    for (var atobStr = atob(str), leng = atobStr.length, arr = new Uint8Array(leng), r = 0; r < leng; r++) {
        arr[r] = atobStr.charCodeAt(r);
    }return arr.buffer;
}

function blobToArrayBuffer(blobStr, callback) {
    //readAsArrayBuffer t:callback
    var fileReader = new FileReader();
    fileReader.onload = function () {
        callback(this.result);
    };
    fileReader.readAsArrayBuffer(blobStr);
}

function convertObjectValueToString(obj) {
    //把对象元素都转成字符串
    return Object.keys(obj).reduce(function (res, cur) {
        "string" == typeof obj[cur] ? res[cur] = obj[cur] : "number" == typeof obj[cur] ? res[cur] = obj[cur] + "" : res[cur] = Object.prototype.toString.apply(obj[cur]);
        return res;
    }, {});
}
function renameProperty(obj, oldName, newName) {
    isObject(obj) !== !1 && oldName != newName && obj.hasOwnProperty(oldName) && (obj[newName] = obj[oldName], delete obj[oldName]);
}

function toArray(arg) {
    // 把e转成array
    if (Array.isArray(arg)) {
        for (var t = 0, n = Array(arg.length); t < arg.length; t++) {
            n[t] = arg[t];
        }return n;
    }
    return Array.from(arg);
}

var words = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    btoa = btoa || function (str) {
    for (var curPosFlag, curCodeValue, text = String(str), res = "", i = 0, wordTpl = words; text.charAt(0 | i) || (wordTpl = "=", i % 1); res += wordTpl.charAt(63 & curPosFlag >> 8 - i % 1 * 8)) {
        curCodeValue = text.charCodeAt(i += .75);
        if (curCodeValue > 255) throw new Error('"btoa" failed');
        curPosFlag = curPosFlag << 8 | curCodeValue;
    }
    return res;
},
    atob = atob || function (str) {
    var text = String(str).replace(/=+$/, ""),
        res = "";
    if (text.length % 4 === 1) throw new Error('"atob" failed');
    for (var curFlage, curValue, i = 0, a = 0; curValue = text.charAt(a++); ~curValue && (curFlage = i % 4 ? 64 * curFlage + curValue : curValue, i++ % 4) ? res += String.fromCharCode(255 & curFlage >> (-2 * i & 6)) : 0) {
        curValue = words.indexOf(curValue);
    }return res;
};

var AppServiceSdkKnownError = function (_Error) {
    _inherits(AppServiceSdkKnownError, _Error);

    function AppServiceSdkKnownError(e) {
        _classCallCheck(this, AppServiceSdkKnownError);

        var _this = _possibleConstructorReturn(this, (AppServiceSdkKnownError.__proto__ || Object.getPrototypeOf(AppServiceSdkKnownError)).call(this, "APP-SERVICE-SDK:" + e));

        _this.type = "AppServiceSdkKnownError";
        return _this;
    }

    return AppServiceSdkKnownError;
}(Error);

var Components = {
    //components
    audio: { "1.0.0": ["id", "src", "loop", "controls", "poster", "name", "author", "binderror", "bindplay", "bindpause", "bindtimeupdate", "bindended"] },
    button: {
        "1.0.0": [{ size: ["default", "mini"] }, { type: ["primary", "default", "warn"] }, "plain", "disabled", "loading", { "form-type": ["submit", "reset"] }, "hover-class", "hover-start-time", "hover-stay-time"],
        "1.1.0": [{ "open-type": ["contact"] }],
        "1.2.0": [{ "open-type": ["share"] }],
        "1.4.0": ["session-from"],
        "1.3.0": [{ "open-type": ["getUserInfo"] }]
    },
    canvas: { "1.0.0": ["canvas-id", "disable-scroll", "bindtouchstart", "bindtouchmove", "bindtouchend", "bindtouchcancel", "bindlongtap", "binderror"] },
    "checkbox-group": { "1.0.0": ["bindchange"] },
    checkbox: { "1.0.0": ["value", "disabled", "checked", "color"] },
    "contact-button": { "1.0.0": ["size", { type: ["default-dark", "default-light"] }, "session-from"] },
    "cover-view": { "1.4.0": [] },
    "cover-image": { "1.4.0": ["src"] },
    form: { "1.0.0": ["report-submit", "bindsubmit", "bindreset"], "1.2.0": ["bindautofill"] },
    icon: { "1.0.0": [{ type: ["success", "success_no_circle", "info", "warn", "waiting", "cancel", "download", "search", "clear"] }, "size", "color"] },
    image: { "1.0.0": ["src", { mode: ["scaleToFill", "aspectFit", "aspectFill", "widthFix", "top", "bottom", "center", "left", "right", "top left", "top right", "bottom left", "bottom right"] }, "binderror", "bindload"] },
    input: {
        "1.0.0": ["value", { type: ["text", "number", "idcard", "digit"] }, "password", "placeholder", "placeholder-style", "placeholder-class", "disabled", "maxlength", "cursor-spacing", "auto-focus", "focus", "bindinput", "bindfocus", "bindblur", "bindconfirm"],
        "1.1.0": [{ "confirm-type": ["send", "search", "next", "go", "done"] }, "confirm-hold"],
        "1.2.0": ["auto-fill"]
    },
    label: { "1.0.0": ["for"] },
    map: {
        "1.0.0": ["longitude", "latitude", "scale", { markers: ["id", "latitude", "longitude", "title", "iconPath", "rotate", "alpha", "width", "height"] }, "covers", { polyline: ["points", "color", "width", "dottedLine"] }, { circles: ["latitude", "longitude", "color", "fillColor", "radius", "strokeWidth"] }, { controls: ["id", "position", "iconPath", "clickable"] }, "include-points", "show-location", "bindmarkertap", "bindcontroltap", "bindregionchange", "bindtap"],
        "1.2.0": [{ markers: ["callout", "label", "anchor"] }, { polyline: ["arrowLine", "borderColor", "borderWidth"] }, "bindcallouttap"]
    },
    modal: { "1.0.0": [] },
    "movable-area": { "1.2.0": [] },
    "movable-view": { "1.2.0": ["direction", "inertia", "out-of-bounds", "x", "y", "damping", "friction"] },
    navigator: {
        "1.0.0": ["url", { "open-type": ["navigate", "redirect", "switchTab"] }, "delta", "hover-class", "hover-start-time", "hover-stay-time"],
        "1.1.0": [{ "open-type": ["reLaunch", "navigateBack"] }]
    },
    "open-data": { "1.4.0": [{ type: ["groupName"] }, "open-gid"] },
    "picker-view": { "1.0.0": ["value", "indicator-style", "bindchange"], "1.1.0": ["indicator-class"] },
    "picker-view-column": { "1.0.0": [] },
    picker: {
        "1.0.0": ["range", "range-key", "value", "bindchange", "disabled", "start", "end", { fields: ["year", "month", "day"] }, { mode: ["selector", "date", "time"] }],
        "1.2.0": ["auto-fill"],
        "1.4.0": ["bindcolumnchange", { mode: ["multiSelector", "region"] }]
    },
    progress: { "1.0.0": ["percent", "show-info", "stroke-width", "color", "activeColor", "backgroundColor", "active"] },
    "radio-group": { "1.0.0": ["bindchange"] },
    radio: { "1.0.0": ["value", "checked", "disabled", "color"] },
    "rich-text": { "1.4.0": [{ nodes: ["name", "attrs", "children"] }] },
    "scroll-view": { "1.0.0": ["scroll-x", "scroll-y", "upper-threshold", "lower-threshold", "scroll-top", "scroll-left", "scroll-into-view", "scroll-with-animation", "enable-back-to-top", "bindscrolltoupper", "bindscrolltolower", "bindscroll"] },
    slider: { "1.0.0": ["min", "max", "step", "disabled", "value", "color", "selected-color", "activeColor", "backgroundColor", "show-value", "bindchange"] },
    swiper: {
        "1.0.0": ["indicator-dots", "autoplay", "current", "interval", "duration", "circular", "vertical", "bindchange"],
        "1.1.0": ["indicator-color", "indicator-active-color"]
    },
    "swiper-item": { "1.0.0": [] },
    "switch": { "1.0.0": ["checked", { type: ["switch", "checkbox"] }, "bindchange", "color"] },
    text: { "1.0.0": [], "1.1.0": ["selectable"], "1.4.0": [{ space: ["ensp", "emsp", "nbsp"] }, "decode"] },
    textarea: {
        "1.0.0": ["value", "placeholder", "placeholder-style", "placeholder-class", "disabled", "maxlength", "auto-focus", "focus", "auto-height", "fixed", "cursor-spacing", "bindfocus", "bindblur", "bindlinechange", "bindinput", "bindconfirm"],
        "1.2.0": ["auto-fill"]
    },
    video: {
        "1.0.0": ["src", "controls", "danmu-list", "danmu-btn", "enable-danmu", "autoplay", "bindplay", "bindpause", "bindended", "bindtimeupdate", "objectFit", "poster"],
        "1.1.0": ["duration"],
        "1.4.0": ["loop", "muted", "bindfullscreenchange"]
    },
    view: { "1.0.0": ["hover-class", "hover-start-time", "hover-stay-time"] }
};
var APIs = {
    //APIS
    onAccelerometerChange: { "1.0.0": [{ callback: ["x", "y", "z"] }] },
    startAccelerometer: { "1.1.0": [] },
    stopAccelerometer: { "1.1.0": [] },
    chooseAddress: { "1.1.0": [{ success: ["userName", "postalCode", "provinceName", "cityName", "countyName", "detailInfo", "nationalCode", "telNumber"] }] },
    createAnimation: { "1.0.0": [{ object: ["duration", { timingFunction: ["linear", "ease", "ease-in", "ease-in-out", "ease-out", "step-start", "step-end"] }, "delay", "transformOrigin"] }] },
    createAudioContext: { "1.0.0": [] },
    canIUse: { "1.0.0": [] },
    login: { "1.0.0": [{ success: ["code"] }] },
    checkSession: { "1.0.0": [] },
    createMapContext: { "1.0.0": [] },
    requestPayment: { "1.0.0": [{ object: ["timeStamp", "nonceStr", "package", "signType", "paySign"] }] },
    showToast: { "1.0.0": [{ object: ["title", "icon", "duration", "mask"] }], "1.1.0": [{ object: ["image"] }] },
    showLoading: { "1.1.0": [{ object: ["title", "mask"] }] },
    hideToast: { "1.0.0": [] },
    hideLoading: { "1.1.0": [] },
    showModal: {
        "1.0.0": [{ object: ["title", "content", "showCancel", "cancelText", "cancelColor", "confirmText", "confirmColor"] }, { success: ["confirm"] }],
        "1.1.0": [{ success: ["cancel"] }]
    },
    showActionSheet: { "1.0.0": [{ object: ["itemList", "itemColor"] }, { success: ["tapIndex"] }] },
    arrayBufferToBase64: { "1.1.0": [] },
    base64ToArrayBuffer: { "1.1.0": [] },
    createVideoContext: { "1.0.0": [] },
    authorize: { "1.2.0": [{ object: ["scope"] }] },
    openBluetoothAdapter: { "1.1.0": [] },
    closeBluetoothAdapter: { "1.1.0": [] },
    getBluetoothAdapterState: { "1.1.0": [{ success: ["discovering", "available"] }] },
    onBluetoothAdapterStateChange: { "1.1.0": [{ callback: ["available", "discovering"] }] },
    startBluetoothDevicesDiscovery: { "1.1.0": [{ object: ["services", "allowDuplicatesKey", "interval"] }, { success: ["isDiscovering"] }] },
    stopBluetoothDevicesDiscovery: { "1.1.0": [] },
    getBluetoothDevices: { "1.1.0": [{ success: ["devices"] }] },
    onBluetoothDeviceFound: { "1.1.0": [{ callback: ["devices"] }] },
    getConnectedBluetoothDevices: { "1.1.0": [{ object: ["services"] }, { success: ["devices"] }] },
    createBLEConnection: { "1.1.0": [{ object: ["deviceId"] }] },
    closeBLEConnection: { "1.1.0": [{ object: ["deviceId"] }] },
    getBLEDeviceServices: { "1.1.0": [{ object: ["deviceId"] }, { success: ["services"] }] },
    getBLEDeviceCharacteristics: { "1.1.0": [{ object: ["deviceId", "serviceId"] }, { success: ["characteristics"] }] },
    readBLECharacteristicValue: { "1.1.0": [{ object: ["deviceId", "serviceId", "characteristicId"] }, { success: ["characteristic"] }] },
    writeBLECharacteristicValue: { "1.1.0": [{ object: ["deviceId", "serviceId", "characteristicId", "value"] }] },
    notifyBLECharacteristicValueChange: { "1.1.1": [{ object: ["deviceId", "serviceId", "characteristicId", "state"] }] },
    onBLEConnectionStateChange: { "1.1.1": [{ callback: ["deviceId", "connected"] }] },
    onBLECharacteristicValueChange: { "1.1.0": [{ callback: ["deviceId", "serviceId", "characteristicId", "value"] }] },
    captureScreen: { "1.4.0": [{ success: ["tempFilePath"] }] },
    addCard: { "1.1.0": [{ object: ["cardList"] }, { success: ["cardList"] }] },
    openCard: { "1.1.0": [{ object: ["cardList"] }] },
    setClipboardData: { "1.1.0": [{ object: ["data"] }] },
    getClipboardData: { "1.1.0": [{ success: ["data"] }] },
    onCompassChange: { "1.0.0": [{ callback: ["direction"] }] },
    startCompass: { "1.1.0": [] },
    stopCompass: { "1.1.0": [] },
    setStorage: { "1.0.0": [{ object: ["key", "data"] }] },
    getStorage: { "1.0.0": [{ object: ["key"] }, { success: ["data"] }] },
    getStorageSync: { "1.0.0": [] },
    getStorageInfo: { "1.0.0": [{ success: ["keys", "currentSize", "limitSize"] }] },
    removeStorage: { "1.0.0": [{ object: ["key"] }] },
    removeStorageSync: { "1.0.0": [] },
    clearStorage: { "1.0.0": [] },
    clearStorageSync: { "1.0.0": [] },
    getNetworkType: { "1.0.0": [{ success: ["networkType"] }] },
    onNetworkStatusChange: { "1.1.0": [{ callback: ["isConnected", { networkType: ["wifi", "2g", "3g", "4g", "none", "unknown"] }] }] },
    setScreenBrightness: { "1.2.0": [{ object: ["value"] }] },
    getScreenBrightness: { "1.2.0": [{ success: ["value"] }] },
    vibrateLong: { "1.2.0": [] },
    vibrateShort: { "1.2.0": [] },
    getExtConfig: { "1.1.0": [{ success: ["extConfig"] }] },
    getExtConfigSync: { "1.1.0": [] },
    saveFile: { "1.0.0": [{ object: ["tempFilePath"] }, { success: ["savedFilePath"] }] },
    getSavedFileList: { "1.0.0": [{ success: ["fileList"] }] },
    getSavedFileInfo: { "1.0.0": [{ object: ["filePath"] }, { success: ["size", "createTime"] }] },
    removeSavedFile: { "1.0.0": [{ object: ["filePath"] }] },
    openDocument: { "1.0.0": [{ object: ["filePath"] }], "1.4.0": [{ object: ["fileType"] }] },
    getBackgroundAudioManager: { "1.2.0": [] },
    getFileInfo: { "1.4.0": [{ object: ["filePath", { digestAlgorithm: ["md5", "sha1"] }] }, { success: ["size", "digest"] }] },
    startBeaconDiscovery: { "1.2.0": [{ object: ["uuids"] }] },
    stopBeaconDiscovery: { "1.2.0": [] },
    getBeacons: { "1.2.0": [{ success: ["beacons"] }] },
    onBeaconUpdate: { "1.2.0": [{ callback: ["beacons"] }] },
    onBeaconServiceChange: { "1.2.0": [{ callback: ["available", "discovering"] }] },
    getLocation: {
        "1.0.0": [{ object: ["type"] }, { success: ["latitude", "longitude", "speed", "accuracy"] }],
        "1.2.0": [{ success: ["altitude", "verticalAccuracy", "horizontalAccuracy"] }]
    },
    chooseLocation: { "1.0.0": [{ object: ["cancel"] }, { success: ["name", "address", "latitude", "longitude"] }] },
    openLocation: { "1.0.0": [{ object: ["latitude", "longitude", "scale", "name", "address"] }] },
    getBackgroundAudioPlayerState: { "1.0.0": [{ success: ["duration", "currentPosition", "status", "downloadPercent", "dataUrl"] }] },
    playBackgroundAudio: { "1.0.0": [{ object: ["dataUrl", "title", "coverImgUrl"] }] },
    pauseBackgroundAudio: { "1.0.0": [] },
    seekBackgroundAudio: { "1.0.0": [{ object: ["position"] }] },
    stopBackgroundAudio: { "1.0.0": [] },
    onBackgroundAudioPlay: { "1.0.0": [] },
    onBackgroundAudioPause: { "1.0.0": [] },
    onBackgroundAudioStop: { "1.0.0": [] },
    chooseImage: {
        "1.0.0": [{ object: ["count", "sizeType", "sourceType"] }, { success: ["tempFilePaths"] }],
        "1.2.0": [{ success: ["tempFiles"] }]
    },
    previewImage: { "1.0.0": [{ object: ["current", "urls"] }] },
    getImageInfo: { "1.0.0": [{ object: ["src"] }, { success: ["width", "height", "path"] }] },
    saveImageToPhotosAlbum: { "1.2.0": [{ object: ["filePath"] }] },
    startRecord: { "1.0.0": [{ success: ["tempFilePath"] }] },
    stopRecord: { "1.0.0": [] },
    chooseVideo: { "1.0.0": [{ object: ["sourceType", "maxDuration", "camera"] }, { success: ["tempFilePath", "duration", "size", "height", "width"] }] },
    saveVideoToPhotosAlbum: { "1.2.0": [{ object: ["filePath"] }] },
    playVoice: { "1.0.0": [{ object: ["filePath"] }] },
    pauseVoice: { "1.0.0": [] },
    stopVoice: { "1.0.0": [] },
    navigateBackMiniProgram: { "1.3.0": [{ object: ["extraData"] }] },
    navigateToMiniProgram: { "1.3.0": [{ object: ["appId", "path", "extraData", "envVersion"] }] },
    uploadFile: { "1.0.0": [{ object: ["url", "filePath", "name", "header", "formData"] }, { success: ["data", "statusCode"] }] },
    downloadFile: { "1.0.0": [{ object: ["url", "header"] }] },
    request: {
        "1.0.0": [{ object: ["url", "data", "header", { method: ["OPTIONS", "GET", "HEAD", "POST", "PUT", "DELETE", "TRACE", "CONNECT"] }, "dataType"] }, { success: ["data", "statusCode"] }],
        "1.2.0": [{ success: ["header"] }]
    },
    connectSocket: {
        "1.0.0": [{ object: ["url", "data", "header", { method: ["OPTIONS", "GET", "HEAD", "POST", "PUT", "DELETE", "TRACE", "CONNECT"] }] }],
        "1.4.0": [{ object: ["protocols"] }]
    },
    onSocketOpen: { "1.0.0": [] },
    onSocketError: { "1.0.0": [] },
    sendSocketMessage: { "1.0.0": [{ object: ["data"] }] },
    onSocketMessage: { "1.0.0": [{ callback: ["data"] }] },
    closeSocket: { "1.0.0": [], "1.4.0": [{ object: ["code", "reason"] }] },
    onSocketClose: { "1.0.0": [] },
    onUserCaptureScreen: { "1.4.0": [] },
    chooseContact: { "1.0.0": [{ success: ["phoneNumber", "displayName"] }] },
    getUserInfo: {
        "1.0.0": [{ success: ["userInfo", "rawData", "signature", "encryptedData", "iv"] }],
        "1.1.0": [{ object: ["withCredentials"] }],
        "1.4.0": [{ object: ["lang"] }]
    },
    addPhoneContact: { "1.2.0": [{ object: ["photoFilePath", "nickName", "lastName", "middleName", "firstName", "remark", "mobilePhoneNumber", "weChatNumber", "addressCountry", "addressState", "addressCity", "addressStreet", "addressPostalCode", "organization", "title", "workFaxNumber", "workPhoneNumber", "hostNumber", "email", "url", "workAddressCountry", "workAddressState", "workAddressCity", "workAddressStreet", "workAddressPostalCode", "homeFaxNumber", "homePhoneNumber", "homeAddressCountry", "homeAddressState", "homeAddressCity", "homeAddressStreet", "homeAddressPostalCode"] }] },
    makePhoneCall: { "1.0.0": [{ object: ["phoneNumber"] }] },
    stopPullDownRefresh: { "1.0.0": [] },
    scanCode: {
        "1.0.0": [{ success: ["result", "scanType", "charSet", "path"] }],
        "1.2.0": [{ object: ["onlyFromCamera"] }]
    },
    pageScrollTo: { "1.4.0": [{ object: ["scrollTop"] }] },
    setEnableDebug: { "1.4.0": [{ object: ["enableDebug"] }] },
    setKeepScreenOn: { "1.4.0": [{ object: ["keepScreenOn"] }] },
    setNavigationBarColor: { "1.4.0": [{ object: ["frontColor", "backgroundColor", "animation", "animation.duration", { "animation.timingFunc": ["linear", "easeIn", "easeOut", "easeInOut"] }] }] },
    openSetting: { "1.1.0": [{ success: ["authSetting"] }] },
    getSetting: { "1.2.0": [{ success: ["authSetting"] }] },
    showShareMenu: { "1.1.0": [{ object: ["withShareTicket"] }] },
    hideShareMenu: { "1.1.0": [] },
    updateShareMenu: { "1.2.0": [{ object: ["withShareTicket"] }], "1.4.0": [{ object: ["dynamic", "widget"] }] },
    getShareInfo: { "1.1.0": [{ object: ["shareTicket"] }, { callback: ["encryptedData", "iv"] }] },
    getSystemInfo: {
        "1.0.0": [{ success: ["model", "pixelRatio", "windowWidth", "windowHeight", "language", "version", "system", "platform"] }],
        "1.1.0": [{ success: ["screenWidth", "screenHeight", "SDKVersion"] }]
    },
    getSystemInfoSync: {
        "1.0.0": [{ return: ["model", "pixelRatio", "windowWidth", "windowHeight", "language", "version", "system", "platform"] }],
        "1.1.0": [{ return: ["screenWidth", "screenHeight", "SDKVersion"] }]
    },
    navigateTo: { "1.0.0": [{ object: ["url"] }] },
    redirectTo: { "1.0.0": [{ object: ["url"] }] },
    reLaunch: { "1.1.0": [{ object: ["url"] }] },
    switchTab: { "1.0.0": [{ object: ["url"] }] },
    navigateBack: { "1.0.0": [{ object: ["delta"] }] },
    setNavigationBarTitle: { "1.0.0": [{ object: ["title"] }] },
    showNavigationBarLoading: { "1.0.0": [] },
    hideNavigationBarLoading: { "1.0.0": [] },
    setTopBarText: { "1.4.2": [{ object: ["text"] }] },
    getWeRunData: { "1.2.0": [{ success: ["encryptedData", "iv"] }] },
    createSelectorQuery: { "1.4.0": [] },
    createCanvasContext: { "1.0.0": [] },
    canvasToTempFilePath: {
        "1.0.0": [{ object: ["canvasId"] }],
        "1.2.0": [{ object: ["x", "y", "width", "height", "destWidth", "destHeight"] }]
    },
    canvasContext: {
        "1.0.0": ["addColorStop", "arc", "beginPath", "bezierCurveTo", "clearActions", "clearRect", "closePath", "createCircularGradient", "createLinearGradient", "drawImage", "draw", "fillRect", "fillText", "fill", "lineTo", "moveTo", "quadraticCurveTo", "rect", "rotate", "save", "scale", "setFillStyle", "setFontSize", "setGlobalAlpha", "setLineCap", "setLineJoin", "setLineWidth", "setMiterLimit", "setShadow", "setStrokeStyle", "strokeRect", "stroke", "translate"],
        "1.1.0": ["setTextAlign"],
        "1.4.0": ["setTextBaseline"]
    },
    animation: { "1.0.0": ["opacity", "backgroundColor", "width", "height", "top", "left", "bottom", "right", "rotate", "rotateX", "rotateY", "rotateZ", "rotate3d", "scale", "scaleX", "scaleY", "scaleZ", "scale3d", "translate", "translateX", "translateY", "translateZ", "translate3d", "skew", "skewX", "skewY", "matrix", "matrix3d"] },
    audioContext: { "1.0.0": ["setSrc", "play", "pause", "seek"] },
    mapContext: {
        "1.0.0": ["getCenterLocation", "moveToLocation"],
        "1.2.0": ["translateMarker", "includePoints"],
        "1.4.0": ["getRegion", "getScale"]
    },
    videoContext: {
        "1.0.0": ["play", "pause", "seek", "sendDanmu"],
        "1.4.0": ["playbackRate", "requestFullScreen", "exitFullScreen"]
    },
    backgroundAudioManager: { "1.2.0": ["play", "pause", "stop", "seek", "onCanplay", "onPlay", "onPause", "onStop", "onEnded", "onTimeUpdate", "onPrev", "onNext", "onError", "onWaiting", "duration", "currentTime", "paused", "src", "startTime", "buffered", "title", "epname", "singer", "coverImgUrl", "webUrl"] },
    uploadTask: { "1.4.0": ["onProgressUpdate", "abort"] },
    downloadTask: { "1.4.0": ["onProgressUpdate", "abort"] },
    requestTask: { "1.4.0": ["abort"] },
    selectorQuery: { "1.4.0": ["select", "selectAll", "selectViewport", "exec"] },
    onBLEConnectionStateChanged: { "1.1.0": [{ callback: ["deviceId", "connected"] }] },
    notifyBLECharacteristicValueChanged: { "1.1.0": [{ object: ["deviceId", "serviceId", "characteristicId", "state"] }] },
    sendBizRedPacket: { "1.2.0": [{ object: ["timeStamp", "nonceStr", "package", "signType", "paySign"] }] }
};
//检测组件相关是否存在
function isComponentExist(params) {
    var name = params[0],
        //组件名
    attribute = params[1],
        //属性名
    option = params[2],
        //组件属性可选值
    component = Components[name];
    if (!attribute) {
        return true;
    } else {
        for (var key in component) {
            for (var i = 0; i < component[key].length; i++) {
                if ("string" == typeof component[key][i] && component[key][i] == attribute) {
                    return true;
                } else if (component[key][i][attribute]) {
                    if (!option) {
                        return true;
                    } else if (component[key][i][attribute].indexOf(option) > -1) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}

//检测API相关是否存在
function isAPIExist(params) {
    var name = params[0],
        //API名
    method = params[1],
        //调用方式：有效值为return, success, object, callback
    param = params[2],
        //组件属性可选值
    options = params[3],
        methods = ["return", "success", "object", "callback"],
        api = APIs[name];
    if (api) {
        if (!method) {
            return true;
        } else if (methods.indexOf(method) < 0) {
            return false;
        } else {
            for (var key in api) {
                for (var i = 0; i < key.length; i++) {
                    if ("object" == _typeof(api[key][i]) && api[key][i][method]) {
                        if (!param) {
                            return true;
                        } else {
                            for (var j = 0; j < api[key][i][method].length; j++) {
                                if (typeof api[key][i][method][j] == "string" && api[key][i][method][j] == param) {
                                    return true;
                                } else if (_typeof(api[key][i][method][j]) == "object" && api[key][i][method][j][param]) {
                                    if (!options) {
                                        return true;
                                    } else if (api[key][i][method][j][param].indexOf(options) > -1) {
                                        return true;
                                    } else {
                                        return false;
                                    }
                                }
                            }
                            return true;
                        }
                    }
                }
                return false;
            }
            return false;
        }
    } else {
        return true;
    }
}
function canIUse(params, version) {
    var name = params[0]; //API或组件名
    if (Components[name]) {
        return isComponentExist(params);
    } else if (APIs[name]) {
        return isAPIExist(params);
    } else {
        return false;
    }
}

function checkParam(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

var config = function () {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var obj = t[n];
            obj.enumerable = obj.enumerable || !1, obj.configurable = !0, "value" in obj && (obj.writable = !0), Object.defineProperty(e, obj.key, obj);
        }
    }
    return function (t, n, obj) {
        return n && e(t.prototype, n), obj && e(t, obj), t;
    };
}();
var setSelect = function () {
    function e(t, n, r) {
        checkParam(this, e), this._selectorQuery = t, this._selector = n, this._single = r;
    }
    return config(e, [{
        key: "fields",
        value: function value(e, t) {
            return this._selectorQuery._push(this._selector, this._single, e, t), this._selectorQuery;
        }
    }, {
        key: "boundingClientRect",
        value: function value(e) {
            return this._selectorQuery._push(this._selector, this._single, {
                id: !0,
                dataset: !0,
                rect: !0,
                size: !0
            }, e), this._selectorQuery;
        }
    }, {
        key: "scrollOffset",
        value: function value(e) {
            return this._selectorQuery._push(this._selector, this._single, {
                id: !0,
                dataset: !0,
                scrollOffset: !0
            }, e), this._selectorQuery;
        }
    }]), e;
}();
var wxQuerySelector = function () {
    function init(t) {
        checkParam(this, init);
        this._webviewId = t;
        this._queue = [];
        this._queueCb = [];
    }
    return config(init, [{
        key: "select", value: function value(e) {
            return new setSelect(this, e, !0);
        }
    }, {
        key: "selectAll", value: function value(e) {
            return new setSelect(this, e, !1);
        }
    }, {
        key: "selectViewport", value: function value() {
            return new setSelect(this, "viewport", !0);
        }
    }, {
        key: "_push", value: function value(e, t, n, o) {
            this._queue.push({ selector: e, single: t, fields: n }), this._queueCb.push(o || null);
        }
    }, {
        key: "exec", value: function value(e) {
            var t = this;
            u(this._webviewId, this._queue, function (n) {
                var o = t._queueCb;
                n.forEach(function (e, n) {
                    "function" == typeof o[n] && o[n].call(t, e);
                }), "function" == typeof e && e.call(t, n);
            });
        }
    }]), init;
}();

function transWxmlToHtml(url) {
    if ("string" != typeof url) return url;
    var urlArr = url.split("?");
    return urlArr[0] += ".html", void 0 !== urlArr[1] ? urlArr[0] + "?" + urlArr[1] : urlArr[0];
}

function removeHtmlSuffixFromUrl(url) {
    return "string" == typeof url ? -1 !== url.indexOf("?") ? url.replace(/\.html\?/, "?") : url.replace(/\.html$/, "") : url;
}

exports.default = {
    surroundByTryCatchFactory: surroundByTryCatchFactory,
    getDataType: getDataType,
    isObject: isObject,
    paramCheck: paramCheck,
    getRealRoute: getRealRoute,
    getPlatform: getPlatform,
    urlEncodeFormData: urlEncodeFormData,
    addQueryStringToUrl: addQueryStringToUrl,
    validateUrl: validateUrl,
    assign: assign,
    encodeUrlQuery: encodeUrlQuery,
    transWxmlToHtml: transWxmlToHtml,
    removeHtmlSuffixFromUrl: removeHtmlSuffixFromUrl,
    extend: extend,
    arrayBufferToBase64: arrayBufferToBase64,
    base64ToArrayBuffer: base64ToArrayBuffer,
    blobToArrayBuffer: blobToArrayBuffer,
    convertObjectValueToString: convertObjectValueToString,
    anyTypeToString: surroundByTryCatchFactory(anyTypeToString, "anyTypeToString"),
    stringToAnyType: surroundByTryCatchFactory(stringToAnyType, "stringToAnyType"),
    AppServiceSdkKnownError: AppServiceSdkKnownError,
    renameProperty: renameProperty,
    defaultRunningStatus: "active",
    toArray: toArray,
    canIUse: canIUse,
    wxQuerySelector: wxQuerySelector
};

/***/ }),
/* 1 */,
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _utils = __webpack_require__(0);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function invoke() {
    //ServiceJSBridge.invoke
    ServiceJSBridge.invoke.apply(ServiceJSBridge, arguments);
}

function on() {
    //ServiceJSBridge.on
    ServiceJSBridge.on.apply(ServiceJSBridge, arguments);
}

function publish() {
    //ServiceJSBridge.publish
    var args = Array.prototype.slice.call(arguments);
    args[1] = {
        data: args[1],
        options: {
            timestamp: Date.now()
        }
    };
    ServiceJSBridge.publish.apply(ServiceJSBridge, args);
}

function subscribe() {
    //ServiceJSBridge.subscribe
    var args = Array.prototype.slice.call(arguments),
        callback = args[1];
    args[1] = function (params, viewId) {
        var data = params.data,
            options = params.options,
            timeMark = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
            timestamp = options && options.timestamp || 0,
            curTime = Date.now();
        "function" == typeof callback && callback(data, viewId);
        Reporter.speedReport({
            key: "webview2AppService",
            data: data || {},
            timeMark: {
                startTime: timestamp,
                endTime: curTime,
                nativeTime: timeMark.nativeTime || 0
            }
        });
    };
    ServiceJSBridge.subscribe.apply(ServiceJSBridge, args);
}

function invokeMethod(apiName) {
    var options = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        innerFns = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
        params = {};
    for (var i in options) {
        "function" == typeof options[i] && (params[i] = Reporter.surroundThirdByTryCatch(options[i], "at api " + apiName + " " + i + " callback function"), delete options[i]);
    }
    var sysEventFns = {};
    for (var s in innerFns) {
        "function" == typeof innerFns[s] && (sysEventFns[s] = _utils2.default.surroundByTryCatchFactory(innerFns[s], "at api " + apiName + " " + s + " callback function"));
    }
    invoke(apiName, options, function (res) {
        res.errMsg = res.errMsg || apiName + ":ok";
        var isOk = 0 === res.errMsg.indexOf(apiName + ":ok"),
            isCancel = 0 === res.errMsg.indexOf(apiName + ":cancel"),
            isFail = 0 === res.errMsg.indexOf(apiName + ":fail");
        if ("function" == typeof sysEventFns.beforeAll && sysEventFns.beforeAll(res), isOk) {
            "function" == typeof sysEventFns.beforeSuccess && sysEventFns.beforeSuccess(res), "function" == typeof params.success && params.success(res), "function" == typeof sysEventFns.afterSuccess && sysEventFns.afterSuccess(res);
        } else if (isCancel) {
            res.errMsg = res.errMsg.replace(apiName + ":cancel", apiName + ":fail cancel"), "function" == typeof params.fail && params.fail(res), "function" == typeof sysEventFns.beforeCancel && sysEventFns.beforeCancel(res), "function" == typeof params.cancel && params.cancel(res), "function" == typeof sysEventFns.afterCancel && sysEventFns.afterCancel(res);
        } else if (isFail) {
            "function" == typeof sysEventFns.beforeFail && sysEventFns.beforeFail(res), "function" == typeof params.fail && params.fail(res);
            var rt = !0;
            "function" == typeof sysEventFns.afterFail && (rt = sysEventFns.afterFail(res)), rt !== !1 && Reporter.reportIDKey({
                key: apiName + "_fail"
            });
        }
        "function" == typeof params.complete && params.complete(res), "function" == typeof sysEventFns.afterAll && sysEventFns.afterAll(res);
    });
    Reporter.reportIDKey({
        key: apiName
    });
}
function noop() {}
function onMethod(apiName, callback) {
    //onMethod
    on(apiName, _utils2.default.surroundByTryCatchFactory(callback, "at api " + apiName + " callback function"));
}
function beforeInvoke(apiName, params, paramTpl) {
    var res = _utils2.default.paramCheck(params, paramTpl);
    return !res || (beforeInvokeFail(apiName, params, "parameter error: " + res), !1);
}

function beforeInvokeFail(apiName) {
    var params = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        errMsg = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "",
        err = apiName + ":fail " + errMsg;
    console.error(err);
    var fail = Reporter.surroundThirdByTryCatch(params.fail || noop, "at api " + apiName + " fail callback function"),
        complete = Reporter.surroundThirdByTryCatch(params.complete || noop, "at api " + apiName + " complete callback function");
    fail({ errMsg: err });
    complete({ errMsg: err });
}

function checkUrlInConfig(apiName, url, params) {
    var path = url.replace(/\.html\?.*|\.html$/, "");
    return -1 !== __wxConfig.pages.indexOf(path) || (beforeInvokeFail(apiName, params, 'url "' + _utils2.default.removeHtmlSuffixFromUrl(url) + '" is not in app.json'), !1);
}

exports.default = {
    invoke: invoke,
    on: on,
    publish: publish,
    subscribe: subscribe,
    invokeMethod: invokeMethod,
    onMethod: onMethod,
    noop: noop,
    beforeInvoke: beforeInvoke,
    beforeInvokeFail: beforeInvokeFail,
    checkUrlInConfig: checkUrlInConfig
};

/***/ }),
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var isArray = Array.isArray ? Array.isArray : function _isArray(obj) {
    return Object.prototype.toString.call(obj) === "[object Array]";
};
var defaultMaxListeners = 10;

function init() {
    this._events = {};
    if (this._conf) {
        configure.call(this, this._conf);
    }
}

function configure(conf) {
    if (conf) {
        this._conf = conf;

        conf.delimiter && (this.delimiter = conf.delimiter);
        this._maxListeners = conf.maxListeners !== undefined ? conf.maxListeners : defaultMaxListeners;

        conf.wildcard && (this.wildcard = conf.wildcard);
        conf.newListener && (this.newListener = conf.newListener);
        conf.verboseMemoryLeak && (this.verboseMemoryLeak = conf.verboseMemoryLeak);

        if (this.wildcard) {
            this.listenerTree = {};
        }
    } else {
        this._maxListeners = defaultMaxListeners;
    }
}

function logPossibleMemoryLeak(count, eventName) {
    var errorMsg = '(node) warning: possible EventEmitter memory ' + 'leak detected. ' + count + ' listeners added. ' + 'Use emitter.setMaxListeners() to increase limit.';

    if (this.verboseMemoryLeak) {
        errorMsg += ' Event name: ' + eventName + '.';
    }

    if (typeof process !== 'undefined' && process.emitWarning) {
        var e = new Error(errorMsg);
        e.name = 'MaxListenersExceededWarning';
        e.emitter = this;
        e.count = count;
        process.emitWarning(e);
    } else {
        console.error(errorMsg);

        if (console.trace) {
            console.trace();
        }
    }
}

function EventEmitter(conf) {
    this._events = {};
    this.newListener = false;
    this.verboseMemoryLeak = false;
    configure.call(this, conf);
}
EventEmitter.EventEmitter2 = EventEmitter; // backwards compatibility for exporting EventEmitter property

//
// Attention, function return type now is array, always !
// It has zero elements if no any matches found and one or more
// elements (leafs) if there are matches
//
function searchListenerTree(handlers, type, tree, i) {
    if (!tree) {
        return [];
    }
    var listeners = [],
        leaf,
        len,
        branch,
        xTree,
        xxTree,
        isolatedBranch,
        endReached,
        typeLength = type.length,
        currentType = type[i],
        nextType = type[i + 1];
    if (i === typeLength && tree._listeners) {
        //
        // If at the end of the event(s) list and the tree has listeners
        // invoke those listeners.
        //
        if (typeof tree._listeners === 'function') {
            handlers && handlers.push(tree._listeners);
            return [tree];
        } else {
            for (leaf = 0, len = tree._listeners.length; leaf < len; leaf++) {
                handlers && handlers.push(tree._listeners[leaf]);
            }
            return [tree];
        }
    }

    if (currentType === '*' || currentType === '**' || tree[currentType]) {
        //
        // If the event emitted is '*' at this part
        // or there is a concrete match at this patch
        //
        if (currentType === '*') {
            for (branch in tree) {
                if (branch !== '_listeners' && tree.hasOwnProperty(branch)) {
                    listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], i + 1));
                }
            }
            return listeners;
        } else if (currentType === '**') {
            endReached = i + 1 === typeLength || i + 2 === typeLength && nextType === '*';
            if (endReached && tree._listeners) {
                // The next element has a _listeners, add it to the handlers.
                listeners = listeners.concat(searchListenerTree(handlers, type, tree, typeLength));
            }

            for (branch in tree) {
                if (branch !== '_listeners' && tree.hasOwnProperty(branch)) {
                    if (branch === '*' || branch === '**') {
                        if (tree[branch]._listeners && !endReached) {
                            listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], typeLength));
                        }
                        listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], i));
                    } else if (branch === nextType) {
                        listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], i + 2));
                    } else {
                        // No match on this one, shift into the tree but not in the type array.
                        listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], i));
                    }
                }
            }
            return listeners;
        }

        listeners = listeners.concat(searchListenerTree(handlers, type, tree[currentType], i + 1));
    }

    xTree = tree['*'];
    if (xTree) {
        //
        // If the listener tree will allow any match for this part,
        // then recursively explore all branches of the tree
        //
        searchListenerTree(handlers, type, xTree, i + 1);
    }

    xxTree = tree['**'];
    if (xxTree) {
        if (i < typeLength) {
            if (xxTree._listeners) {
                // If we have a listener on a '**', it will catch all, so add its handler.
                searchListenerTree(handlers, type, xxTree, typeLength);
            }

            // Build arrays of matching next branches and others.
            for (branch in xxTree) {
                if (branch !== '_listeners' && xxTree.hasOwnProperty(branch)) {
                    if (branch === nextType) {
                        // We know the next element will match, so jump twice.
                        searchListenerTree(handlers, type, xxTree[branch], i + 2);
                    } else if (branch === currentType) {
                        // Current node matches, move into the tree.
                        searchListenerTree(handlers, type, xxTree[branch], i + 1);
                    } else {
                        isolatedBranch = {};
                        isolatedBranch[branch] = xxTree[branch];
                        searchListenerTree(handlers, type, { '**': isolatedBranch }, i + 1);
                    }
                }
            }
        } else if (xxTree._listeners) {
            // We have reached the end and still on a '**'
            searchListenerTree(handlers, type, xxTree, typeLength);
        } else if (xxTree['*'] && xxTree['*']._listeners) {
            searchListenerTree(handlers, type, xxTree['*'], typeLength);
        }
    }

    return listeners;
}

function growListenerTree(type, listener) {

    type = typeof type === 'string' ? type.split(this.delimiter) : type.slice();

    //
    // Looks for two consecutive '**', if so, don't add the event at all.
    //
    for (var i = 0, len = type.length; i + 1 < len; i++) {
        if (type[i] === '**' && type[i + 1] === '**') {
            return;
        }
    }

    var tree = this.listenerTree;
    var name = type.shift();

    while (name !== undefined) {

        if (!tree[name]) {
            tree[name] = {};
        }

        tree = tree[name];

        if (type.length === 0) {

            if (!tree._listeners) {
                tree._listeners = listener;
            } else {
                if (typeof tree._listeners === 'function') {
                    tree._listeners = [tree._listeners];
                }

                tree._listeners.push(listener);

                if (!tree._listeners.warned && this._maxListeners > 0 && tree._listeners.length > this._maxListeners) {
                    tree._listeners.warned = true;
                    logPossibleMemoryLeak.call(this, tree._listeners.length, name);
                }
            }
            return true;
        }
        name = type.shift();
    }
    return true;
}

// By default EventEmitters will print a warning if more than
// 10 listeners are added to it. This is a useful default which
// helps finding memory leaks.
//
// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.

EventEmitter.prototype.delimiter = '.';

EventEmitter.prototype.setMaxListeners = function (n) {
    if (n !== undefined) {
        this._maxListeners = n;
        if (!this._conf) this._conf = {};
        this._conf.maxListeners = n;
    }
};

EventEmitter.prototype.event = '';

EventEmitter.prototype.once = function (event, fn) {
    return this._once(event, fn, false);
};

EventEmitter.prototype.prependOnceListener = function (event, fn) {
    return this._once(event, fn, true);
};

EventEmitter.prototype._once = function (event, fn, prepend) {
    this._many(event, 1, fn, prepend);
    return this;
};

EventEmitter.prototype.many = function (event, ttl, fn) {
    return this._many(event, ttl, fn, false);
};

EventEmitter.prototype.prependMany = function (event, ttl, fn) {
    return this._many(event, ttl, fn, true);
};

EventEmitter.prototype._many = function (event, ttl, fn, prepend) {
    var self = this;

    if (typeof fn !== 'function') {
        throw new Error('many only accepts instances of Function');
    }

    function listener() {
        if (--ttl === 0) {
            self.off(event, listener);
        }
        return fn.apply(this, arguments);
    }

    listener._origin = fn;

    this._on(event, listener, prepend);

    return self;
};

EventEmitter.prototype.emit = function () {

    this._events || init.call(this);

    var type = arguments[0];

    if (type === 'newListener' && !this.newListener) {
        if (!this._events.newListener) {
            return false;
        }
    }

    var al = arguments.length;
    var args, l, i, j;
    var handler;

    if (this._all && this._all.length) {
        handler = this._all.slice();
        if (al > 3) {
            args = new Array(al);
            for (j = 0; j < al; j++) {
                args[j] = arguments[j];
            }
        }

        for (i = 0, l = handler.length; i < l; i++) {
            this.event = type;
            switch (al) {
                case 1:
                    handler[i].call(this, type);
                    break;
                case 2:
                    handler[i].call(this, type, arguments[1]);
                    break;
                case 3:
                    handler[i].call(this, type, arguments[1], arguments[2]);
                    break;
                default:
                    handler[i].apply(this, args);
            }
        }
    }

    if (this.wildcard) {
        handler = [];
        var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
        searchListenerTree.call(this, handler, ns, this.listenerTree, 0);
    } else {
        handler = this._events[type];
        if (typeof handler === 'function') {
            this.event = type;
            switch (al) {
                case 1:
                    handler.call(this);
                    break;
                case 2:
                    handler.call(this, arguments[1]);
                    break;
                case 3:
                    handler.call(this, arguments[1], arguments[2]);
                    break;
                default:
                    args = new Array(al - 1);
                    for (j = 1; j < al; j++) {
                        args[j - 1] = arguments[j];
                    }handler.apply(this, args);
            }
            return true;
        } else if (handler) {
            // need to make copy of handlers because list can change in the middle
            // of emit call
            handler = handler.slice();
        }
    }

    if (handler && handler.length) {
        if (al > 3) {
            args = new Array(al - 1);
            for (j = 1; j < al; j++) {
                args[j - 1] = arguments[j];
            }
        }
        for (i = 0, l = handler.length; i < l; i++) {
            this.event = type;
            switch (al) {
                case 1:
                    handler[i].call(this);
                    break;
                case 2:
                    handler[i].call(this, arguments[1]);
                    break;
                case 3:
                    handler[i].call(this, arguments[1], arguments[2]);
                    break;
                default:
                    handler[i].apply(this, args);
            }
        }
        return true;
    } else if (!this._all && type === 'error') {
        if (arguments[1] instanceof Error) {
            throw arguments[1]; // Unhandled 'error' event
        } else {
            throw new Error("Uncaught, unspecified 'error' event.");
        }
        return false;
    }

    return !!this._all;
};

EventEmitter.prototype.emitAsync = function () {

    this._events || init.call(this);

    var type = arguments[0];

    if (type === 'newListener' && !this.newListener) {
        if (!this._events.newListener) {
            return Promise.resolve([false]);
        }
    }

    var promises = [];

    var al = arguments.length;
    var args, l, i, j;
    var handler;

    if (this._all) {
        if (al > 3) {
            args = new Array(al);
            for (j = 1; j < al; j++) {
                args[j] = arguments[j];
            }
        }
        for (i = 0, l = this._all.length; i < l; i++) {
            this.event = type;
            switch (al) {
                case 1:
                    promises.push(this._all[i].call(this, type));
                    break;
                case 2:
                    promises.push(this._all[i].call(this, type, arguments[1]));
                    break;
                case 3:
                    promises.push(this._all[i].call(this, type, arguments[1], arguments[2]));
                    break;
                default:
                    promises.push(this._all[i].apply(this, args));
            }
        }
    }

    if (this.wildcard) {
        handler = [];
        var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
        searchListenerTree.call(this, handler, ns, this.listenerTree, 0);
    } else {
        handler = this._events[type];
    }

    if (typeof handler === 'function') {
        this.event = type;
        switch (al) {
            case 1:
                promises.push(handler.call(this));
                break;
            case 2:
                promises.push(handler.call(this, arguments[1]));
                break;
            case 3:
                promises.push(handler.call(this, arguments[1], arguments[2]));
                break;
            default:
                args = new Array(al - 1);
                for (j = 1; j < al; j++) {
                    args[j - 1] = arguments[j];
                }promises.push(handler.apply(this, args));
        }
    } else if (handler && handler.length) {
        handler = handler.slice();
        if (al > 3) {
            args = new Array(al - 1);
            for (j = 1; j < al; j++) {
                args[j - 1] = arguments[j];
            }
        }
        for (i = 0, l = handler.length; i < l; i++) {
            this.event = type;
            switch (al) {
                case 1:
                    promises.push(handler[i].call(this));
                    break;
                case 2:
                    promises.push(handler[i].call(this, arguments[1]));
                    break;
                case 3:
                    promises.push(handler[i].call(this, arguments[1], arguments[2]));
                    break;
                default:
                    promises.push(handler[i].apply(this, args));
            }
        }
    } else if (!this._all && type === 'error') {
        if (arguments[1] instanceof Error) {
            return Promise.reject(arguments[1]); // Unhandled 'error' event
        } else {
            return Promise.reject("Uncaught, unspecified 'error' event.");
        }
    }

    return Promise.all(promises);
};

EventEmitter.prototype.on = function (type, listener) {
    return this._on(type, listener, false);
};

EventEmitter.prototype.prependListener = function (type, listener) {
    return this._on(type, listener, true);
};

EventEmitter.prototype.onAny = function (fn) {
    return this._onAny(fn, false);
};

EventEmitter.prototype.prependAny = function (fn) {
    return this._onAny(fn, true);
};

EventEmitter.prototype.addListener = EventEmitter.prototype.on;

EventEmitter.prototype._onAny = function (fn, prepend) {
    if (typeof fn !== 'function') {
        throw new Error('onAny only accepts instances of Function');
    }

    if (!this._all) {
        this._all = [];
    }

    // Add the function to the event listener collection.
    if (prepend) {
        this._all.unshift(fn);
    } else {
        this._all.push(fn);
    }

    return this;
};

EventEmitter.prototype._on = function (type, listener, prepend) {
    if (typeof type === 'function') {
        this._onAny(type, listener);
        return this;
    }

    if (typeof listener !== 'function') {
        throw new Error('on only accepts instances of Function');
    }
    this._events || init.call(this);

    // To avoid recursion in the case that type == "newListeners"! Before
    // adding it to the listeners, first emit "newListeners".
    this.emit('newListener', type, listener);

    if (this.wildcard) {
        growListenerTree.call(this, type, listener);
        return this;
    }

    if (!this._events[type]) {
        // Optimize the case of one listener. Don't need the extra array object.
        this._events[type] = listener;
    } else {
        if (typeof this._events[type] === 'function') {
            // Change to array.
            this._events[type] = [this._events[type]];
        }

        // If we've already got an array, just add
        if (prepend) {
            this._events[type].unshift(listener);
        } else {
            this._events[type].push(listener);
        }

        // Check for listener leak
        if (!this._events[type].warned && this._maxListeners > 0 && this._events[type].length > this._maxListeners) {
            this._events[type].warned = true;
            logPossibleMemoryLeak.call(this, this._events[type].length, type);
        }
    }

    return this;
};

EventEmitter.prototype.off = function (type, listener) {
    if (typeof listener !== 'function') {
        throw new Error('removeListener only takes instances of Function');
    }

    var handlers,
        leafs = [];

    if (this.wildcard) {
        var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
        leafs = searchListenerTree.call(this, null, ns, this.listenerTree, 0);
    } else {
        // does not use listeners(), so no side effect of creating _events[type]
        if (!this._events[type]) return this;
        handlers = this._events[type];
        leafs.push({ _listeners: handlers });
    }

    for (var iLeaf = 0; iLeaf < leafs.length; iLeaf++) {
        var leaf = leafs[iLeaf];
        handlers = leaf._listeners;
        if (isArray(handlers)) {

            var position = -1;

            for (var i = 0, length = handlers.length; i < length; i++) {
                if (handlers[i] === listener || handlers[i].listener && handlers[i].listener === listener || handlers[i]._origin && handlers[i]._origin === listener) {
                    position = i;
                    break;
                }
            }

            if (position < 0) {
                continue;
            }

            if (this.wildcard) {
                leaf._listeners.splice(position, 1);
            } else {
                this._events[type].splice(position, 1);
            }

            if (handlers.length === 0) {
                if (this.wildcard) {
                    delete leaf._listeners;
                } else {
                    delete this._events[type];
                }
            }

            this.emit("removeListener", type, listener);

            return this;
        } else if (handlers === listener || handlers.listener && handlers.listener === listener || handlers._origin && handlers._origin === listener) {
            if (this.wildcard) {
                delete leaf._listeners;
            } else {
                delete this._events[type];
            }

            this.emit("removeListener", type, listener);
        }
    }

    function recursivelyGarbageCollect(root) {
        if (root === undefined) {
            return;
        }
        var keys = Object.keys(root);
        for (var i in keys) {
            var key = keys[i];
            var obj = root[key];
            if (obj instanceof Function || (typeof obj === 'undefined' ? 'undefined' : _typeof(obj)) !== "object" || obj === null) continue;
            if (Object.keys(obj).length > 0) {
                recursivelyGarbageCollect(root[key]);
            }
            if (Object.keys(obj).length === 0) {
                delete root[key];
            }
        }
    }
    recursivelyGarbageCollect(this.listenerTree);

    return this;
};

EventEmitter.prototype.offAny = function (fn) {
    var i = 0,
        l = 0,
        fns;
    if (fn && this._all && this._all.length > 0) {
        fns = this._all;
        for (i = 0, l = fns.length; i < l; i++) {
            if (fn === fns[i]) {
                fns.splice(i, 1);
                this.emit("removeListenerAny", fn);
                return this;
            }
        }
    } else {
        fns = this._all;
        for (i = 0, l = fns.length; i < l; i++) {
            this.emit("removeListenerAny", fns[i]);
        }this._all = [];
    }
    return this;
};

EventEmitter.prototype.removeListener = EventEmitter.prototype.off;

EventEmitter.prototype.removeAllListeners = function (type) {
    if (arguments.length === 0) {
        !this._events || init.call(this);
        return this;
    }

    if (this.wildcard) {
        var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
        var leafs = searchListenerTree.call(this, null, ns, this.listenerTree, 0);

        for (var iLeaf = 0; iLeaf < leafs.length; iLeaf++) {
            var leaf = leafs[iLeaf];
            leaf._listeners = null;
        }
    } else if (this._events) {
        this._events[type] = null;
    }
    return this;
};

EventEmitter.prototype.listeners = function (type) {
    if (this.wildcard) {
        var handlers = [];
        var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
        searchListenerTree.call(this, handlers, ns, this.listenerTree, 0);
        return handlers;
    }

    this._events || init.call(this);

    if (!this._events[type]) this._events[type] = [];
    if (!isArray(this._events[type])) {
        this._events[type] = [this._events[type]];
    }
    return this._events[type];
};

EventEmitter.prototype.eventNames = function () {
    return Object.keys(this._events);
};

EventEmitter.prototype.listenerCount = function (type) {
    return this.listeners(type).length;
};

EventEmitter.prototype.listenersAny = function () {

    if (this._all) {
        return this._all;
    } else {
        return [];
    }
};

exports.default = EventEmitter;
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(128)))

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
// module6

exports.default = {
    LOG_LIMIT: 1024,
    AppStatus: {
        FORE_GROUND: 0,
        BACK_GROUND: 1,
        LOCLOCKK: 2
    }
};

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var isDevTools = function isDevTools() {
  return true;
};
var addHtmlSuffixToUrl = function addHtmlSuffixToUrl(url) {
  //给url增加.html后缀
  if ("string" != typeof url) {
    return url;
  }
  var uri = url.split("?")[0],
      query = url.split("?")[1];
  uri += ".html";
  if ("undefined" != typeof query) {
    return uri + "?" + query;
  } else {
    return uri;
  }
};
var removeHtmlSuffixFromUrl = function removeHtmlSuffixFromUrl(url) {
  //去除url后面的.html
  if ("string" == typeof url && url.indexOf(".html") === url.length - 4) {
    return url.substring(0, url.length - 5);
  } else {
    return url;
  }
};

var hasOwnProperty = Object.prototype.hasOwnProperty;

var toString = Object.prototype.toString;

var AppServiceEngineKnownError = function (_Error) {
  _inherits(AppServiceEngineKnownError, _Error);

  function AppServiceEngineKnownError(e) {
    _classCallCheck(this, AppServiceEngineKnownError);

    var _this = _possibleConstructorReturn(this, (AppServiceEngineKnownError.__proto__ || Object.getPrototypeOf(AppServiceEngineKnownError)).call(this, "APP-SERVICE-Engine:" + e));

    _this.type = "AppServiceEngineKnownError";
    return _this;
  }

  return AppServiceEngineKnownError;
}(Error);

var pageEngine = {
  getPlatform: function getPlatform() {
    //get platform
    return "devtools";
  },
  safeInvoke: function safeInvoke() {
    //do page method
    var res = void 0,
        args = Array.prototype.slice.call(arguments),
        fn = args[0];
    args = args.slice(1);
    try {
      var startTime = Date.now();
      res = this[fn].apply(this, args);
      var doTime = Date.now() - startTime;
      doTime > 1e3 && Reporter.slowReport({
        key: "pageInvoke",
        cost: doTime,
        extend: "at " + this.__route__ + " page " + fn + " function"
      });
    } catch (e) {
      Reporter.thirdErrorReport({
        error: e,
        extend: 'at "' + this.__route__ + '" page ' + fn + " function"
      });
    }
    return res;
  },
  isEmptyObject: function isEmptyObject(obj) {
    for (var t in obj) {
      if (obj.hasOwnProperty(t)) {
        return false;
      }
    }
    return true;
  },
  extend: function extend(target, obj) {
    for (var keys = Object.keys(obj), o = keys.length; o--;) {
      target[keys[o]] = obj[keys[o]];
    }
    return target;
  },
  noop: function noop() {},
  getDataType: function getDataType(param) {
    return Object.prototype.toString.call(param).split(" ")[1].split("]")[0];
  },
  isObject: function isObject(param) {
    return null !== param && "object" === (typeof param === "undefined" ? "undefined" : _typeof(param));
  },
  hasOwn: function hasOwn(obj, attr) {
    return hasOwnProperty.call(obj, attr);
  },
  def: function def(obj, attr, value, enumerable) {
    Object.defineProperty(obj, attr, {
      value: value,
      enumerable: !!enumerable,
      writable: true,
      configurable: true
    });
  },
  isPlainObject: function isPlainObject(e) {
    return toString.call(e) === "[object Object]";
  },
  error: function error(title, err) {
    console.group(new Date() + " " + title);
    console.error(err);
    console.groupEnd();
  },
  warn: function warn(title, _warn) {
    console.group(new Date() + " " + title);
    console.warn(_warn);
    console.groupEnd();
  },
  info: function info(msg) {
    __wxConfig__ && __wxConfig__.debug && console.info(msg);
  },
  surroundByTryCatch: function surroundByTryCatch(fn, extend) {
    var self = this;
    return function () {
      try {
        return fn.apply(fn, arguments);
      } catch (e) {
        self.errorReport(e, extend);
        return function () {};
      }
    };
  },
  errorReport: function errorReport(err, extend) {
    //d
    if ("[object Error]" === Object.prototype.toString.apply(err)) {
      if ("AppServiceEngineKnownError" === err.type) {
        throw err;
      }
      Reporter.errorReport({
        key: "jsEnginScriptError",
        error: err,
        extend: extend
      });
    }
  },
  publish: function publish() {
    var params = Array.prototype.slice.call(arguments),
        defaultOpt = {
      options: {
        timestamp: Date.now()
      }
    };
    params[1] ? params[1].options = this.extend(params[1].options || {}, defaultOpt.options) : params[1] = defaultOpt;
    ServiceJSBridge.publish.apply(ServiceJSBridge, params);
  },
  AppServiceEngineKnownError: AppServiceEngineKnownError

  // export default Object.assi{},{},pageEngine,htmlSuffix);
};exports.default = _extends({}, pageEngine, {
  isDevTools: isDevTools,
  addHtmlSuffixToUrl: addHtmlSuffixToUrl,
  removeHtmlSuffixFromUrl: removeHtmlSuffixFromUrl
});

/***/ }),
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _errorType = __webpack_require__(14);

var errorType = _interopRequireWildcard(_errorType);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

var jsBridge = void 0,
    bridgeName = void 0,
    logEventName = void 0;
if (typeof ServiceJSBridge !== 'undefined') {
  jsBridge = window.ServiceJSBridge;
  bridgeName = 'Service';
  logEventName = 'H5_JS_SERVICE_ERR';
} else if (typeof HeraJSBridge !== 'undefined') {
  jsBridge = window.HeraJSBridge;
  bridgeName = 'Weixin';
  logEventName = 'H5_JS_VIEW_ERR';
}
if (typeof __wxConfig === 'undefined') {
  var _wxConfig = typeof __wxConfig__ !== 'undefined' && __wxConfig__ || {};
}
function onBridgeReady(fn) {
  typeof jsBridge !== 'undefined' ? fn() : document.addEventListener(bridgeName + 'JSBridgeReady', fn, !1);
}
function invoke() {
  // invoke
  var args = arguments;
  onBridgeReady(function () {
    jsBridge.invoke.apply(jsBridge, args);
  });
}
function publish() {
  // publish
  var args = arguments;
  onBridgeReady(function () {
    jsBridge.publish.apply(jsBridge, args);
  });
}
function getUpdateTime() {
  // get wx.version.updateTime
  return typeof wx !== 'undefined' ? wx.version && wx.version.updateTime || '' : '';
}
function _reportKeyValue() {
  // 以key/value的形式上报日志
  !reportKeyValues || reportKeyValues.length <= 0 || (invoke('reportKeyValue', {
    dataArray: reportKeyValues
  }), reportKeyValues = []);
}
function _reportIDKey() {
  !reportIDKeys || reportIDKeys.length <= 0 || (invoke('reportIDKey', { dataArray: reportIDKeys }), reportIDKeys = []);
}
function systemLog() {
  !systemLogs || systemLogs.length <= 0 || (invoke('systemLog', { dataArray: systemLogs }), systemLogs = []);
}
function getPlatName() {
  // get platname
  return 'devtools';
}
function safeCall(fn) {
  //
  return function () {
    try {
      return fn.apply(fn, arguments);
    } catch (e) {
      console.error('reporter error:' + e.message);
    }
  };
}
function _defindGeter(key) {
  defineObj.__defineGetter__(key, function () {
    return safeCall(utils[key]);
  });
}
var reportIDKeyLength = 1,
    reportKeyValueLengthThreshold = 20,
    systemLogLength = 50,
    submitTLThreshold = 50,
    reportKeyTLThreshold = 50,
    reportIDKeyTLThreshold = 20,
    logTLThreshold = 50,
    speedReportThreshold = 500,
    slowReportThreshold = 500,
    errorReportTemp = 3,
    errorReportSize = 3,
    slowReportLength = 3,
    errorReportLength = 50,
    slowReportValueLength = 50,
    reportKeyValues = [],
    reportIDKeys = [],
    systemLogs = [],
    reportKeyTimePreTime = 0,
    reportIDKeyPreTime = 0,
    logPreTime = 0,
    submitPreTime = 0,
    slowReportTime = 0,
    speedReportMap = {},
    errorReportMap = {},
    slowReportMap = {};
typeof logxx === 'function' && logxx('reporter-sdk start');
var isIOS = getPlatName() === 'ios';
var errListenerFns = function errListenerFns() {};
var utils = {
  // log report obj
  surroundThirdByTryCatch: function surroundThirdByTryCatch(fn, ext) {
    return function () {
      var res;
      try {
        var startTime = Date.now();
        res = fn.apply(fn, arguments);
        var doTime = Date.now() - startTime;
        doTime > 1e3 && utils.slowReport({
          key: 'apiCallback',
          cost: doTime,
          extend: ext
        });
      } catch (e) {
        utils.thirdErrorReport({
          error: e,
          extend: ext
        });
      }
      return res;
    };
  },
  slowReport: function slowReport(params) {
    var key = params.key,
        cost = params.cost,
        extend = params.extend,
        force = params.force,
        slowValueType = errorType.SlowValueType[key],
        now = Date.now();
    // 指定类型 强制或上报间隔大于＝指定阀值 extend类型数不超出阀值&当前extend上报数不超出阀值
    var flag = slowValueType && (force || !(now - slowReportTime < slowReportThreshold)) && !(Object.keys(slowReportMap).length > slowReportValueLength || (slowReportMap[extend] || (slowReportMap[extend] = 0), slowReportMap[extend]++, slowReportMap[extend] > slowReportLength));
    if (flag) {
      slowReportTime = now;
      var value = cost + ',' + encodeURIComponent(extend) + ',' + slowValueType;
      utils.reportKeyValue({
        key: 'Slow',
        value: value,
        force: !0
      });
    }
  },
  speedReport: function speedReport(params) {
    var key = params.key,
        data = params.data,
        timeMark = params.timeMark,
        force = params.force,
        SpeedValueType = errorType.SpeedValueType[key],
        now = Date.now(),
        dataLength = 0,
        nativeTime = timeMark.nativeTime,
        flag = SpeedValueType && (force || !(now - (speedReportMap[SpeedValueType] || 0) < speedReportThreshold)) && timeMark.startTime && timeMark.endTime && (SpeedValueType != 1 && SpeedValueType != 2 || nativeTime);
    if (flag) {
      data && (dataLength = JSON.stringify(data).length);
      speedReportMap[SpeedValueType] = now;
      var value = SpeedValueType + ',' + timeMark.startTime + ',' + nativeTime + ',' + nativeTime + ',' + timeMark.endTime + ',' + dataLength;
      utils.reportKeyValue({
        key: 'Speed',
        value: value,
        force: true
      });
    }
  },
  reportKeyValue: function reportKeyValue(params) {
    var key = params.key,
        value = params.value,
        force = params.force;
    errorType.KeyValueType[key] && (!force && Date.now() - reportKeyTimePreTime < reportKeyTLThreshold || (reportKeyTimePreTime = Date.now(), reportKeyValues.push({
      key: errorType.KeyValueType[key],
      value: value
    }), reportKeyValues.length >= reportKeyValueLengthThreshold && _reportKeyValue()));
  },
  reportIDKey: function reportIDKey(params) {
    var id = params.id,
        key = params.key,
        force = params.force;
    errorType.IDKeyType[key] && (!force && Date.now() - reportIDKeyPreTime < reportIDKeyTLThreshold || (reportIDKeyPreTime = Date.now(), reportIDKeys.push({
      id: id || isIOS ? '356' : '358',
      key: errorType.IDKeyType[key],
      value: 1
    }), reportIDKeys.length >= reportIDKeyLength && _reportIDKey()));
  },
  thirdErrorReport: function thirdErrorReport(params) {
    var error = params.error,
        extend = params.extend;
    utils.errorReport({
      key: 'thirdScriptError',
      error: error,
      extend: extend
    });
  },
  errorReport: function errorReport(params) {
    var data = {},
        error = params.error || {},
        extend = params.extend;
    data.msg = extend ? error.message + ';' + extend : error.message;
    data.stack = error.stack;
    if (errorType.ErrorType[params.key]) {
      data.key = params.key;
    } else {
      data.key = 'unknowErr';
    }
    jsBridge.publish('H5_LOG_MSG', { event: logEventName, desc: data }, [params.webviewId || '']);
  },
  log: function log(_log, debug) {
    _log && typeof _log === 'string' && (!debug && Date.now() - logPreTime < logTLThreshold || (logPreTime = Date.now(), systemLogs.push(_log + ''), systemLogs.length >= systemLogLength && systemLog()));
  },
  submit: function submit() {
    Date.now() - submitPreTime < submitTLThreshold || (submitPreTime = Date.now(), _reportIDKey(), _reportKeyValue(), systemLog());
  },
  registerErrorListener: function registerErrorListener(fn) {
    typeof fn === 'function' && (errListenerFns = fn);
  },
  unRegisterErrorListener: function unRegisterErrorListener() {
    errListenerFns = function errListenerFns() {};
  },
  triggerErrorMessage: function triggerErrorMessage(params) {
    errListenerFns(params);
  }
};
var defineObj = {};
for (var key in utils) {
  _defindGeter(key);
}

typeof window !== 'undefined' && (window.onbeforeunload = function () {
  utils.submit();
});
window.Reporter = defineObj;
module.exports = defineObj;

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
var IDKeyType = exports.IDKeyType = {
    login: 1,
    login_cancel: 2,
    login_fail: 3,
    request_fail: 4,
    connectSocket_fail: 5,
    closeSocket_fail: 6,
    sendSocketMessage_fail: 7,
    uploadFile_fail: 8,
    downloadFile_fail: 9,
    redirectTo_fail: 10,
    navigateTo_fail: 11,
    navigateBack_fail: 12,
    appServiceSDKScriptError: 13,
    webviewSDKScriptError: 14,
    jsEnginScriptError: 15,
    thirdScriptError: 16,
    webviewScriptError: 17,
    exparserScriptError: 18,
    startRecord: 19,
    startRecord_fail: 20,
    getLocation: 21,
    getLocation_fail: 22,
    chooseLocation: 23,
    chooseLocation_fail: 24,
    openAddress: 25,
    openAddress_fail: 26,
    openLocation: 27,
    openLocation_fail: 28,
    makePhoneCall: 29,
    makePhoneCall_fail: 30,
    operateWXData: 31,
    operateWXData_fail: 32,
    checkLogin: 33,
    checkLogin_fail: 34,
    refreshSession: 35,
    refreshSession_fail: 36,
    chooseVideo: 37,
    chooseVideo_fail: 38,
    chooseImage: 39,
    chooseImage_fail: 40,
    verifyPaymentPassword: 41,
    verifyPaymentPassword_fail: 42,
    requestPayment: 43,
    requestPayment_fail: 44,
    bindPaymentCard: 45,
    bindPaymentCard_fail: 46,
    requestPaymentToBank: 47,
    requestPaymentToBank_fail: 48,
    openDocument: 49,
    openDocument_fail: 50,
    chooseContact: 51,
    chooseContact_fail: 52,
    operateMusicPlayer: 53,
    operateMusicPlayer_fail: 54,
    getMusicPlayerState_fail: 55,
    playVoice_fail: 56,
    setNavigationBarTitle_fail: 57,
    switchTab_fail: 58,
    getImageInfo_fail: 59,
    enableCompass_fail: 60,
    enableAccelerometer_fail: 61,
    getStorage_fail: 62,
    setStorage_fail: 63,
    clearStorage_fail: 64,
    removeStorage_fail: 65,
    getStorageInfo_fail: 66,
    getStorageSync_fail: 67,
    setStorageSync_fail: 68,
    addCard_fail: 69,
    openCard_fail: 70
};
var KeyValueType = exports.KeyValueType = {
    Speed: "13544",
    Error: "13582",
    Slow: "13968"
};
var SpeedValueType = exports.SpeedValueType = {
    webview2AppService: 1,
    appService2Webview: 2,
    funcReady: 3,
    firstGetData: 4,
    firstRenderTime: 5,
    reRenderTime: 6,
    forceUpdateRenderTime: 7,
    appRoute2newPage: 8,
    newPage2pageReady: 9,
    thirdScriptRunTime: 10,
    pageframe: 11,
    WAWebview: 12
};
var SlowValueType = exports.SlowValueType = {
    apiCallback: 1,
    pageInvoke: 2
};
var ErrorType = exports.ErrorType = {
    appServiceSDKScriptError: 1,
    webviewSDKScriptError: 2,
    jsEnginScriptError: 3,
    thirdScriptError: 4,
    webviewScriptError: 5,
    exparserScriptError: 6
};

/***/ }),
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */,
/* 19 */,
/* 20 */,
/* 21 */,
/* 22 */,
/* 23 */,
/* 24 */,
/* 25 */,
/* 26 */,
/* 27 */,
/* 28 */,
/* 29 */,
/* 30 */,
/* 31 */,
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; // Canvas Context API


var _utils = __webpack_require__(0);

var _utils2 = _interopRequireDefault(_utils);

var _canvas = __webpack_require__(33);

var _canvas2 = _interopRequireDefault(_canvas);

var _predefinedColor = __webpack_require__(131);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function notifyCurrentRoutetoContext(url) {
    curUrl = url;
}

function isNum(e) {
    return "number" == typeof e;
}

function parseColorValue(colorStr) {
    var matchArr = null;
    if (null != (matchArr = /^#([0-9|A-F|a-f]{6})$/.exec(colorStr))) {
        var red = parseInt(matchArr[1].slice(0, 2), 16),
            green = parseInt(matchArr[1].slice(2, 4), 16),
            blue = parseInt(matchArr[1].slice(4), 16);
        return [red, green, blue, 255];
    }

    if (null != (matchArr = /^rgb\((.+)\)$/.exec(colorStr))) {
        return matchArr[1].split(",").map(function (e) {
            return parseInt(e.trim());
        }).concat(255);
    }

    if (null != (matchArr = /^rgba\((.+)\)$/.exec(colorStr))) {
        return matchArr[1].split(",").map(function (e, t) {
            return 3 == t ? Math.floor(255 * parseFloat(e.trim())) : parseInt(e.trim());
        });
    }

    var color = colorStr.toLowerCase();

    if (_predefinedColor.predefinedColor.hasOwnProperty(color)) {
        matchArr = /^#([0-9|A-F|a-f]{6})$/.exec(_predefinedColor.predefinedColor[color]);
        var red = parseInt(matchArr[1].slice(0, 2), 16),
            green = parseInt(matchArr[1].slice(2, 4), 16),
            blue = parseInt(matchArr[1].slice(4), 16);
        return [red, green, blue, 255];
    }

    console.group("非法颜色: " + colorStr);
    console.error("不支持颜色：" + colorStr);
    console.groupEnd();
}

function deepCopy(obj) {
    //复制对象
    if (Array.isArray(obj)) {
        var res = [];
        obj.forEach(function (e) {
            res.push(deepCopy(e));
        });
        return res;
    }
    if ("object" == (typeof obj === 'undefined' ? 'undefined' : _typeof(obj))) {
        var res = {};
        for (var n in obj) {
            res[n] = deepCopy(obj[n]);
        }return res;
    }
    return obj;
}

var transformAndOthersAPI = ["scale", "rotate", "translate", "save", "restore"],
    drawingAPI = ["drawImage", "fillText", "fill", "stroke", "fillRect", "strokeRect", "clearRect"],
    drawPathAPI = ["beginPath", "moveTo", "lineTo", "rect", "arc", "quadraticCurveTo", "bezierCurveTo", "closePath"],
    styleAPI = ["setFillStyle", "setStrokeStyle", "setGlobalAlpha", "setShadow", "setFontSize", "setLineCap", "setLineJoin", "setLineWidth", "setMiterLimit"],
    curUrl = "";

var ColorStop = function () {
    function ColorStop(type, data) {
        _classCallCheck(this, ColorStop);

        this.type = type;
        this.data = data;
        this.colorStop = [];
    }

    _createClass(ColorStop, [{
        key: 'addColorStop',
        value: function addColorStop(e, t) {
            this.colorStop.push([e, parseColorValue(t)]);
        }
    }]);

    return ColorStop;
}();

var Context = function () {
    function Context(t) {
        _classCallCheck(this, Context);

        this.actions = [];
        this.path = [];
        this.canvasId = t;
    }

    _createClass(Context, [{
        key: 'getActions',
        value: function getActions() {
            var actions = deepCopy(this.actions);
            this.actions = [];
            this.path = [];
            return actions;
        }
    }, {
        key: 'clearActions',
        value: function clearActions() {
            this.actions = [];
            this.path = [];
        }
    }, {
        key: 'draw',
        value: function draw() {
            var reserve = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                canvasId = this.canvasId,
                actions = deepCopy(this.actions);
            this.actions = [];
            this.path = [];
            _canvas2.default.drawCanvas({
                canvasId: canvasId,
                actions: actions,
                reserve: reserve
            });
        }
    }, {
        key: 'createLinearGradient',
        value: function createLinearGradient(e, t, n, o) {
            return new ColorStop("linear", [e, t, n, o]);
        }
    }, {
        key: 'createCircularGradient',
        value: function createCircularGradient(e, t, n) {
            return new ColorStop("radial", [e, t, n]);
        }
    }]);

    return Context;
}();

[].concat(transformAndOthersAPI, drawingAPI).forEach(function (apiName) {
    "fill" == apiName || "stroke" == apiName ? Context.prototype[apiName] = function () {
        this.actions.push({
            method: apiName + "Path",
            data: deepCopy(this.path)
        });
    } : "fillRect" === apiName ? Context.prototype[apiName] = function (e, t, n, o) {
        this.actions.push({
            method: "fillPath",
            data: [{
                method: "rect",
                data: [e, t, n, o]
            }]
        });
    } : "strokeRect" === apiName ? Context.prototype[apiName] = function (e, t, n, o) {
        this.actions.push({
            method: "strokePath",
            data: [{
                method: "rect",
                data: [e, t, n, o]
            }]
        });
    } : "fillText" == apiName ? Context.prototype[apiName] = function (t, n, o) {
        this.actions.push({
            method: apiName,
            data: [t.toString(), n, o]
        });
    } : "drawImage" == apiName ? Context.prototype[apiName] = function (t, n, o, r, a) {
        //"devtools" == utils.getPlatform() || /wdfile:\/\//.test(t) || (t = utils.getRealRoute(curUrl, t).replace(/.html$/, "")),
        isNum(r) && isNum(a) ? data = [t, n, o, r, a] : data = [t, n, o], this.actions.push({
            method: apiName,
            data: data
        });
    } : Context.prototype[apiName] = function () {
        this.actions.push({
            method: apiName,
            data: [].slice.apply(arguments)
        });
    };
});
drawPathAPI.forEach(function (apiName) {
    "beginPath" == apiName ? Context.prototype[apiName] = function () {
        this.path = [];
    } : "lineTo" == apiName ? Context.prototype.lineTo = function () {
        0 == this.path.length ? this.path.push({
            method: "moveTo",
            data: [].slice.apply(arguments)
        }) : this.path.push({
            method: "lineTo",
            data: [].slice.apply(arguments)
        });
    } : Context.prototype[apiName] = function () {
        this.path.push({
            method: apiName,
            data: [].slice.apply(arguments)
        });
    };
});
styleAPI.forEach(function (apiName) {
    "setFillStyle" == apiName || "setStrokeStyle" == apiName ? Context.prototype[apiName] = function () {
        var params = arguments[0];
        "string" == typeof params ? this.actions.push({
            method: apiName,
            data: ["normal", parseColorValue(params)]
        }) : "object" == (typeof params === 'undefined' ? 'undefined' : _typeof(params)) && params instanceof ColorStop && this.actions.push({
            method: apiName,
            data: [params.type, params.data, params.colorStop]
        });
    } : "setGlobalAlpha" === apiName ? Context.prototype[apiName] = function () {
        var data = [].slice.apply(arguments, [0, 1]);
        data[0] = Math.floor(255 * parseFloat(data[0]));
        this.actions.push({
            method: apiName,
            data: data
        });
    } : "setShadow" == apiName ? Context.prototype[apiName] = function () {
        var data = [].slice.apply(arguments, [0, 4]);
        data[3] = parseColorValue(data[3]);
        this.actions.push({
            method: apiName,
            data: data
        });
    } : Context.prototype[apiName] = function () {
        this.actions.push({
            method: apiName,
            data: [].slice.apply(arguments, [0, 1])
        });
    };
});

exports.default = {
    notifyCurrentRoutetoContext: notifyCurrentRoutetoContext,
    Context: Context
};

/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _bridge = __webpack_require__(2);

var _bridge2 = _interopRequireDefault(_bridge);

var _context = __webpack_require__(32);

var _context2 = _interopRequireDefault(_context);

var _utils = __webpack_require__(0);

var _utils2 = _interopRequireDefault(_utils);

var _EventEmitter = __webpack_require__(6);

var _EventEmitter2 = _interopRequireDefault(_EventEmitter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function canvasDesString(webviewID, canvasId) {
    return webviewID + "canvas" + canvasId;
}

function clearOldWebviewCanvas() {
    for (var key in canvasIDs) {
        if (0 == key.indexOf(webviewID + "canvas")) {
            canvasIDs[key];
            delete canvasIDs[key];
        }
    }
}

function notifyWebviewIdtoCanvas(e) {
    webviewID = e;
}

function invokeDrawCanvas(canvasId, actions) {
    var reserve = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
    /*
            success = arguments[3],
            fail = arguments[4],
            complte = arguments[5],
            platform = utils.getPlatform();
        "ios" == platform || "android" == platform ?
            ServiceJSBridge.invoke("drawCanvas", {
                canvasId: canvasId,
                reserve: reserve,
                actions: actions
            },
            function (e) {
                e.errMsg && /ok/.test(e.errMsg) ?
                "function" == typeof success && success(e) :
                "function" == typeof fail && fail(e)
                "function" == typeof complte && complte(e)
            }) :
    */
    ServiceJSBridge.publish("canvas" + canvasId + "actionsChanged", { actions: actions, reserve: reserve }, [webviewID]);
}

function drawCanvas(params) {
    var canvasId = params.canvasId,
        actions = params.actions,
        reserve = params.reserve,
        success = params.success,
        fail = params.fail,
        complete = params.complete;
    if (canvasId && Array.isArray(actions)) {
        var key = canvasDesString(webviewID, canvasId);
        if ("number" == typeof canvasIDs[key]) {
            var canvasId = canvasIDs[key];
            invokeDrawCanvas(canvasId, actions, reserve, success, fail, complete);
        } else {
            canvasOptions[key] = canvasOptions[key] || [];
            canvasOptions[key] = canvasOptions[key].concat({
                actions: actions,
                reserve: reserve,
                success: success,
                fail: fail,
                complete: complete
            });
        }
    }
}

function canvasToTempFilePathImpl(obj) {

    ServiceJSBridge.subscribe("onCanvasToDataUrl_" + obj.canvasId, function (params) {
        var dataUrl = params.dataUrl;
        _bridge2.default.invokeMethod("base64ToTempFilePath", _utils2.default.assign({ base64Data: dataUrl }, obj), {
            beforeAll: function beforeAll(res) {
                res.errMsg = res.errMsg.replace("base64ToTempFilePath", "canvasToTempFilePath");
            }
        });
    }), _bridge2.default.publish("invokeCanvasToDataUrl_" + obj.canvasId, { canvasId: obj.canvasId });
}

function canvasToTempFilePath(obj) {
    if (obj.canvasId) {
        var key = canvasDesString(webviewID, obj.canvasId);
        if ("number" == typeof canvasIDs[key]) {
            obj.canvasId = canvasIDs[key];
            canvasToTempFilePathImpl(obj);
        } else {
            var res = {
                errMsg: "canvasToTempFilePath: fail canvas is empty"
            };
            "function" == typeof obj.fail && obj.fail(res), "function" == typeof obj.complete && obj.complete(res);
        }
    }
}

var webviewID = (new _EventEmitter2.default.EventEmitter2(), 0),
    canvasInfo = {},
    canvasIDs = {},
    canvasOptions = {};

ServiceJSBridge.subscribe("canvasInsert", function (event, t) {
    var canvasId = event.canvasId,
        canvasNumber = event.canvasNumber,
        data = event.data,
        key = canvasDesString(webviewID, canvasId);

    canvasInfo[canvasNumber] = {
        lastTouches: [],
        data: data
    };

    canvasIDs[key] = canvasIDs[key] || canvasNumber;

    Array.isArray(canvasOptions[key]) && (canvasOptions[key].forEach(function (e) {
        invokeDrawCanvas(canvasNumber, e.actions, e.reserve, e.success, e.fail, e.complete);
    }), delete canvasOptions[key]);
});

ServiceJSBridge.subscribe("canvasRemove", function (params, t) {
    var canvasId = params.canvasId,
        canvasIndex = canvasDesString(webviewID, canvasId);
    canvasIDs[canvasIndex] && delete canvasIDs[canvasIndex];
});

var createContext = function createContext() {
    return new _context2.default.Context();
},
    createCanvasContext = function createCanvasContext(e) {
    return new _context2.default.Context(e);
};

exports.default = {
    canvasInfo: canvasInfo,
    clearOldWebviewCanvas: clearOldWebviewCanvas,
    notifyWebviewIdtoCanvas: notifyWebviewIdtoCanvas,
    drawCanvas: drawCanvas,
    canvasToTempFilePath: canvasToTempFilePath,
    createContext: createContext,
    createCanvasContext: createCanvasContext
};

/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _utils = __webpack_require__(8);

var _utils2 = _interopRequireDefault(_utils);

var _parsePage = __webpack_require__(137);

var _parsePage2 = _interopRequireDefault(_parsePage);

var _constants = __webpack_require__(143);

var eventDefine = _interopRequireWildcard(_constants);

var _logReport = __webpack_require__(35);

var reportRealtimeAction = _interopRequireWildcard(_logReport);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var getRouteToPage;
var getWebviewIdToPage;
var setWxRouteBegin;
var setWxRoute;
var setWxConfig;
var reset;
var pageHolder;
var getCurrentPages;
var getCurrentPage;

var pageStack = [];
var tabBars = []; //tab栏url列表
var currentPage;
__wxConfig__.tabBar && __wxConfig__.tabBar.list && "object" === _typeof(__wxConfig__.tabBar.list) && "function" == typeof __wxConfig__.tabBar.list.forEach && __wxConfig__.tabBar.list.forEach(function (item) {
    tabBars.push(item.pagePath);
});

var app = {
    appRouteTime: 0,
    newPageTime: 0,
    pageReadyTime: 0
};

var speedReport = function speedReport(key, startTime, endTime) {
    Reporter.speedReport({
        key: key,
        timeMark: {
            startTime: startTime,
            endTime: endTime
        }
    });
};

var pageStackObjs = {};
var pageRegObjs = {}; //key:pathname
var pageIndex = 0;

getCurrentPage = function getCurrentPage() {
    return currentPage;
};
getCurrentPages = function getCurrentPages() {
    var pageArr = [];
    pageStack.forEach(function (pageObj) {
        pageArr.push(pageObj.page);
    });
    return pageArr;
};
pageHolder = function pageHolder(pageObj) {
    //Page 接口
    if (!__wxRouteBegin) {
        throw _utils2.default.error("Page 注册错误", "Please do not register multiple Pages in " + __wxRoute + ".js");
        new _utils2.default.AppServiceEngineKnownError("Please do not register multiple Pages in " + __wxRoute + ".js");
    }

    __wxRouteBegin = !1;
    var pages = __wxConfig__.pages,
        pagePath = pages[pageIndex];
    pageIndex++;
    if ("Object" !== _utils2.default.getDataType(pageObj)) {
        throw _utils2.default.error("Page 注册错误", "Options is not object: " + JSON.stringify(pageObj) + " in " + __wxRoute + ".js");
        new _utils2.default.AppServiceEngineKnownError("Options is not object: " + JSON.stringify(pageObj) + " in " + __wxRoute + ".js");
    }
    _utils2.default.info("Register Page: " + pagePath);
    pageRegObjs[pagePath] = pageObj;
};
var pageInitData = _utils2.default.surroundByTryCatch(function (pageObj, webviewId) {
    _utils2.default.info("Update view with init data");
    var ext = {};
    ext.webviewId = webviewId, ext.enablePullUpRefresh = pageObj.hasOwnProperty("onReachBottom");
    var params = {
        data: {
            data: pageObj.data,
            ext: ext,
            options: {
                firstRender: !0
            }
        }
    };
    _utils2.default.publish("appDataChange", params, [webviewId]);
});
var pageParse = function pageParse(routePath, webviewId, params) {
    //解析page e:pagepath t:webviewId params:
    var curPageObj = undefined;
    routePath = routePath.replace(/\.htm[^\.]*$/, '');
    if (pageRegObjs.hasOwnProperty(routePath)) {
        curPageObj = pageRegObjs[routePath];
    } else {
        _utils2.default.warn("Page route 错误", "Page[" + routePath + "] not found. May be caused by: 1. Forgot to add page route in app.json. 2. Invoking Page() in async task.");
        curPageObj = {};
    }
    app.newPageTime = Date.now();
    var page = new _parsePage2.default(curPageObj, webviewId, routePath);
    pageInitData(page, webviewId);
    if (_utils2.default.isDevTools()) {
        __wxAppData[routePath] = page.data;
        __wxAppData[routePath].__webviewId__ = webviewId;
        _utils2.default.publish(eventDefine.UPDATE_APP_DATA);
    }
    currentPage = {
        page: page,
        webviewId: webviewId,
        route: routePath
    };
    pageStack.push(currentPage);
    page.onLoad(params);
    page.onShow();
    pageStackObjs[webviewId] = {
        page: page,
        route: routePath
    };
    reportRealtimeAction.triggerAnalytics("enterPage", page);
    speedReport("appRoute2newPage", app.appRouteTime, app.newPageTime);
};

var pageHide = function pageHide(pageItem) {
    //执行page hide event
    pageItem.page.onHide();
    reportRealtimeAction.triggerAnalytics("leavePage", pageItem.page);
};

var pageUnload = function pageUnload(pageItem) {
    //do page unload
    pageItem.page.onUnload();
    _utils2.default.isDevTools() && (delete __wxAppData[pageItem.route], _utils2.default.publish(eventDefine.UPDATE_APP_DATA));
    delete pageStackObjs[pageItem.webviewId];
    pageStack = pageStack.slice(0, pageStack.length - 1);
    reportRealtimeAction.triggerAnalytics("leavePage", pageItem.page);
};

var isTabBarsPage = function isTabBarsPage(pageItem) {
    //
    return tabBars.indexOf(pageItem.route) !== -1 || tabBars.indexOf(pageItem.route + ".html") !== -1;
};

var skipPage = function skipPage(routePath, pWebViewId, pageParams, pApiKey) {
    //打开、跳转页面
    _utils2.default.info("On app route: " + routePath);
    app.appRouteTime = Date.now();
    if ("navigateTo" === pApiKey) {
        currentPage && pageHide(currentPage);
        pageStackObjs.hasOwnProperty(pWebViewId) ? _utils2.default.error("Page route 错误(system error)", "navigateTo with an already exist webviewId " + pWebViewId) : pageParse(routePath, pWebViewId, pageParams);
    } else if ("redirectTo" === pApiKey) {
        currentPage && pageUnload(currentPage);
        pageStackObjs.hasOwnProperty(pWebViewId) ? _utils2.default.error("Page route 错误(system error)", "redirectTo with an already exist webviewId " + pWebViewId) : pageParse(routePath, pWebViewId, pageParams);
    } else if ("navigateBack" === pApiKey) {
        for (var isExist = !1, i = pageStack.length - 1; i >= 0; i--) {
            var pageItem = pageStack[i];
            if (pageItem.webviewId === pWebViewId) {
                isExist = !0;
                currentPage = pageItem;
                pageItem.page.onShow();
                reportRealtimeAction.triggerAnalytics("enterPage", pageItem);
                break;
            }
            pageUnload(pageItem);
        }
        isExist || _utils2.default.error("Page route 错误(system error)", "navigateBack with an unexist webviewId " + pWebViewId);
    } else if ("reLaunch" === pApiKey) {
        currentPage && pageUnload(currentPage);
        pageStackObjs.hasOwnProperty(pWebViewId) ? _utils2.default.error("Page route 错误(system error)", "redirectTo with an already exist webviewId " + pWebViewId) : pageParse(routePath, pWebViewId, pageParams);
    } else if ("switchTab" === pApiKey) {
        for (var onlyOnePage = !0; pageStack.length > 1;) {
            pageUnload(pageStack[pageStack.length - 1]);
            onlyOnePage = !1;
        }
        if (pageStack[0].webviewId === pWebViewId) {
            currentPage = pageStack[0];
            onlyOnePage || currentPage.page.onShow();
        } else if (isTabBarsPage(pageStack[0]) ? onlyOnePage && pageHide(pageStack[0]) : pageUnload(pageStack[0]), pageStackObjs.hasOwnProperty(pWebViewId)) {
            var pageObj = pageStackObjs[pWebViewId].page;
            currentPage = {
                webviewId: pWebViewId,
                route: routePath,
                page: pageObj
            };
            pageStack = [currentPage];
            pageObj.onShow();
            reportRealtimeAction.triggerAnalytics("enterPage", pageObj);
        } else {
            pageStack = [];
            pageParse(routePath, pWebViewId, pageParams);
        }
    } else {
        "appLaunch" === pApiKey ? pageStackObjs.hasOwnProperty(pWebViewId) ? _utils2.default.error("Page route 错误(system error)", "appLaunch with an already exist webviewId " + pWebViewId) : pageParse(routePath, pWebViewId, pageParams) : _utils2.default.error("Page route 错误(system error)", "Illegal open type: " + pApiKey);
    }
};

var doWebviewEvent = function doWebviewEvent(pWebviewId, pEvent, params) {
    //do dom ready
    if (!pageStackObjs.hasOwnProperty(pWebviewId)) {
        return _utils2.default.warn("事件警告", "OnWebviewEvent: " + pEvent + ", WebviewId: " + pWebviewId + " not found");
    }
    var pageItem = pageStackObjs[pWebviewId],
        pageObj = pageItem.page;
    return pEvent === eventDefine.DOM_READY_EVENT ? (app.pageReadyTime = Date.now(), _utils2.default.info("Invoke event onReady in page: " + pageItem.route), pageObj.onReady(), reportRealtimeAction.triggerAnalytics("pageReady", pageObj), void speedReport("newPage2pageReady", app.newPageTime, app.pageReadyTime)) : (_utils2.default.info("Invoke event " + pEvent + " in page: " + pageItem.route), pageObj.hasOwnProperty(pEvent) ? _utils2.default.safeInvoke.call(pageObj, pEvent, params) : _utils2.default.warn("事件警告", "Do not have " + pEvent + " handler in current page: " + pageItem.route + ". Please make sure that " + pEvent + " handler has been defined in " + pageItem.route + ", or " + pageItem.route + " has been added into app.json"));
};

var pullDownRefresh = function pullDownRefresh(pWebviewId) {
    //do pulldownrefresh
    pageStackObjs.hasOwnProperty(pWebviewId) || _utils2.default.warn("事件警告", "onPullDownRefresh WebviewId: " + pWebviewId + " not found");
    var pageItem = pageStackObjs[pWebviewId],
        pageObj = pageItem.page;
    if (pageObj.hasOwnProperty("onPullDownRefresh")) {
        _utils2.default.info("Invoke event onPullDownRefresh in page: " + pageItem.route);
        _utils2.default.safeInvoke.call(pageObj, "onPullDownRefresh");
        reportRealtimeAction.triggerAnalytics("pullDownRefresh", pageObj);
    }
};

var invokeShareAppMessage = function invokeShareAppMessage(params, pWebviewId) {
    //invoke event onShareAppMessage
    var shareParams = params,
        pageItem = pageStackObjs[pWebviewId],
        pageObj = pageItem.page,
        eventName = "onShareAppMessage";
    if (pageObj.hasOwnProperty(eventName)) {
        _utils2.default.info("Invoke event onShareAppMessage in page: " + pageItem.route);
        var shareObj = _utils2.default.safeInvoke.call(pageObj, eventName) || {};
        shareParams.title = shareObj.title || params.title;
        shareParams.desc = shareObj.desc || params.desc;
        shareParams.path = shareObj.path ? _utils2.default.addHtmlSuffixToUrl(shareObj.path) : params.path;
        shareParams.path.length > 0 && "/" === shareParams.path[0] && (shareParams.path = shareParams.path.substr(1));
        shareParams.success = shareObj.success;
        shareParams.cancel = shareObj.cancel;
        shareParams.fail = shareObj.fail;
        shareParams.complete = shareObj.complete;
    }
    return shareParams;
};
wd.onAppRoute(_utils2.default.surroundByTryCatch(function (params) {
    var path = params.path,
        webviewId = params.webviewId,
        query = params.query || {},
        openType = params.openType;
    skipPage(path, webviewId, query, openType);
}), "onAppRoute");

wd.onWebviewEvent(_utils2.default.surroundByTryCatch(function (params) {
    var webviewId = params.webviewId,
        eventName = params.eventName,
        data = params.data;
    return doWebviewEvent(webviewId, eventName, data);
}, "onWebviewEvent"));

ServiceJSBridge.on("onPullDownRefresh", _utils2.default.surroundByTryCatch(function (e, pWebViewId) {
    pullDownRefresh(pWebViewId);
}, "onPullDownRefresh"));

var shareAppMessage = function shareAppMessage(params, webviewId) {
    var shareInfo = invokeShareAppMessage(params, webviewId);
    ServiceJSBridge.invoke("shareAppMessage", shareInfo, function (res) {
        / ^shareAppMessage: ok /.test(res.errMsg) && "function" == typeof shareInfo.success ? shareInfo.success(res) : /^shareAppMessage:cancel/.test(res.errMsg) && "function" == typeof shareInfo.cancel ? shareInfo.cancel(res) : /^shareAppMessage:fail/.test(res.errMsg) && "function" == typeof shareInfo.fail && shareInfo.fail(res), //bug?? 原代码：shareInfo.fail && shareInfo.cancel(res)
        "function" == typeof shareInfo.complete && shareInfo.complete(res);
    });
};

ServiceJSBridge.on("onShareAppMessage", _utils2.default.surroundByTryCatch(shareAppMessage, "onShareAppMessage"));
reset = function reset() {
    currentPage = undefined;
    pageStackObjs = {};
    pageRegObjs = {};
    pageStack = [];
    pageIndex = 0;
};
setWxConfig = function setWxConfig(e) {
    __wxConfig__ = e;
};
setWxRoute = function setWxRoute(e) {
    __wxRoute = e;
};
setWxRouteBegin = function setWxRouteBegin(e) {
    __wxRouteBegin = e;
};
getWebviewIdToPage = function getWebviewIdToPage() {
    return pageStackObjs;
};
getRouteToPage = function getRouteToPage() {
    return pageRegObjs;
};

exports.default = {
    getRouteToPage: getRouteToPage,
    getWebviewIdToPage: getWebviewIdToPage,
    setWxRouteBegin: setWxRouteBegin,
    setWxRoute: setWxRoute,
    setWxConfig: setWxConfig,
    reset: reset,
    pageHolder: pageHolder,
    getCurrentPages: getCurrentPages,
    getCurrentPage: getCurrentPage
};

/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
var triggerAnalytics = exports.triggerAnalytics = function triggerAnalytics(eventName, pageObj, desc) {
    var data = {};
    if (pageObj) {
        data.pageRoute = pageObj.__route__;
    }
    if (desc) {
        data.desc = desc;
    }
    ServiceJSBridge.publish("H5_LOG_MSG", { event: eventName, desc: data }, [pageObj && pageObj.__wxWebviewId__ || '']);
};

/***/ }),
/* 36 */,
/* 37 */,
/* 38 */,
/* 39 */,
/* 40 */,
/* 41 */,
/* 42 */,
/* 43 */,
/* 44 */,
/* 45 */,
/* 46 */,
/* 47 */,
/* 48 */,
/* 49 */,
/* 50 */,
/* 51 */,
/* 52 */,
/* 53 */,
/* 54 */,
/* 55 */,
/* 56 */,
/* 57 */,
/* 58 */,
/* 59 */,
/* 60 */,
/* 61 */,
/* 62 */,
/* 63 */,
/* 64 */,
/* 65 */,
/* 66 */,
/* 67 */,
/* 68 */,
/* 69 */,
/* 70 */,
/* 71 */,
/* 72 */,
/* 73 */,
/* 74 */,
/* 75 */,
/* 76 */,
/* 77 */,
/* 78 */,
/* 79 */,
/* 80 */,
/* 81 */,
/* 82 */,
/* 83 */,
/* 84 */,
/* 85 */,
/* 86 */,
/* 87 */,
/* 88 */,
/* 89 */,
/* 90 */,
/* 91 */,
/* 92 */,
/* 93 */,
/* 94 */,
/* 95 */,
/* 96 */,
/* 97 */,
/* 98 */,
/* 99 */,
/* 100 */,
/* 101 */,
/* 102 */,
/* 103 */,
/* 104 */,
/* 105 */,
/* 106 */,
/* 107 */,
/* 108 */,
/* 109 */,
/* 110 */,
/* 111 */,
/* 112 */,
/* 113 */,
/* 114 */,
/* 115 */,
/* 116 */,
/* 117 */,
/* 118 */,
/* 119 */,
/* 120 */,
/* 121 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(122);

__webpack_require__(123);

__webpack_require__(124);

__webpack_require__(13);

__webpack_require__(125);

__webpack_require__(136);

__webpack_require__(145);

/***/ }),
/* 122 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 123 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Created by pengguanfa on 2017/10/25.
 * 扩展api配置
 */
window.HeraExtApiConf = [{
  name: 'testApi',
  fn: function fn(params) {
    this.showToast(params);
  },
  params: {
    title: ''
  }
}, {
  name: 'openPage',
  params: {
    name: '',
    param: {}
  }
}, {
  name: 'getCookie',
  params: {
    host: ''
  }
}, {
  name: 'openLink',
  params: {
    url: ''
  }
}];

/***/ }),
/* 124 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


// 在 iOS 上，小程序的 javascript 代码是运行在 JavaScriptCore 中，是由 WKWebView 来渲染的，环境有 iOS8、iOS9、iOS10
// 在 Android 上，小程序的 javascript 代码是通过 X5 JSCore来解析，是由 X5 基于 Mobile Chrome 37 内核来渲染的
// 在 开发工具上， 小程序的 javascript 代码是运行在 nwjs 中，是由 Chrome Webview 来渲染的

!function (global) {
  // ServiceJSBridge 对象兼容层
  if (typeof logxx === 'function' && logxx('jsbridge start'), !global.ServiceJSBridge) {
    var hasDocument = global.hasOwnProperty('document'),
        isIOS = !1,
        callbacks = {},
        callbackIndex = 0,
        defaultEventHandlers = {},
        eventPrefix = 'custom_event_',
        handlers = {},
        PROTOCAL = 'wdhybrid',
        IFRAME_PREFIX = 'hybridjsbrige_';
    if (hasDocument) {
      var userAgent = global.navigator.userAgent,
          isAndroid = userAgent.indexOf('Android') != -1;
      isIOS = !isAndroid;
    }
    var utils = {
      parseData: function parseData(str) {
        var result;
        if (str && typeof str === 'string') {
          try {
            result = JSON.parse(str);
          } catch (e) {
            result = {
              status: {
                code: 1,
                msg: 'PARAM_PARSE_ERROR'
              }
            };
          }
        } else {
          result = str || {};
        }
        return result;
      }
    };
    var postMessage = function postMessage(event, paramsString, callbackId) {
      // postMessage
      if (isIOS) {
        global.webkit.messageHandlers.invokeHandler.postMessage({
          C: event,
          paramsString: paramsString,
          callbackId: callbackId
        });
      } else {
        var jsCoreHandleResult = HeraJSCore.invokeHandler(event, paramsString, callbackId);
        if (typeof jsCoreHandleResult !== 'undefined' && typeof callbacks[callbackId] === 'function' && jsCoreHandleResult !== '') {
          try {
            jsCoreHandleResult = JSON.parse(jsCoreHandleResult);
          } catch (e) {
            jsCoreHandleResult = {};
          }
          callbacks[callbackId](jsCoreHandleResult), delete callbacks[callbackId];
        }
      }
    },
        createIframe = function createIframe(uri, sid) {
      var iframe = document.createElement('iframe'),
          iframeId = IFRAME_PREFIX + sid;
      iframe.style.display = 'none';
      iframe.setAttribute('id', iframeId);
      iframe.setAttribute('frameborder', '0');
      iframe.setAttribute('src', uri);
      document.documentElement.appendChild(iframe);
      // this.messageIframe = messageIframe
    },
        retrieveIframe = function retrieveIframe(sid) {
      var iframeId = IFRAME_PREFIX + sid,
          iframe = document.querySelector('#' + iframeId);
      if (iframe) {
        document.documentElement.removeChild(iframe);
      }
    },
        publishHandler = function publishHandler(event, paramsString, webviewIds) {
      // publishHandler
      isIOS ? global.webkit.messageHandlers.publishHandler.postMessage({
        event: event,
        paramsString: paramsString,
        webviewIds: webviewIds
      }) : HeraJSCore.publishHandler(event, paramsString, webviewIds);
    },
        invoke = function invoke(event, params, callback) {
      // postMessage
      var paramsString = JSON.stringify(params || {}),
          callbackId = ++callbackIndex;
      // reportLog(event,params,'','invoke');
      callbacks[callbackId] = callback;
      postMessage(event, paramsString, callbackId);
    },
        invokeCallbackHandler = function invokeCallbackHandler(callbackId, params) {
      var callback = callbacks[callbackId];
      // reportLog('invokeCallbackHandler:'+callbackId,params,'','api2app2service_get');
      typeof callback === 'function' && callback(params), delete callbacks[callbackId];
      if (isIOS) retrieveIframe(callbackId);
    },
        oldCallbackHandler = function oldCallbackHandler(data) {
      // {"bridgeParam":{"action":"call","callbackID":"1468927578039","status":{"status_code":-5,"status_reason":"'module' or 'identifier' is unsupported."}}}
      if (data) {
        if (typeof data === 'string') {
          data = utils.parseData(data);
        }
        var callbackId = data.bridgeParam.callbackID;
        // 延迟是为了避免：
        // 在 ios 中，如果 onComplete 回调中有 alert 等有阻塞作用的代码时，会导致页面“卡死”（Native UI层级覆盖导致点击无效）
        if (callbackId) {
          setTimeout(function () {
            invokeCallbackHandler(callbackId, data.param);
          }, 1);
        }
      }
    },
        publishCallbackHandler = function publishCallbackHandler(callbackId) {
      if (isIOS) retrieveIframe(callbackId);
    },
        on = function on(eventName, handler) {
      defaultEventHandlers[eventName] = handler;
    },
        publish = function publish(eventName, params, webviewIds) {
      // publishHandler
      webviewIds = webviewIds || [];
      var paramsString,
          event = eventPrefix + eventName;

      paramsString = JSON.stringify(params);
      webviewIds = JSON.stringify(webviewIds);
      publishHandler(event, paramsString, webviewIds);
    },
        subscribe = function subscribe(eventName, handler) {
      handlers[eventPrefix + eventName] = handler;
    },
        subscribeHandler = function subscribeHandler(eventName, data, webviewId, reportParams) {
      // 执行注册的回调
      var handler
      // reportLog('subscribeHandler:'+eventName,data,[webviewId||''],'app2view_get');
      ;handler = eventName.indexOf(eventPrefix) != -1 ? handlers[eventName] : defaultEventHandlers[eventName], typeof handler === 'function' && handler(data, webviewId, reportParams);
    };
    global.ServiceJSBridge = {
      invoke: invoke,
      invokeCallbackHandler: invokeCallbackHandler,
      oldCallbackHandler: oldCallbackHandler,
      publishCallbackHandler: publishCallbackHandler,
      on: on,
      publish: publish,
      subscribe: subscribe,
      subscribeHandler: subscribeHandler
    };
  }
}(window);

/***/ }),
/* 125 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _bridge = __webpack_require__(2);

var _bridge2 = _interopRequireDefault(_bridge);

var _utils = __webpack_require__(0);

var _utils2 = _interopRequireDefault(_utils);

var _Animation = __webpack_require__(126);

var _Animation2 = _interopRequireDefault(_Animation);

var _createAudio = __webpack_require__(127);

var _createAudio2 = _interopRequireDefault(_createAudio);

var _createVideo = __webpack_require__(129);

var _createVideo2 = _interopRequireDefault(_createVideo);

var _map = __webpack_require__(130);

var _map2 = _interopRequireDefault(_map);

var _configFlags = __webpack_require__(7);

var _configFlags2 = _interopRequireDefault(_configFlags);

var _context = __webpack_require__(32);

var _context2 = _interopRequireDefault(_context);

var _canvas = __webpack_require__(33);

var _canvas2 = _interopRequireDefault(_canvas);

var _appContextSwitch = __webpack_require__(132);

var _appContextSwitch2 = _interopRequireDefault(_appContextSwitch);

__webpack_require__(133);

__webpack_require__(134);

__webpack_require__(135);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function addGetterForWX(apiKey) {
  WX.__defineGetter__(apiKey, function () {
    return _utils2.default.surroundByTryCatchFactory(apiObj[apiKey], 'wd.' + apiKey);
  });
}

function paramCheck(apiName, params, paramTpl) {
  var res = _utils2.default.paramCheck(params, paramTpl);
  return !res || (logErr(apiName, params, apiName + ':fail parameter error: ' + res), !1);
}

function paramCheckFail(apiName) {
  var res = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
      n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : '',
      errMsg = apiName + ':fail ' + n;
  console.error(errMsg);
  var fail = Reporter.surroundThirdByTryCatch(options.fail || emptyFn, 'at api ' + apiName + ' fail callback function'),
      complete = Reporter.surroundThirdByTryCatch(options.complete || emptyFn, 'at api ' + apiName + ' complete callback function');
  fail({
    errMsg: errMsg
  });
  complete({
    errMsg: errMsg
  });
}

function checkUrl(apiName, params) {
  // 判断当前页面是否在app.json里
  var matchArr = /^(.*)\.html/gi.exec(params.url);
  return !matchArr || __wxConfig__.pages.indexOf(matchArr[1]) !== -1 || (logErr(apiName, params, apiName + ':fail url not in app.json'), !1);
}

typeof logxx === 'function' && logxx('sdk start');

var emptyFn = function emptyFn() {},
    pageData = {},
    currUrl = '',
    SDKVersion = '1.4.2',
    appRouteCallbacks = [],
    appRouteDoneCallback = [],
    pageEventFn = void 0,
    WX = {},
    hasInvokeEnableAccelerometer = !1,
    hasInvokeEnableCompass = !1,
    accelerometerChangeFns = [],
    compassChangeFns = [],
    refreshSessionTimeHander = void 0,
    curWebViewId = void 0,
    currentClipBoardData = void 0,
    loginSourceUrl = '';

_bridge2.default.subscribe('SPECIAL_PAGE_EVENT', function (params) {
  var data = params.data,
      eventName = params.eventName,
      ext = params.ext,
      webViewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  if (data && data.type == 'input' && typeof pageEventFn === 'function') {
    var res = pageEventFn({
      data: data,
      eventName: eventName,
      webviewId: webViewId
    }),
        value = data.detail.value;
    if (ext && ext.setKeyboardValue) {
      if (res === undefined) {} else if (_utils2.default.getDataType(res) === 'Object') {
        var params = {};
        value != res.value && (params.value = res.value + '');
        isNaN(parseInt(res.cursor)) || (params.cursor = parseInt(res.cursor));
        _bridge2.default.publish('setKeyboardValue', params, [webViewId]);
      } else {
        value != res && _bridge2.default.publish('setKeyboardValue', {
          value: res + '',
          cursor: -1
        }, [webViewId]);
      }
    }
  }
});

var logErr = function logErr(apiName) {
  var options = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
      errMsg = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : '';
  console.error(errMsg);
  Reporter.triggerErrorMessage(errMsg);
  var fail = Reporter.surroundThirdByTryCatch(options.fail || emptyFn, 'at api ' + apiName + ' fail callback function'),
      complete = Reporter.surroundThirdByTryCatch(options.complete || emptyFn, 'at api ' + apiName + ' complete callback function');
  fail({
    errMsg: errMsg
  });
  complete({
    errMsg: errMsg
  });
};

var apiObj = {
  // wx对象
  invoke: _bridge2.default.invoke,
  on: _bridge2.default.on,
  drawCanvas: _canvas2.default.drawCanvas,
  createContext: _canvas2.default.createContext,
  createCanvasContext: _canvas2.default.createCanvasContext,
  canvasToTempFilePath: _canvas2.default.canvasToTempFilePath,
  reportIDKey: function reportIDKey(e, t) {},
  reportKeyValue: function reportKeyValue(e, t) {},
  onPullDownRefresh: function onPullDownRefresh(e) {
    console.log('onPullDownRefresh has been removed from api list');
  },
  setNavigationBarColor: function setNavigationBarColor() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    if (paramCheck('setNavigationBarColor', params, {
      frontColor: '',
      backgroundColor: ''
    })) {
      if (['#ffffff', '#000000'].indexOf(params.frontColor) === -1) {
        logErr('setNavigationBarColor', params, 'invalid frontColor "' + params.frontColor + '"');
      }

      params.frontColor === '#ffffff' ? _bridge2.default.invokeMethod('setStatusBarStyle', {
        color: 'white'
      }) : params.frontColor === '#000000' && _bridge2.default.invokeMethod('setStatusBarStyle', {
        color: 'black'
      });

      var t = Object.assign({}, params);
      delete t.alpha;
      _bridge2.default.invokeMethod('setNavigationBarColor', t);
    }
  },
  setNavigationBarTitle: function setNavigationBarTitle() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('setNavigationBarTitle', params, {
      title: ''
    }) && _bridge2.default.invokeMethod('setNavigationBarTitle', params);
  },
  showNavigationBarLoading: function showNavigationBarLoading(e) {
    _bridge2.default.invokeMethod('showNavigationBarLoading', e);
  },
  hideNavigationBarLoading: function hideNavigationBarLoading(e) {
    _bridge2.default.invokeMethod('hideNavigationBarLoading', e);
  },
  stopPullDownRefresh: function stopPullDownRefresh(e) {
    _bridge2.default.invokeMethod('stopPullDownRefresh', e);
  },
  redirectTo: function redirectTo(params) {
    arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    if (paramCheck('redirectTo', params, { url: '' })) {
      params.url = _utils2.default.getRealRoute(currUrl, params.url);
      params.url = _utils2.default.encodeUrlQuery(params.url);
      checkUrl('redirectTo', params) && _bridge2.default.invokeMethod('redirectTo', params, {
        afterSuccess: function afterSuccess() {
          currUrl = params.url;
        }
      });
    }
  },
  // 关闭所有页面，打开到应用内的某个页面
  reLaunch: function reLaunch(params) {
    arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    if (_utils2.default.defaultRunningStatus != 'active') {
      return paramCheckFail('reLaunch', params, 'can not invoke reLaunch in background');
    }
    if (paramCheck('reLaunch', params, { url: '' })) {
      params.url = _utils2.default.getRealRoute(currUrl, params.url);
      params.url = _utils2.default.encodeUrlQuery(params.url);
      checkUrl('reLaunch', params) && _bridge2.default.invokeMethod('reLaunch', params, {
        afterSuccess: function afterSuccess() {
          currUrl = params.url;
        },
        afterFail: function afterFail() {
          console.log('failed');
        }
      });
    }
  },
  createSelectorQuery: function createSelectorQuery(e) {
    // 返回一个SelectorQuery对象实例
    var t = null;
    if (e && e.page) {
      t.e.page__wxWebViewId__;
    } else {
      var n = getCurrentPages();
      t = n[n.length - 1].__wxWebviewId__;
    }
    console.log(111);
    return new _utils2.default.wxQuerySelector(t);
  },

  pageScrollTo: function pageScrollTo(param) {
    // 将页面滚动到目标位置
    var target = getCurrentPages(),
        viewId = target[target.length - 1].__wxWebviewId__;
    if (param.hasOwnProperty('page') && param.page.hasOwnProperty('__wxWebviewId__')) {
      viewId = param.page.__wxWebviewId__;
    }

    _bridge2.default.invokeMethod('pageScrollTo', param, [viewId]);
  },

  navigateTo: function navigateTo(params) {
    arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    if (paramCheck('navigateTo', params, { url: '' })) {
      params.url = _utils2.default.getRealRoute(currUrl, params.url);
      params.url = _utils2.default.encodeUrlQuery(params.url);
      checkUrl('navigateTo', params) && _bridge2.default.invokeMethod('navigateTo', params, {
        afterSuccess: function afterSuccess() {
          currUrl = params.url;
          _context2.default.notifyCurrentRoutetoContext(currUrl);
        }
      });
    }
  },
  switchTab: function switchTab() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    if (paramCheck('switchTab', params, { url: '' })) {
      ;/\?.*$/.test(params.url) && (console.warn('wd.switchTab: url 不支持 queryString'), params.url = params.url.replace(/\?.*$/, ''));
      params.url = _utils2.default.getRealRoute(currUrl, params.url);
      params.url = _utils2.default.encodeUrlQuery(params.url);
      checkUrl('switchTab', params) && _bridge2.default.invokeMethod('switchTab', params, {
        afterSuccess: function afterSuccess() {
          currUrl = params.url;
          _context2.default.notifyCurrentRoutetoContext(currUrl);
        }
      });
    }
  },
  navigateBack: function navigateBack() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    typeof params.delta !== 'number' ? params.delta = 1 : (params.delta = parseInt(params.delta), params.delta < 1 && (params.delta = 1));
    _bridge2.default.invokeMethod('navigateBack', params);
  },
  getStorage: function getStorage(params) {
    if (paramCheck('getStorage', params, { key: '' })) {
      _bridge2.default.invokeMethod('getStorage', params, {
        beforeSuccess: function beforeSuccess(res) {
          res.data = _utils2.default.stringToAnyType(res.data, res.dataType);
          delete res.dataType;
        },
        afterFail: function afterFail() {
          var res = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
          if (res.errMsg && res.errMsg.indexOf('data not found') > 0) return !1;
        }
      });
    }
  },
  getStorageSync: function getStorageSync(key) {
    if (paramCheck('getStorageSync', key, '')) {
      var rt;
      _bridge2.default.invokeMethod('getStorageSync', { key: key }, {
        beforeAll: function beforeAll(res) {
          res = res || {};
          rt = _utils2.default.stringToAnyType(res.data, res.dataType);
        },
        afterFail: function afterFail() {
          var res = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
          if (res.errMsg && res.errMsg.indexOf('data not found') > 0) {
            return !1;
          }
        }
      });
      return rt;
    }
  },
  setStorage: function setStorage(params) {
    if (paramCheck('setStorage', params, { key: '' })) {
      try {
        var opt = _utils2.default.anyTypeToString(params.data),
            data = opt.data,
            dataType = opt.dataType;
        _bridge2.default.invokeMethod('setStorage', {
          key: params.key,
          data: data,
          dataType: dataType,
          success: params.success,
          fail: params.fail,
          complete: params.complete
        });
      } catch (e) {
        typeof params.fail === 'function' && params.fail({
          errMsg: 'setStorage:fail ' + e.message
        }), typeof params.complete === 'function' && params.complete({
          errMsg: 'setStorage:fail ' + e.message
        });
      }
    }
  },
  setStorageSync: function setStorageSync(key, value) {
    value = value || '';
    if (paramCheck('setStorageSync', key, '')) {
      var dataObj = _utils2.default.anyTypeToString(value),
          data = dataObj.data,
          dataType = dataObj.dataType;
      _bridge2.default.invokeMethod('setStorageSync', {
        key: key,
        data: data,
        dataType: dataType
      });
    }
  },
  removeStorage: function removeStorage(params) {
    paramCheck('removeStorage', params, { key: '' }) && _bridge2.default.invokeMethod('removeStorage', params);
  },
  removeStorageSync: function removeStorageSync(key) {
    paramCheck('removeStorageSync', key, '') && _bridge2.default.invokeMethod('removeStorageSync', { key: key });
  },
  clearStorage: function clearStorage() {
    _bridge2.default.invokeMethod('clearStorage');
  },
  clearStorageSync: function clearStorageSync() {
    _bridge2.default.invokeMethod('clearStorageSync');
  },
  getStorageInfo: function getStorageInfo(params) {
    _bridge2.default.invokeMethod('getStorageInfo', params);
  },
  getStorageInfoSync: function getStorageInfoSync() {
    var rt = void 0;
    _bridge2.default.invokeMethod('getStorageInfoSync', {}, {
      beforeAll: function beforeAll(t) {
        rt = t;
        delete t.errMsg;
      }
    });
    return rt;
  },
  request: function request() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    if (paramCheck('request', params, { url: '' })) {
      if (_utils2.default.validateUrl(params.url) === !1) {
        return logErr('request', params, 'request:fail invalid url "' + params.url + '"');
      }
      if (params.data === 'function') {
        return logErr('request', params, 'request:fail data should not be Function');
      }
      var headerType = _utils2.default.getDataType(params.header);
      params.header = params.header || {};
      params.header = _utils2.default.convertObjectValueToString(params.header);
      headerType !== 'Undefined' && headerType !== 'Object' && (console.warn('wd.request: header must be an object'), params.header = {});
      params.header = Object.keys(params.header).reduce(function (res, cur) {
        cur.toLowerCase() === 'content-type' ? res[cur.toLowerCase()] = params.header[cur] : res[cur] = params.header[cur];
        return res;
      }, {});
      params.method && (params.method = params.method.toUpperCase());
      var headers = params.header || {},
          requestMethod = 'GET';
      typeof params.method === 'string' && (requestMethod = params.method.toUpperCase());
      var data;
      params.dataType = params.dataType || 'json';
      headers['content-type'] = headers['content-type'] || 'application/json';
      data = !params.data ? '' : typeof params.data !== 'string' ? headers['content-type'].indexOf('application/x-www-form-urlencoded') > -1 ? _utils2.default.urlEncodeFormData(params.data, !0) : headers['content-type'].indexOf('application/json') > -1 ? JSON.stringify(params.data) : _typeof(params.data) === 'object' ? JSON.stringify(params.data) : data.toString() : params.data;
      requestMethod == 'GET' && (params.url = _utils2.default.addQueryStringToUrl(params.url, params.data));
      _bridge2.default.invokeMethod('request', {
        url: params.url,
        data: data,
        header: headers,
        method: requestMethod,
        success: params.success,
        fail: params.fail,
        complete: params.complete
      }, {
        beforeSuccess: function beforeSuccess(res) {
          if (params.dataType === 'json') {
            try {
              res.data = JSON.parse(res.data);
            } catch (e) {}
          }
          res.statusCode = parseInt(res.statusCode);
        }
      });
    }
  },
  connectSocket: function connectSocket(params) {
    if (paramCheck('connectSocket', params, { url: '' })) {
      _typeof(params.header) !== 'object' && typeof params.header !== 'undefined' && (console.warn('connectSocket: header must be an object'), delete params.header);
      var header = {};
      params.header && (header = _utils2.default.convertObjectValueToString(params.header));

      _bridge2.default.invokeMethod('connectSocket', _utils2.default.assign({}, params, {
        header: header
      }), {
        beforeSuccess: function beforeSuccess(e) {
          e.statusCode = parseInt(e.statusCode);
        }
      });
    }
  },
  closeSocket: function closeSocket(e) {
    _bridge2.default.invokeMethod('closeSocket', e);
  },
  sendSocketMessage: function sendSocketMessage(params) {
    var paramType = _utils2.default.getDataType(params.data);
    _utils2.default.getPlatform() === 'devtools' ? _bridge2.default.invokeMethod('sendSocketMessage', params) : paramType === 'String' ? _bridge2.default.invokeMethod('sendSocketMessage', params) : paramType === 'ArrayBuffer' && _bridge2.default.invokeMethod('sendSocketMessage', _utils2.default.assign(params, {
      data: _utils2.default.arrayBufferToBase64(params.data),
      isBuffer: !0
    }));
  },
  onSocketOpen: function onSocketOpen(callback) {
    paramCheck('onSocketOpen', callback, emptyFn) && _bridge2.default.onMethod('onSocketOpen', Reporter.surroundThirdByTryCatch(callback, 'at onSocketOpen callback function'));
  },
  onSocketClose: function onSocketClose(callback) {
    paramCheck('onSocketClose', callback, emptyFn) && _bridge2.default.onMethod('onSocketClose', Reporter.surroundThirdByTryCatch(callback, 'at onSocketClose callback function'));
  },
  onSocketMessage: function onSocketMessage(callback) {
    if (paramCheck('onSocketMessage', callback, emptyFn)) {
      callback = Reporter.surroundThirdByTryCatch(callback, 'at onSocketMessage callback function');
      _bridge2.default.onMethod('onSocketMessage', function (params) {
        _utils2.default.getPlatform() !== 'devtools' && params.isBuffer === !0 && (params.data = _utils2.default.base64ToArrayBuffer(params.data));
        delete params.isBuffer;
        _utils2.default.getPlatform() === 'devtools' && _utils2.default.getDataType(params.data) === 'Blob' ? _utils2.default.blobToArrayBuffer(params.data, function (data) {
          ;params.data = data, callback(params);
        }) : callback(params);
      });
    }
  },
  onSocketError: function onSocketError(callback) {
    _bridge2.default.onMethod('onSocketError', Reporter.surroundThirdByTryCatch(callback, 'at onSocketError callback function'));
  },
  uploadFile: function uploadFile(params) {
    if (paramCheck('uploadFile', params, { url: '', filePath: '', name: '' })) {
      _typeof(params.header) !== 'object' && typeof params.header !== 'undefined' && (console.warn('uploadFile: header must be an object'), delete params.header), _typeof(params.formData) !== 'object' && typeof params.formData !== 'undefined' && (console.warn('uploadFile: formData must be an object'), delete params.formData);
      var header = {},
          formData = {};
      params.header && (header = _utils2.default.convertObjectValueToString(params.header));
      params.formData && (formData = _utils2.default.convertObjectValueToString(params.formData));
      _bridge2.default.invokeMethod('uploadFile', _utils2.default.assign({}, params, {
        header: header,
        formData: formData
      }), {
        beforeSuccess: function beforeSuccess(res) {
          res.statusCode = parseInt(res.statusCode);
        }
      });
    }
  },
  downloadFile: function downloadFile(params) {
    paramCheck('downloadFile', params, { url: '' }) && _bridge2.default.invokeMethod('downloadFile', params, {
      beforeSuccess: function beforeSuccess(res) {
        res.statusCode = parseInt(res.statusCode);
        var statusArr = [200, 304];
        statusArr.indexOf(res.statusCode) === -1 && delete res.tempFilePath;
      }
    });
  },
  chooseImage: function chooseImage() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    _bridge2.default.invokeMethod('chooseImage', _utils2.default.assign({
      count: 9,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera']
    }, params));
  },
  previewImage: function previewImage(params) {
    paramCheck('previewImage', params, { urls: [''] }) && _bridge2.default.invokeMethod('previewImage', params);
  },
  getImageInfo: function getImageInfo(params) {
    paramCheck('getImageInfo', params, { src: '' }) && (/^(http|https):\/\//.test(params.src) ? _bridge2.default.invokeMethod('downloadFile', { url: params.src }, {
      afterSuccess: function afterSuccess(res) {
        params.src = res.tempFilePath;
        _bridge2.default.invokeMethod('getImageInfo', params, {
          beforeSuccess: function beforeSuccess(rt) {
            rt.path = params.src;
          }
        });
      },
      afterFail: function afterFail() {
        logErr('getImageInfo', params, 'getImageInfo:fail download image fail');
      }
    }) : /^wdfile:\/\//.test(params.src) ? _bridge2.default.invokeMethod('getImageInfo', params, {
      beforeSuccess: function beforeSuccess(rt) {
        rt.path = params.src;
      }
    }) : (params.src = _utils2.default.getRealRoute(currUrl, params.src, !1), _bridge2.default.invokeMethod('getImageInfo', params, {
      beforeSuccess: function beforeSuccess(rt) {
        rt.path = params.src;
      }
    })));
  },
  startRecord: function startRecord(params) {
    ;apiObj.appStatus === _configFlags2.default.AppStatus.BACK_GROUND && apiObj.hanged === !1 || _bridge2.default.invokeMethod('startRecord', params);
  },
  stopRecord: function stopRecord(params) {
    _bridge2.default.invokeMethod('stopRecord', params);
  },
  playVoice: function playVoice(params) {
    paramCheck('playVoice', params, { filePath: '' }) && _bridge2.default.invokeMethod('playVoice', params);
  },
  pauseVoice: function pauseVoice(e) {
    _bridge2.default.invokeMethod('pauseVoice', e);
  },
  stopVoice: function stopVoice(e) {
    _bridge2.default.invokeMethod('stopVoice', e);
  },
  onVoicePlayEnd: function onVoicePlayEnd(callback) {
    _bridge2.default.onMethod('onVoicePlayEnd', Reporter.surroundThirdByTryCatch(callback, 'at onVoicePlayEnd callback function'));
  },
  chooseVideo: function chooseVideo() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    params.sourceType = params.sourceType || ['album', 'camera'];
    params.camera = params.camera || ['front', 'back'];
    _bridge2.default.invokeMethod('chooseVideo', params);
  },
  getLocation: function getLocation(params) {
    console.log('getLocation', params, apiObj.appStatus, apiObj.hanged);apiObj.appStatus === _configFlags2.default.AppStatus.BACK_GROUND && apiObj.hanged === !1 || _bridge2.default.invokeMethod('getLocation', params);
  },
  openLocation: function openLocation() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('openLocation', params, { latitude: 0.1, longitude: 0.1 }) && _bridge2.default.invokeMethod('openLocation', params);
  },
  chooseLocation: function chooseLocation() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    _bridge2.default.invokeMethod('chooseLocation', params);
  },
  getNetworkType: function getNetworkType(params) {
    _bridge2.default.invokeMethod('getNetworkType', params);
  },
  getSystemInfo: function getSystemInfo(params) {
    var platform = _utils2.default.getPlatform();
    _bridge2.default.invokeMethod('getSystemInfo', params, {
      beforeSuccess: function beforeSuccess(rt) {
        rt.platform = platform;
      }
    });
  },
  getSystemInfoSync: function getSystemInfoSync(params) {
    var rt = {},
        platform = _utils2.default.getPlatform();
    _bridge2.default.invokeMethod('getSystemInfo', {}, {
      beforeSuccess: function beforeSuccess(res) {
        rt = res || {};
        rt.platform = platform;
        delete rt.errMsg;
      }
    });
    return rt;
  },
  onAccelerometerChange: function onAccelerometerChange(callback) {
    hasInvokeEnableAccelerometer || (_bridge2.default.invokeMethod('enableAccelerometer', { enable: !0 }), hasInvokeEnableAccelerometer = !0);
    accelerometerChangeFns.push(Reporter.surroundThirdByTryCatch(callback, 'at onAccelerometerChange callback function'));
  },
  onCompassChange: function onCompassChange(callback) {
    hasInvokeEnableCompass || (_bridge2.default.invokeMethod('enableCompass', { enable: !0 }), hasInvokeEnableCompass = !0);
    compassChangeFns.push(Reporter.surroundThirdByTryCatch(callback, 'at onCompassChange callback function'));
  },
  reportAction: function reportAction(params) {
    _bridge2.default.invokeMethod('reportAction', params);
  },
  getBackgroundAudioPlayerState: function getBackgroundAudioPlayerState(params) {
    _bridge2.default.invokeMethod('getMusicPlayerState', params, {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('getBackgroundAudioPlayerState', 'getMusicPlayerState');
      }
    });
  },
  playBackgroundAudio: function playBackgroundAudio() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};apiObj.appStatus === _configFlags2.default.AppStatus.BACK_GROUND && apiObj.hanged === !1 || _bridge2.default.invokeMethod('operateMusicPlayer', _utils2.default.assign({ operationType: 'play' }, params), {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateMusicPlayer', 'playBackgroundAudio');
      }
    });
  },
  pauseBackgroundAudio: function pauseBackgroundAudio() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    _bridge2.default.invokeMethod('operateMusicPlayer', _utils2.default.assign({ operationType: 'pause' }, params), {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateMusicPlayer', 'pauseBackgroundAudio');
      }
    });
  },
  seekBackgroundAudio: function seekBackgroundAudio() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('seekBackgroundAudio', params, { position: 1 }) && _bridge2.default.invokeMethod('operateMusicPlayer', _utils2.default.assign({ operationType: 'seek' }, params), {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateMusicPlayer', 'seekBackgroundAudio');
      }
    });
  },
  stopBackgroundAudio: function stopBackgroundAudio() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    console.log('stopBackgroundAudio');
    _bridge2.default.invokeMethod('operateMusicPlayer', _utils2.default.assign({ operationType: 'stop' }, params), {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateMusicPlayer', 'stopBackgroundAudio');
      }
    });
  },
  onBackgroundAudioPlay: function onBackgroundAudioPlay(callback) {
    _bridge2.default.onMethod('onMusicPlay', Reporter.surroundThirdByTryCatch(callback, 'at onBackgroundAudioPlay callback function'));
  },
  onBackgroundAudioPause: function onBackgroundAudioPause(callback) {
    _bridge2.default.onMethod('onMusicPause', Reporter.surroundThirdByTryCatch(callback, 'at onBackgroundAudioPause callback function'));
  },
  onBackgroundAudioStop: function onBackgroundAudioStop(callback) {
    _bridge2.default.onMethod('onMusicEnd', Reporter.surroundThirdByTryCatch(callback, 'at onBackgroundAudioStop callback function'));
  },
  login: function login(params) {
    if (__wxConfig__ && __wxConfig__.weweb && __wxConfig__.weweb.loginUrl) {
      // 引导到自定义的登录页面
      if (__wxConfig__.weweb.loginUrl.indexOf('/') != 0) {
        __wxConfig__.weweb.loginUrl = '/' + __wxConfig__.weweb.loginUrl;
      }
      var curPages = getCurrentPages();

      loginSourceUrl = curPages[curPages.length - 1].__route__;
      apiObj.redirectTo({
        url: __wxConfig__.weweb.loginUrl
      });
    } else {
      _bridge2.default.invokeMethod('login', params);
    }
  },
  loginSuccess: function loginSuccess() {
    var url = loginSourceUrl && (loginSourceUrl.indexOf('/') === 0 ? loginSourceUrl : '/' + loginSourceUrl) || '/' + __root__;
    loginSourceUrl = '';
    apiObj.redirectTo({
      url: url
    });
  },
  checkLogin: function checkLogin(params) {
    _bridge2.default.invokeMethod('checkLogin', params);
  },
  checkSession: function checkSession(params) {
    refreshSessionTimeHander && clearTimeout(refreshSessionTimeHander);
    _bridge2.default.invokeMethod('refreshSession', params, {
      beforeSuccess: function beforeSuccess(res) {
        refreshSessionTimeHander = setTimeout(function () {
          _bridge2.default.invokeMethod('refreshSession');
        }, 1e3 * res.expireIn);
        delete res.err_code;
        delete res.expireIn;
      },
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('refreshSession', 'checkSession');
      }
    });
  },
  authorize: function authorize(params) {
    _bridge2.default.invokeMethod('authorize', params);
  },
  getUserInfo: function getUserInfo(params) {
    _bridge2.default.invokeMethod('operateWXData', _utils2.default.assign({
      data: {
        api_name: 'webapi_getuserinfo',
        data: params.data || {}
      }
    }, params), {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateWXData', 'getUserInfo');
      },
      beforeSuccess: function beforeSuccess(res) {
        // "android" ===  utils.getPlatform() && (res.data = JSON.parse(res.data))
        res.rawData = res.data.data;
        try {
          res.userInfo = JSON.parse(res.data.data);
          res.signature = res.data.signature;
          res.data.encryptData && (console.group(new Date() + ' encryptData 字段即将废除'), console.warn('请使用 encryptedData 和 iv 字段进行解密，详见：https://mp.weixin.qq.com/debug/wxadoc/dev/api/open.html'), console.groupEnd(), res.encryptData = res.data.encryptData);
          res.data.encryptedData && (res.encryptedData = res.data.encryptedData, res.iv = res.data.iv);
          delete res.data;
        } catch (e) {}
      }
    });
  },
  getFriends: function getFriends(params) {
    _bridge2.default.invokeMethod('operateWXData', {
      data: {
        api_name: 'webapi_getfriends',
        data: params.data || {}
      },
      success: params.success,
      fail: params.fail,
      complete: params.complete
    }, {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateWXData', 'getFriends');
      },
      beforeSuccess: function beforeSuccess(res) {
        // "android" ===  utils.getPlatform() && (res.data = JSON.parse(res.data))
        res.rawData = res.data.data;
        try {
          res.friends = JSON.parse(res.data.data);
          res.signature = res.data.signature;
          delete res.data;
        } catch (e) {}
      }
    });
  },
  requestPayment: function requestPayment(params) {
    paramCheck('requestPayment', params, {
      timeStamp: '',
      nonceStr: '',
      package: '',
      signType: '',
      paySign: ''
    }) && _bridge2.default.invokeMethod('requestPayment', params);
  },
  verifyPaymentPassword: function verifyPaymentPassword(params) {
    _bridge2.default.invokeMethod('verifyPaymentPassword', params);
  },
  bindPaymentCard: function bindPaymentCard(params) {
    _bridge2.default.invokeMethod('bindPaymentCard', params);
  },
  requestPaymentToBank: function requestPaymentToBank(params) {
    _bridge2.default.invokeMethod('requestPaymentToBank', params);
  },
  addCard: function addCard(params) {
    paramCheck('addCard', params, { cardList: [] }) && _bridge2.default.invokeMethod('addCard', params);
  },
  openCard: function openCard(params) {
    paramCheck('openCard', params, { cardList: [] }) && _bridge2.default.invokeMethod('openCard', params);
  },
  scanCode: function scanCode() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('scanCode', params, {}) && _bridge2.default.invokeMethod('scanCode', params, {
      beforeSuccess: function beforeSuccess(res) {
        typeof res.path === 'string' && (res.path = res.path.replace(/\.html$/, ''), res.path = res.path.replace(/\.html\?/, '?'));
      }
    });
  },
  openAddress: function openAddress(params) {
    _bridge2.default.invokeMethod('openAddress', params);
  },
  saveFile: function saveFile(params) {
    paramCheck('saveFile', params, { tempFilePath: '' }) && _bridge2.default.invokeMethod('saveFile', params);
  },
  openDocument: function openDocument(params) {
    paramCheck('openDocument', params, { filePath: '' }) && _bridge2.default.invokeMethod('openDocument', params);
  },
  chooseContact: function chooseContact(params) {
    _bridge2.default.invokeMethod('chooseContact', params);
  },
  makePhoneCall: function makePhoneCall() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('makePhoneCall', params, { phoneNumber: '' }) && _bridge2.default.invokeMethod('makePhoneCall', params);
  },
  onAppRoute: function onAppRoute(params, t) {
    appRouteCallbacks.push(params);
  },
  onAppRouteDone: function onAppRouteDone(params, t) {
    appRouteDoneCallback.push(params);
  },
  onAppEnterBackground: function onAppEnterBackground(params) {
    _appContextSwitch2.default.onAppEnterBackground.call(apiObj, params);
  },
  onAppEnterForeground: function onAppEnterForeground(params) {
    _appContextSwitch2.default.onAppEnterForeground.call(apiObj, params);
  },
  onAppRunningStatusChange: function onAppRunningStatusChange(params) {
    _appContextSwitch2.default.onAppRunningStatusChange.call(apiObj, params);
  },
  setAppData: function setAppData(data) {
    var options = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        webviewIds = arguments[2];
    arguments[3];
    options.forceUpdate = typeof options.forceUpdate !== 'undefined' && options.forceUpdate;
    if (_utils2.default.isObject(data) === !1) {
      throw new _utils2.default.AppServiceSdkKnownError('setAppData:data should be an object');
    }
    !function () {
      var hasUpdate = !1,
          tmpData = {},
          setCurData = function setCurData(key, value, type) {
        hasUpdate = !0;
        tmpData[key] = value;
        type === 'Array' || type === 'Object' ? pageData[key] = JSON.parse(JSON.stringify(value)) : pageData[key] = value;
      };
      for (var oKey in data) {
        var curValue = data[oKey],
            gValue = pageData[oKey],
            gValueType = _utils2.default.getDataType(gValue),
            curValueType = _utils2.default.getDataType(curValue);
        gValueType !== curValueType ? setCurData(oKey, curValue, curValueType) : gValueType == 'Array' || gValueType == 'Object' ? JSON.stringify(gValue) !== JSON.stringify(curValue) && setCurData(oKey, curValue, curValueType) : gValueType == 'String' || gValueType == 'Number' || gValueType == 'Boolean' ? gValue.toString() !== curValue.toString() && setCurData(oKey, curValue, curValueType) : gValueType == 'Date' ? gValue.getTime().toString() !== curValue.getTime().toString() && setCurData(oKey, curValue, curValueType) : gValue !== curValue && setCurData(oKey, curValue, curValueType);
      }
      options.forceUpdate ? _bridge2.default.publish('appDataChange', {
        data: data,
        option: {
          timestamp: Date.now(),
          forceUpdate: !0
        }
      }, webviewIds) : hasUpdate && _bridge2.default.publish('appDataChange', {
        data: tmpData
      }, webviewIds);
    }();
  },
  onPageEvent: function onPageEvent(e, t) {
    console.warn("'onPageEvent' is deprecated, use 'Page[eventName]'");
  },
  createAnimation: function createAnimation() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    if (paramCheck('createAnimation', params, {})) return new _Animation2.default(params);
  },
  createAudioContext: function createAudioContext(e) {
    return _createAudio2.default.call(apiObj, e, curWebViewId);
  },
  createVideoContext: function createVideoContext(e) {
    return _createVideo2.default.call(apiObj, e, curWebViewId);
  },
  createMapContext: function createMapContext(e) {
    return new _map2.default.MapContext(e);
  },
  onWebviewEvent: function onWebviewEvent(fn, t) {
    pageEventFn = fn;
    _bridge2.default.subscribe('PAGE_EVENT', function (params) {
      var data = params.data,
          eventName = params.eventName,
          webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
      fn({
        data: data,
        eventName: eventName,
        webviewId: webviewId
      });
    });
  },
  onNativeEvent: function onNativeEvent(fn) {
    ;['onCanvasTouchStart', 'onCanvasTouchMove', 'onCanvasTouchEnd'].forEach(function (key) {
      _bridge2.default.onMethod(key, function (data, webviewId) {
        fn({
          data: data,
          eventName: key,
          webviewId: webviewId
        });
      });
    });
  },
  hideKeyboard: function hideKeyboard(params) {
    _bridge2.default.publish('hideKeyboard', {}); // "devtools" ==  utils.getPlatform() ? bridge.publish("hideKeyboard", {}) :  bridge.invokeMethod("hideKeyboard", params)
  },
  getPublicLibVersion: function getPublicLibVersion() {
    var rt;
    _bridge2.default.invokeMethod('getPublicLibVersion', {
      complete: function complete(res) {
        res.version ? rt = res.version : (rt = res, delete rt.errMsg);
      }
    });
    return rt;
  },
  showModal: function showModal() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        options = {
      title: '',
      content: '',
      confirmText: '确定',
      cancelText: '取消',
      showCancel: !0,
      confirmColor: '#3CC51F',
      cancelColor: '#000000'
    };
    options = _utils2.default.extend(options, params);
    if (paramCheck('showModal', options, {
      title: '',
      content: '',
      confirmText: '',
      cancelText: '',
      confirmColor: '',
      cancelColor: ''
    })) {
      return options.confirmText.length > 4 ? void logErr('showModal', params, 'showModal:fail confirmText length should not large then 4') : options.cancelText.length > 4 ? void logErr('showModal', params, 'showModal:fail cancelText length should not large then 4') : _bridge2.default.invokeMethod('showModal', options, {
        beforeSuccess: function beforeSuccess(rt) {
          rt.confirm = Boolean(rt.confirm);
        }
      });
    }
  },
  showToast: function showToast() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        options = {
      duration: 1500,
      title: '',
      icon: 'success',
      mask: !1
    };
    options = _utils2.default.extend(options, params);
    delete options.image;['success', 'loading'].indexOf(options.icon) < 0 && (options.icon = 'success');
    options.duration > 1e4 && (options.duration = 1e4);
    paramCheck('showToast', options, {
      duration: 1,
      title: '',
      icon: ''
    }) && _bridge2.default.invokeMethod('showToast', options);
  },
  hideToast: function hideToast(e) {
    _bridge2.default.invokeMethod('hideToast', e);
  },
  showLoading: function showLoading() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        defaultArgs = { title: '', icon: 'loading', mask: !1, duration: 1e8 };
    defaultArgs = _utils2.default.extend(defaultArgs, params);
    params.image && (defaultArgs.image = _utils2.default.getRealRoute(currUrl, params.image, !1));
    paramCheck('showLoading', defaultArgs, {
      duration: 1,
      title: ''
    }) && _bridge2.default.invokeMethod('showToast', defaultArgs, {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('showToast', 'showLoading');
      }
    });
  },
  hideLoading: function hideLoading(args) {
    _bridge2.default.invokeMethod('hideToast', args, {
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('hideToast', 'hideLoading');
      }
    });
  },
  showActionSheet: function showActionSheet() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        options = {
      itemList: [],
      itemColor: '#000000'
    };
    options = _utils2.default.extend(options, params);
    options.cancelText = '取消';
    options.cancelColor = '#000000';
    if (paramCheck('showActionSheet', options, { itemList: ['1'], itemColor: '' })) {
      return params.itemList.length > 6 ? void logErr('showActionSheet', params, 'showActionSheet:fail parameter error: itemList should not be large than 6') : _bridge2.default.invokeMethod('showActionSheet', options, {
        beforeCancel: function beforeCancel(t) {
          try {
            typeof params.success === 'function' && params.success({
              errMsg: 'showActionSheet:ok',
              cancel: !0
            });
          } catch (e) {
            Reporter.thirdErrorReport({
              error: e,
              extend: 'showActionSheet success callback error'
            });
          }
        }
      });
    }
  },
  getSavedFileList: function getSavedFileList() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    _bridge2.default.invokeMethod('getSavedFileList', params);
  },
  getSavedFileInfo: function getSavedFileInfo() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('getSavedFileInfo', params, { filePath: '' }) && _bridge2.default.invokeMethod('getSavedFileInfo', params);
  },
  getFileInfo: function getFileInfo() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    if (_bridge2.default.beforeInvoke('getFileInfo', params, { filePath: '' })) {
      if (void 0 !== params.digestAlgorithm) {
        var res = _utils2.default.paramCheck(params, { digestAlgorithm: '' });
        if (res) {
          _bridge2.default.beforeInvokeFail('getFileInfo', params, 'parameter error: ' + res);
        }
        if (['md5', 'sha1'].indexOf(params.digestAlgorithm) === -1) {
          _bridge2.default.beforeInvokeFail('getFileInfo', params, 'parameter error: invalid digestAlgorithm "' + params.digestAlgorithm + '"');
        }
      }
      _bridge2.default.invokeMethod('getFileInfo', params, {});
    }
  },
  removeSavedFile: function removeSavedFile() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('removeSavedFile', params, { filePath: '' }) && _bridge2.default.invokeMethod('removeSavedFile', params);
  },
  getExtConfig: function getExtConfig() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    setTimeout(function () {
      var res = {
        errMsg: 'getExtConfig: ok',
        extConfig: (0, apiObj.getExtConfigSync)()
      };
      typeof params.success === 'function' && params.success(res);
      typeof params.complete === 'function' && params.complete(res);
    }, 0);
  },
  getClipboardData: function getClipboardData() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    _bridge2.default.invokeMethod('getClipboardData', params, {});
    // bridge.invokeMethod("getClipboardData",params,{})
  },
  setClipboardData: function setClipboardData() {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    paramCheck('setClipboardData', params, { data: '' }) && _bridge2.default.invokeMethod('setClipboardData', params, {
      beforeSuccess: function beforeSuccess() {
        currentClipBoardData = params.data;
        apiObj.reportClipBoardData(!0);
      }
    });
  },
  reportClipBoardData: function reportClipBoardData(param) {
    if (currentClipBoardData !== '') {
      var t = getCurrentPages().find(function (e) {
        return e.__wxWebviewId__ === curWebViewId;
      }) || {},
          value = [currentClipBoardData, t.__route__, param ? 1 : 0, Object.keys(t.options).map(function (e) {
        return encodeURIComponent(e) + '=' + encodeURIComponent(t.options[e]);
      }).join('&')].map(encodeURIComponent).join(',');
      Reporter.reportKeyValue({
        key: 'Clipboard',
        value: value,
        force: !0
      });
    }
  },
  getExtConfigSync: function getExtConfigSync() {
    if (!__wxConfig__.ext) return {};
    try {
      return JSON.parse(JSON.stringify(__wxConfig__.ext));
    } catch (e) {
      return {};
    }
  },
  chooseAddress: function chooseAddress(params) {
    _bridge2.default.invokeMethod('openAddress', params, {
      beforeSuccess: function beforeSuccess(res) {
        _utils2.default.renameProperty(res, 'addressPostalCode', 'postalCode');
        _utils2.default.renameProperty(res, 'proviceFirstStageName', 'provinceName');
        _utils2.default.renameProperty(res, 'addressCitySecondStageName', 'cityName');
        _utils2.default.renameProperty(res, 'addressCountiesThirdStageName', 'countyName');
        _utils2.default.renameProperty(res, 'addressDetailInfo', 'detailInfo');
      },
      beforeAll: function beforeAll(res) {
        res.errMsg = res.errMsg.replace('openAddress', 'chooseAddress');
        delete res.err_msg;
      }
    });
  },
  canIuse: function canIuse() {
    var param1 = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : '',
        param2 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : SDKVersion;
    if (typeof param1 !== 'string') {
      throw new _utils2.default.AppServiceSdkKnownError('canIUse: schema should be an object');
    }
    var params = param1.split('.');
    return _utils2.default.canIUse(_utils2.default.toArray(params), param2);
  },
  reportLog: function reportLog(name, data) {
    _bridge2.default.publish('H5_USER_LOG', { event: name, desc: data || '' });
  }
};

apiObj.onAppEnterBackground(function () {
  apiObj.getClipboardData({
    success: function success(e) {
      e.data !== currentClipBoardData && (currentClipBoardData = e.data, apiObj.reportClipBoardData)(!1);
    }
  });
}), apiObj.onAppEnterForeground(), apiObj.appStatus = _configFlags2.default.AppStatus.FORE_GROUND, apiObj.hanged = !1, _bridge2.default.subscribe('INVOKE_METHOD', function (params, t) {
  var name = params.name,
      args = params.args;
  apiObj[name](args, !0);
}), _bridge2.default.subscribe('WEBVIEW_ERROR_MSG', function (params, t) {
  var msg = params.msg;
  Reporter.triggerErrorMessage(msg);
}), _bridge2.default.onMethod('onAppRoute', function (params) {
  var webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  params.path = params.path.replace(/\.\w+(\?|$)/, '$1'); // .substring(0, params.path.length - 5);
  params.webviewId = params.webviewId ? params.webviewId : webviewId;
  currUrl = params.path;
  if (params.openType !== 'appLaunch') {
    for (var n in params.query) {
      params.query[n] = decodeURIComponent(params.query[n]);
    }
  }
  if (params.openType == 'navigateBack' || params.openType == 'redirectTo') {
    _canvas2.default.clearOldWebviewCanvas();
  }
  _canvas2.default.notifyWebviewIdtoCanvas(params.webviewId);
  _map2.default.notifyWebviewIdtoMap(params.webviewId);
  curWebViewId = params.webviewId;
  appRouteCallbacks.forEach(function (callback) {
    callback(params);
  });
}), _bridge2.default.onMethod('onAppRouteDone', function (params) {
  var webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  params.path = params.path.replace(/\.\w+(\?|$)/, '$1'); // params.path.substring(0, params.path.length - 5);
  params.webviewId = typeof params.webviewId !== 'undefined' ? params.webviewId : webviewId;
  currUrl = params.path;
  appRouteDoneCallback.forEach(function (fn) {
    fn(params);
  });
  _bridge2.default.publish('onAppRouteDone', {}, [webviewId]);
}), _bridge2.default.onMethod('onKeyboardValueChange', function (params) {
  var webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
      pValue = params.value,
      pCursor = params.cursor;
  if (params.data && typeof pageEventFn === 'function') {
    var data = JSON.parse(params.data);
    if (data.bindinput) {
      var peRes;
      try {
        peRes = pageEventFn({
          data: {
            type: 'input',
            target: data.target,
            currentTarget: data.target,
            timeStamp: Date.now(),
            touches: [],
            detail: {
              value: params.value,
              cursor: params.cursor
            }
          },
          eventName: data.bindinput,
          webviewId: webviewId
        });
      } catch (e) {
        throw new _utils2.default.AppServiceSdkKnownError('bind key input error');
      }
      if (data.setKeyboardValue) {
        if (void 0 === peRes || peRes === null || peRes === !1) ;else if (_utils2.default.getDataType(peRes) === 'Object') {
          var opt = {
            inputId: params.inputId
          };
          pValue != peRes.value && (opt.value = peRes.value + '');
          isNaN(parseInt(peRes.cursor)) || (opt.cursor = parseInt(peRes.cursor), typeof opt.value === 'undefined' && (opt.value = pValue), opt.cursor > opt.value.length && (opt.cursor = -1));
          _bridge2.default.invokeMethod('setKeyboardValue', opt);
        } else {
          pValue != peRes && _bridge2.default.invokeMethod('setKeyboardValue', {
            value: peRes + '',
            cursor: -1,
            inputId: params.inputId
          });
        }
      }
    }
  }
  _bridge2.default.publish('setKeyboardValue', {
    value: pValue,
    cursor: pCursor,
    inputId: params.inputId
  }, [webviewId]);
});

var getTouchInfo = function getTouchInfo(touchInfo, eventKey, eventInfo) {
  // 返回touch信息
  var touches = [],
      changedTouches = [];
  if (eventKey === 'onTouchStart') {
    for (var i in touchInfo) {
      touches.push(touchInfo[i]);
    }var touchObj = {
      x: eventInfo.touch.x,
      y: eventInfo.touch.y,
      identifier: eventInfo.touch.id
    };
    changedTouches.push(touchObj);
    touches.push(touchObj);
  } else if (eventKey === 'onTouchMove') {
    for (var s in touchInfo) {
      var curTouchInfo = touchInfo[s],
          hasUpdate = !1;
      for (var f in eventInfo.touches) {
        var touchObj = {
          x: eventInfo.touches[f].x,
          y: eventInfo.touches[f].y,
          identifier: eventInfo.touches[f].id
        };
        if (touchObj.identifier === curTouchInfo.identifier && (curTouchInfo.x !== touchObj.x || curTouchInfo.y !== touchObj.y)) {
          touches.push(touchObj);
          changedTouches.push(touchObj);
          hasUpdate = !0;
          break;
        }
      }
      hasUpdate || touches.push(curTouchInfo);
    }
  } else if (eventKey === 'onTouchEnd') {
    var touchObj = {
      x: eventInfo.touch.x,
      y: eventInfo.touch.y,
      identifier: eventInfo.touch.id
    };
    for (var p in touchInfo) {
      var curTouchInfo = touchInfo[p];
      curTouchInfo.identifier === touchObj.identifier ? changedTouches.push(touchObj) : touches.push(curTouchInfo);
    }
  } else if (eventKey === 'onTouchCancel') {
    for (var v in eventInfo.touches) {
      var touchObj = {
        x: eventInfo.touches[v].x,
        y: eventInfo.touches[v].y,
        identifier: eventInfo.touches[v].id
      };
      changedTouches.push(touchObj);
    }
  } else if (eventKey === 'onLongPress') {
    var touchObj = {
      x: eventInfo.touch.x,
      y: eventInfo.touch.y,
      identifier: eventInfo.touch.id
    };
    for (var b in touchInfo) {
      touchInfo[b].identifier === touchObj.identifier ? touches.push(touchObj) : touches.push(touchInfo[b]);
    }
    changedTouches.push(touchObj);
  }
  return {
    touches: touches,
    changedTouches: changedTouches
  };
},
    touchEvents = {
  onTouchStart: 'touchstart',
  onTouchMove: 'touchmove',
  onTouchEnd: 'touchend',
  onTouchCancel: 'touchcancel',
  onLongPress: 'longtap'
};['onTouchStart', 'onTouchMove', 'onTouchEnd', 'onTouchCancel', 'onLongPress'].forEach(function (eventName) {
  _bridge2.default.onMethod(eventName, function (params) {
    var webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
        data = JSON.parse(params.data),
        canvasNumber = data.canvasNumber;
    _canvas2.default.canvasInfo.hasOwnProperty(canvasNumber) || console.error('No such canvas ' + canvasNumber + ' register in ' + webviewId + ', but trigger ' + eventName + ' event.');
    var canvasData = _canvas2.default.canvasInfo[canvasNumber].data;
    if (canvasData[eventName] && typeof pageEventFn === 'function') {
      var touchInfo = getTouchInfo(canvasData.lastTouches, eventName, params),
          touches = touchInfo.touches,
          changedTouches = touchInfo.changedTouches;canvasData.lastTouches = touches, eventName === 'onTouchMove' && changedTouches.length === 0 || pageEventFn({
        data: {
          type: touchEvents[eventName],
          timeStamp: new Date() - canvasData.startTime,
          target: canvasData.target,
          touches: touches,
          changedTouches: changedTouches
        },
        eventName: canvasData[eventName],
        webviewId: webviewId
      });
    }
  });
}), ['onVideoPlay', 'onVideoPause', 'onVideoEnded', 'onVideoTimeUpdate', 'onVideoClickFullScreenBtn', 'onVideoClickDanmuBtn'].forEach(function (eventName) {
  _bridge2.default.onMethod(eventName, function () {
    var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        webviewId = arguments[1],
        bindEventName = 'bind' + eventName.substring(7).toLowerCase(),
        dataObj = JSON.parse(params.data),
        handlers = dataObj.handlers,
        event = dataObj.event,
        createdTimestamp = dataObj.createdTimestamp;
    if (handlers[bindEventName] && typeof pageEventFn === 'function') {
      var data = {
        type: bindEventName.substring(4),
        target: event.target,
        currentTarget: event.currentTarget,
        timeStamp: Date.now() - createdTimestamp,
        detail: {}
      };
      bindEventName === 'bindtimeupdate' && (data.detail = { currentTime: params.position });
      pageEventFn({
        data: data,
        eventName: handlers[bindEventName],
        webviewId: webviewId
      });
    }
  });
}), _bridge2.default.onMethod('onAccelerometerChange', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  accelerometerChangeFns.forEach(function (fn) {
    typeof fn === 'function' && fn(params);
  });
}), _bridge2.default.onMethod('onCompassChange', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  compassChangeFns.forEach(function (fn) {
    typeof fn === 'function' && fn(params);
  });
}), _bridge2.default.onMethod('onError', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  console.error('thirdScriptError', '\n', 'sdk uncaught third Error', '\n', params.message, '\n', params.stack);
}), _bridge2.default.onMethod('onMapMarkerClick', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
      webViewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  if (params.data && typeof pageEventFn === 'function') {
    var data = JSON.parse(params.data);
    data.bindmarkertap && pageEventFn({
      data: {
        markerId: data.markerId
      },
      eventName: data.bindmarkertap,
      webviewId: webViewId
    });
  }
}), _bridge2.default.onMethod('onMapControlClick', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
      webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  if (params.data && typeof pageEventFn === 'function') {
    var data = JSON.parse(params.data);
    data.bindcontroltap && pageEventFn({
      data: {
        controlId: data.controlId
      },
      eventName: data.bindcontroltap,
      webviewId: webviewId
    });
  }
}), _bridge2.default.onMethod('onMapRegionChange', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
      webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
      mapInfo = _map2.default.mapInfo[webviewId + '_' + params.mapId];
  mapInfo && mapInfo.bindregionchange && typeof pageEventFn === 'function' && pageEventFn({
    data: {
      type: params.type
    },
    eventName: mapInfo.bindregionchange,
    webviewId: webviewId
  });
}), _bridge2.default.onMethod('onMapClick', function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
      webviewId = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
      mapInfo = _map2.default.mapInfo[webviewId + '_' + params.mapId];
  mapInfo && mapInfo.bindtap && typeof pageEventFn === 'function' && pageEventFn({
    data: {},
    eventName: mapInfo.bindtap,
    webviewId: webviewId
  });
});
for (var key in apiObj) {
  addGetterForWX(key);
}function bindApi(item) {
  if (!item.name) {
    return;
  }
  WX[item.name] = function (params) {
    params = params || {};
    if (item.params && !paramCheck(item.name, params, item.params)) {
      return;
    }
    if (item.fn) {
      item.fn.call(apiObj, params);
    } else {
      _bridge2.default.invokeMethod(item.name, { params: params }, item.option);
    }
  };
}
WX.loadExtApi = function (conf) {
  if (conf) {
    var type = _utils2.default.getDataType(conf);
    if (type == 'Array') {
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = conf[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var item = _step.value;

          bindApi(item);
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }
    } else if (type == 'Object') {
      bindApi(conf);
    }
  }
};
window.HeraExtApiConf && WX.loadExtApi(window.HeraExtApiConf);

window.wd = WX;
module.exports = WX;

/***/ }),
/* 126 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _utils = __webpack_require__(0);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Animation = function () {
    function Animation() {
        _classCallCheck(this, Animation);

        var option = arguments.length <= 0 ? undefined : arguments[0];
        this.actions = [];
        this.currentTransform = [];
        this.currentStepAnimates = [];
        this.option = {
            transition: {
                duration: typeof option.duration !== 'undefined' ? option.duration : 400,
                timingFunction: typeof option.timingFunction !== 'undefined' ? option.timingFunction : 'linear',
                delay: typeof option.delay !== 'undefined' ? option.delay : 0
            },
            transformOrigin: option.transformOrigin || '50% 50% 0'
        };
    }

    _createClass(Animation, [{
        key: 'export',
        value: function _export() {
            var temp = this.actions;
            this.actions = [];
            return { actions: temp };
        }
    }, {
        key: 'step',
        value: function step() {
            var that = this,
                params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};

            this.currentStepAnimates.forEach(function (animate) {
                animate.type !== 'style' ? that.currentTransform[animate.type] = animate : that.currentTransform[animate.type + '.' + animate.args[0]] = animate;
            });
            this.actions.push({
                animates: Object.keys(this.currentTransform).reduce(function (res, cur) {
                    return [].concat(_utils2.default.toArray(res), [that.currentTransform[cur]]);
                }, []),
                option: {
                    transformOrigin: typeof params.transformOrigin !== 'undefined' ? params.transformOrigin : this.option.transformOrigin,
                    transition: {
                        duration: typeof params.duration !== 'undefined' ? params.duration : this.option.transition.duration,
                        timingFunction: typeof params.timingFunction !== 'undefined' ? params.timingFunction : this.option.transition.timingFunction,
                        delay: typeof params.delay !== 'undefined' ? params.delay : this.option.transition.delay
                    }
                }
            });
            this.currentStepAnimates = [];
            return this;
        }
    }, {
        key: 'matrix',
        value: function matrix() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
                r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1,
                i = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 1;
            this.currentStepAnimates.push({
                type: 'matrix',
                args: [e, t, n, o, r, i]
            });
            return this;
        }
    }, {
        key: 'matrix3d',
        value: function matrix3d() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
                r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 0,
                i = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 1,
                a = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0,
                s = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 0,
                c = arguments.length > 8 && void 0 !== arguments[8] ? arguments[8] : 0,
                u = arguments.length > 9 && void 0 !== arguments[9] ? arguments[9] : 0,
                f = arguments.length > 10 && void 0 !== arguments[10] ? arguments[10] : 1,
                l = arguments.length > 11 && void 0 !== arguments[11] ? arguments[11] : 0,
                d = arguments.length > 12 && void 0 !== arguments[12] ? arguments[12] : 0,
                p = arguments.length > 13 && void 0 !== arguments[13] ? arguments[13] : 0,
                h = arguments.length > 14 && void 0 !== arguments[14] ? arguments[14] : 0,
                v = arguments.length > 15 && void 0 !== arguments[15] ? arguments[15] : 1;
            this.currentStepAnimates.push({
                type: 'matrix3d',
                args: [e, t, n, o, r, i, a, s, c, u, f, l, d, p, h, v]
            });
            this.stepping = !1;
            return this;
        }
    }, {
        key: 'rotate',
        value: function rotate() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'rotate',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'rotate3d',
        value: function rotate3d() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0,
                o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
            this.currentStepAnimates.push({
                type: 'rotate3d',
                args: [e, t, n, o]
            });
            this.stepping = !1;
            return this;
        }
    }, {
        key: 'rotateX',
        value: function rotateX() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'rotateX',
                args: [e]
            });
            this.stepping = !1;
            return this;
        }
    }, {
        key: 'rotateY',
        value: function rotateY() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'rotateY',
                args: [e]
            });
            this.stepping = !1;
            return this;
        }
    }, {
        key: 'rotateZ',
        value: function rotateZ() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'rotateZ',
                args: [e]
            });
            this.stepping = !1;
            return this;
        }
    }, {
        key: 'scale',
        value: function scale() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
                t = arguments[1];
            t = typeof t !== 'undefined' ? t : e;
            this.currentStepAnimates.push({
                type: 'scale',
                args: [e, t]
            });
            return this;
        }
    }, {
        key: 'scale3d',
        value: function scale3d() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
            this.currentStepAnimates.push({
                type: 'scale3d',
                args: [e, t, n]
            });
            return this;
        }
    }, {
        key: 'scaleX',
        value: function scaleX() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
            this.currentStepAnimates.push({
                type: 'scaleX',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'scaleY',
        value: function scaleY() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
            this.currentStepAnimates.push({
                type: 'scaleY',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'scaleZ',
        value: function scaleZ() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
            this.currentStepAnimates.push({
                type: 'scaleZ',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'skew',
        value: function skew() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
            this.currentStepAnimates.push({
                type: 'skew',
                args: [e, t]
            });
            return this;
        }
    }, {
        key: 'skewX',
        value: function skewX() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'skewX',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'skewY',
        value: function skewY() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'skewY',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'translate',
        value: function translate() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
            this.currentStepAnimates.push({
                type: 'translate',
                args: [e, t]
            });
            return this;
        }
    }, {
        key: 'translate3d',
        value: function translate3d() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
            this.currentStepAnimates.push({
                type: 'translate3d',
                args: [e, t, n]
            });
            return this;
        }
    }, {
        key: 'translateX',
        value: function translateX() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'translateX',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'translateY',
        value: function translateY() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'translateY',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'translateZ',
        value: function translateZ() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            this.currentStepAnimates.push({
                type: 'translateZ',
                args: [e]
            });
            return this;
        }
    }, {
        key: 'opacity',
        value: function opacity(e) {
            this.currentStepAnimates.push({
                type: 'style',
                args: ['opacity', e]
            });
            return this;
        }
    }, {
        key: 'backgroundColor',
        value: function backgroundColor(e) {
            this.currentStepAnimates.push({
                type: 'style',
                args: ['backgroundColor', e]
            });
            return this;
        }
    }, {
        key: 'width',
        value: function width(e) {
            typeof e === 'number' && (e += 'px');
            this.currentStepAnimates.push({
                type: 'style',
                args: ['width', e]
            });
            return this;
        }
    }, {
        key: 'height',
        value: function height(e) {
            typeof e === 'number' && (e += 'px');
            this.currentStepAnimates.push({
                type: 'style',
                args: ['height', e]
            });
            return this;
        }
    }, {
        key: 'left',
        value: function left(e) {
            typeof e === 'number' && (e += 'px');
            this.currentStepAnimates.push({
                type: 'style',
                args: ['left', e]
            });
            return this;
        }
    }, {
        key: 'right',
        value: function right(e) {
            typeof e === 'number' && (e += 'px');
            this.currentStepAnimates.push({
                type: 'style',
                args: ['right', e]
            });
            return this;
        }
    }, {
        key: 'top',
        value: function top(e) {
            typeof e === 'number' && (e += 'px');
            this.currentStepAnimates.push({
                type: 'style',
                args: ['top', e]
            });
            return this;
        }
    }, {
        key: 'bottom',
        value: function bottom(e) {
            typeof e === 'number' && (e += 'px');
            this.currentStepAnimates.push({
                type: 'style',
                args: ['bottom', e]
            });
            return this;
        }
    }]);

    return Animation;
}();

exports.default = Animation;

/***/ }),
/* 127 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

__webpack_require__(2);

__webpack_require__(0);

var _EventEmitter = __webpack_require__(6);

var _EventEmitter2 = _interopRequireDefault(_EventEmitter);

var _configFlags = __webpack_require__(7);

var _configFlags2 = _interopRequireDefault(_configFlags);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function createAudio(e, t) {
    var self = this,
        audioObj = new Audio(e, t);
    audioObj._getAppStatus = function () {
        return self.appStatus;
    };
    audioObj._getHanged = function () {
        return self.hanged;
    };
    this.onAppEnterBackground(function () {
        audioObj.pause();
    });
    return audioObj;
}

var audioFlags = {},
    eventEmitter2 = new _EventEmitter2.default.EventEmitter2();

ServiceJSBridge.subscribe("audioInsert", function (params, webviewId) {
    var audioId = params.audioId;
    audioFlags[webviewId + "_" + audioId] = !0;
    eventEmitter2.emit("audioInsert_" + webviewId + "_" + audioId);
});

var Audio = function () {
    function Audio(audioId, webviewId) {
        _classCallCheck(this, Audio);

        if ("string" != typeof audioId) throw new Error("audioId should be a String");
        this.audioId = audioId;
        this.webviewId = webviewId;
    }

    _createClass(Audio, [{
        key: 'setSrc',
        value: function setSrc(data) {
            this._sendAction({
                method: "setSrc",
                data: data
            });
        }
    }, {
        key: 'play',
        value: function play() {
            var status = this._getAppStatus();
            this._getHanged();
            status === _configFlags2.default.AppStatus.BACK_GROUND || this._sendAction({
                method: "play"
            });
        }
    }, {
        key: 'pause',
        value: function pause() {
            this._sendAction({
                method: "pause"
            });
        }
    }, {
        key: 'seek',
        value: function seek(data) {
            this._sendAction({
                method: "setCurrentTime",
                data: data
            });
        }
    }, {
        key: '_ready',
        value: function _ready(fn) {
            audioFlags[this.webviewId + "_" + this.audioId] ? fn() : eventEmitter2.on("audioInsert_" + this.webviewId + "_" + this.audioId, function () {
                fn();
            });
        }
    }, {
        key: '_sendAction',
        value: function _sendAction(params) {
            var self = this;
            this._ready(function () {
                ServiceJSBridge.publish("audio_" + self.audioId + "_actionChanged", params, [self.webviewId]);
            });
        }
    }]);

    return Audio;
}();

exports.default = createAudio;

/***/ }),
/* 128 */
/***/ (function(module, exports) {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ }),
/* 129 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _bridge = __webpack_require__(2);

var _bridge2 = _interopRequireDefault(_bridge);

var _utils = __webpack_require__(0);

var _utils2 = _interopRequireDefault(_utils);

var _EventEmitter = __webpack_require__(6);

var _EventEmitter2 = _interopRequireDefault(_EventEmitter);

var _configFlags = __webpack_require__(7);

var _configFlags2 = _interopRequireDefault(_configFlags);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function createVideo(videoId, t) {
    var self = this,
        videoObj = new VideoControl(videoId, t);
    videoObj._getAppStatus = function () {
        return self.appStatus;
    };
    videoObj._getHanged = function () {
        return self.hanged;
    };
    this.onAppEnterBackground(function () {
        videoObj.pause();
    });
    return videoObj;
}

var notIOS = "ios" !== _utils2.default.getPlatform(),
    videoPlayerIds = {},
    EventEmitter = new _EventEmitter2.default.EventEmitter2();

ServiceJSBridge.subscribe("videoPlayerInsert", function (params, t) {
    var domId = params.domId,
        videoPlayerId = params.videoPlayerId;
    videoPlayerIds[domId] = videoPlayerIds[domId] || videoPlayerId;
    EventEmitter.emit("videoPlayerInsert", domId);
});

ServiceJSBridge.subscribe("videoPlayerRemoved", function (params, t) {
    var domId = params.domId;
    params.videoPlayerId;
    delete videoPlayerIds[domId];
});

var VideoControl = function () {
    function VideoControl(videoId) {
        _classCallCheck(this, VideoControl);

        if ("string" != typeof videoId) throw new Error("video ID should be a String");
        this.domId = videoId;
    }

    _createClass(VideoControl, [{
        key: 'play',
        value: function play() {
            var appStatus = this._getAppStatus();
            appStatus === _configFlags2.default.AppStatus.BACK_GROUND || appStatus === _configFlags2.default.AppStatus.LOCK || this._invokeMethod("play");
        }
    }, {
        key: 'pause',
        value: function pause() {
            this._invokeMethod("pause");
        }
    }, {
        key: 'seek',
        value: function seek(e) {
            this._invokeMethod("seek", [e]);
        }
    }, {
        key: 'sendDanmu',
        value: function sendDanmu(params) {
            var text = params.text,
                color = params.color;
            this._invokeMethod("sendDanmu", [text, color]);
        }
    }, {
        key: '_invokeMethod',
        value: function _invokeMethod(type, data) {
            function invoke() {
                notIOS ? (this.action = { method: type, data: data }, this._sendAction()) : _bridge2.default.invokeMethod("operateVideoPlayer", {
                    data: data,
                    videoPlayerId: videoPlayerIds[this.domId],
                    type: type
                });
            }

            var self = this;
            "number" == typeof videoPlayerIds[this.domId] ? invoke.apply(this) : EventEmitter.on("videoPlayerInsert", function (e) {
                invoke.apply(self);
            });
        }
    }, {
        key: '_sendAction',
        value: function _sendAction() {
            ServiceJSBridge.publish("video_" + this.domId + "_actionChanged", this.action);
        }
    }]);

    return VideoControl;
}();

exports.default = createVideo;

/***/ }),
/* 130 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }(); //1-8 map相关事件和方法

var _bridge = __webpack_require__(2);

var _bridge2 = _interopRequireDefault(_bridge);

var _utils = __webpack_require__(0);

var _utils2 = _interopRequireDefault(_utils);

var _EventEmitter = __webpack_require__(6);

var _EventEmitter2 = _interopRequireDefault(_EventEmitter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function notifyWebviewIdtoMap(e) {
    webviewID = e;
}

var mapIds = {},
    mapInfo = {},
    EventEmitter = new _EventEmitter2.default.EventEmitter2(),
    webviewID = 0,
    callbackIndex = 0;

ServiceJSBridge.subscribe("mapInsert", function (params, viewId) {
    var domId = params.domId,
        mapId = params.mapId,
        bindregionchange = params.bindregionchange,
        bindtap = params.bindtap,
        showLocation = params.showLocation,
        key = viewId + "_" + domId;
    mapIds[key] = mapIds[key] || mapId;

    mapInfo[viewId + "_" + mapId] = {
        bindregionchange: bindregionchange,
        bindtap: bindtap,
        showLocation: showLocation
    };
    EventEmitter.emit("mapInsert");
});

var MapContext = function () {
    function MapContext(mapId) {
        _classCallCheck(this, MapContext);

        var that = this;
        if ("string" != typeof mapId) throw new Error("map ID should be a String");
        this.domId = mapId;

        ServiceJSBridge.subscribe("doMapActionCallback", function (event, t) {
            var callbackId = event.callbackId;
            "getMapCenterLocation" === event.method && callbackId && "function" == typeof that[callbackId] && (that[callbackId]({
                longitude: event.longitude,
                latitude: event.latitude
            }), delete that[callbackId]);
        });
    }

    _createClass(MapContext, [{
        key: '_invoke',
        value: function _invoke(methodName, params) {
            var platform = _utils2.default.getPlatform();
            if ("ios" === platform || "android" === platform) {
                var curMapInfo = mapInfo[webviewID + "_" + params.mapId];
                if ("moveToMapLocation" === methodName) {
                    return void (curMapInfo && curMapInfo.showLocation ? _bridge2.default.invokeMethod(methodName, params) : console.error("only show-location set to true can invoke moveToLocation"));
                }
                _bridge2.default.invokeMethod(methodName, params);
            } else {
                params.method = methodName;
                var callbackId = "callback" + webviewID + "_" + params.mapId + "_" + callbackIndex++;
                this[callbackId] = params.success;
                params.callbackId = callbackId;
                _bridge2.default.publish("doMapAction" + params.mapId, params, [webviewID]);
            }
        }
    }, {
        key: '_invokeMethod',
        value: function _invokeMethod(name, params) {
            var self = this,
                index = webviewID + "_" + this.domId;
            "number" == typeof mapIds[index] || mapIds[index] ? (params.mapId = mapIds[index], this._invoke(name, params)) : EventEmitter.on("mapInsert", function () {
                params.mapId = mapIds[index];
                self._invoke(name, params);
            });
        }
    }, {
        key: 'getCenterLocation',
        value: function getCenterLocation() {
            var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            this._invokeMethod("getMapCenterLocation", params);
        }
    }, {
        key: 'moveToLocation',
        value: function moveToLocation() {
            var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            this._invokeMethod("moveToMapLocation", params);
        }
    }]);

    return MapContext;
}();

exports.default = {
    notifyWebviewIdtoMap: notifyWebviewIdtoMap,
    MapContext: MapContext, //class
    mapInfo: mapInfo
};

/***/ }),
/* 131 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
// module14 predefinedColor

var predefinedColor = exports.predefinedColor = {
    aliceblue: "#f0f8ff",
    antiquewhite: "#faebd7",
    aqua: "#00ffff",
    aquamarine: "#7fffd4",
    azure: "#f0ffff",
    beige: "#f5f5dc",
    bisque: "#ffe4c4",
    black: "#000000",
    blanchedalmond: "#ffebcd",
    blue: "#0000ff",
    blueviolet: "#8a2be2",
    brown: "#a52a2a",
    burlywood: "#deb887",
    cadetblue: "#5f9ea0",
    chartreuse: "#7fff00",
    chocolate: "#d2691e",
    coral: "#ff7f50",
    cornflowerblue: "#6495ed",
    cornsilk: "#fff8dc",
    crimson: "#dc143c",
    cyan: "#00ffff",
    darkblue: "#00008b",
    darkcyan: "#008b8b",
    darkgoldenrod: "#b8860b",
    darkgray: "#a9a9a9",
    darkgrey: "#a9a9a9",
    darkgreen: "#006400",
    darkkhaki: "#bdb76b",
    darkmagenta: "#8b008b",
    darkolivegreen: "#556b2f",
    darkorange: "#ff8c00",
    darkorchid: "#9932cc",
    darkred: "#8b0000",
    darksalmon: "#e9967a",
    darkseagreen: "#8fbc8f",
    darkslateblue: "#483d8b",
    darkslategray: "#2f4f4f",
    darkslategrey: "#2f4f4f",
    darkturquoise: "#00ced1",
    darkviolet: "#9400d3",
    deeppink: "#ff1493",
    deepskyblue: "#00bfff",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1e90ff",
    firebrick: "#b22222",
    floralwhite: "#fffaf0",
    forestgreen: "#228b22",
    fuchsia: "#ff00ff",
    gainsboro: "#dcdcdc",
    ghostwhite: "#f8f8ff",
    gold: "#ffd700",
    goldenrod: "#daa520",
    gray: "#808080",
    grey: "#808080",
    green: "#008000",
    greenyellow: "#adff2f",
    honeydew: "#f0fff0",
    hotpink: "#ff69b4",
    indianred: "#cd5c5c",
    indigo: "#4b0082",
    ivory: "#fffff0",
    khaki: "#f0e68c",
    lavender: "#e6e6fa",
    lavenderblush: "#fff0f5",
    lawngreen: "#7cfc00",
    lemonchiffon: "#fffacd",
    lightblue: "#add8e6",
    lightcoral: "#f08080",
    lightcyan: "#e0ffff",
    lightgoldenrodyellow: "#fafad2",
    lightgray: "#d3d3d3",
    lightgrey: "#d3d3d3",
    lightgreen: "#90ee90",
    lightpink: "#ffb6c1",
    lightsalmon: "#ffa07a",
    lightseagreen: "#20b2aa",
    lightskyblue: "#87cefa",
    lightslategray: "#778899",
    lightslategrey: "#778899",
    lightsteelblue: "#b0c4de",
    lightyellow: "#ffffe0",
    lime: "#00ff00",
    limegreen: "#32cd32",
    linen: "#faf0e6",
    magenta: "#ff00ff",
    maroon: "#800000",
    mediumaquamarine: "#66cdaa",
    mediumblue: "#0000cd",
    mediumorchid: "#ba55d3",
    mediumpurple: "#9370db",
    mediumseagreen: "#3cb371",
    mediumslateblue: "#7b68ee",
    mediumspringgreen: "#00fa9a",
    mediumturquoise: "#48d1cc",
    mediumvioletred: "#c71585",
    midnightblue: "#191970",
    mintcream: "#f5fffa",
    mistyrose: "#ffe4e1",
    moccasin: "#ffe4b5",
    navajowhite: "#ffdead",
    navy: "#000080",
    oldlace: "#fdf5e6",
    olive: "#808000",
    olivedrab: "#6b8e23",
    orange: "#ffa500",
    orangered: "#ff4500",
    orchid: "#da70d6",
    palegoldenrod: "#eee8aa",
    palegreen: "#98fb98",
    paleturquoise: "#afeeee",
    palevioletred: "#db7093",
    papayawhip: "#ffefd5",
    peachpuff: "#ffdab9",
    peru: "#cd853f",
    pink: "#ffc0cb",
    plum: "#dda0dd",
    powderblue: "#b0e0e6",
    purple: "#800080",
    rebeccapurple: "#663399",
    red: "#ff0000",
    rosybrown: "#bc8f8f",
    royalblue: "#4169e1",
    saddlebrown: "#8b4513",
    salmon: "#fa8072",
    sandybrown: "#f4a460",
    seagreen: "#2e8b57",
    seashell: "#fff5ee",
    sienna: "#a0522d",
    silver: "#c0c0c0",
    skyblue: "#87ceeb",
    slateblue: "#6a5acd",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#fffafa",
    springgreen: "#00ff7f",
    steelblue: "#4682b4",
    tan: "#d2b48c",
    teal: "#008080",
    thistle: "#d8bfd8",
    tomato: "#ff6347",
    turquoise: "#40e0d0",
    violet: "#ee82ee",
    wheat: "#f5deb3",
    white: "#ffffff",
    whitesmoke: "#f5f5f5",
    yellow: "#ffff00",
    yellowgreen: "#9acd32"
};

/***/ }),
/* 132 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _bridge = __webpack_require__(2);

var _bridge2 = _interopRequireDefault(_bridge);

var _EventEmitter = __webpack_require__(6);

var _EventEmitter2 = _interopRequireDefault(_EventEmitter);

var _configFlags = __webpack_require__(7);

var _configFlags2 = _interopRequireDefault(_configFlags);

var _utils = __webpack_require__(0);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//1-15 绑定AppEnterForeground与AppEnterBackground

var eventEmitter = new _EventEmitter2.default();
_bridge2.default.onMethod("onAppEnterForeground", function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  eventEmitter.emit("onAppEnterForeground", params);
});
_bridge2.default.onMethod("onAppEnterBackground", function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  eventEmitter.emit("onAppEnterBackground", params);
});
_bridge2.default.onMethod("onAppRunningStatusChange", function () {
  var params = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
  _utils2.default.defaultRunningStatus = params.status;
  eventEmitter.emit("onAppRunningStatusChange", params);
});

var onAppEnterForeground = function onAppEnterForeground(fn) {
  var self = this;
  "function" == typeof fn && setTimeout(fn, 0);
  eventEmitter.on("onAppEnterForeground", function (params) {
    _bridge2.default.publish("onAppEnterForeground", params), self.appStatus = _configFlags2.default.AppStatus.FORE_GROUND, "function" == typeof fn && fn(params);
  });
};

var onAppEnterBackground = function onAppEnterBackground(fn) {
  var self = this;
  eventEmitter.on("onAppEnterBackground", function (params) {
    params = params || {};
    _bridge2.default.publish("onAppEnterBackground", params);
    "hide" === params.mode ? self.appStatus = _configFlags2.default.AppStatus.LOCK : self.appStatus = _configFlags2.default.AppStatus.BACK_GROUND, "close" === params.mode ? self.hanged = !1 : "hang" === params.mode && (self.hanged = !0), "function" == typeof fn && fn(params);
  });
};
var onAppRunningStatusChange = function onAppRunningStatusChange(fn) {
  eventEmitter.on("onAppRunningStatusChange", function (params) {
    "function" == typeof fn && fn(params);
  });
};

exports.default = {
  onAppEnterForeground: onAppEnterForeground,
  onAppEnterBackground: onAppEnterBackground,
  onAppRunningStatusChange: onAppRunningStatusChange
};

/***/ }),
/* 133 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


if ("undefined" == typeof navigator) {
    try {
        eval("const GeneratorFunction = Object.getPrototypeOf(function *() {}).constructor; const canvas = new GeneratorFunction('', 'console.log(0)'); canvas().__proto__.__proto__.next = () => {};");
    } catch (e) {}
}

/***/ }),
/* 134 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

// rewrite Function adn SetTimeout setInterval

(function (exports) {

    __webpack_require__(2);
    /*
        if ("undefined" != typeof Function) {
            Function;
            e = {},
                Function.constructor = function () {
                },
                Function.prototype.constructor = function () {
                },
                Function = function () {
                    if (arguments.length > 0 && "return this" === arguments[arguments.length - 1])
                        return function () {
                            return e
                        }
                },
                Object.defineProperty(Function.constructor.__proto__, "apply", {
                    writable: !1,
                    configurable: !1,
                    value: Function.prototype.constructor.apply
                })
        }
    */
    // "undefined" != typeof eval && (eval = void 0),
    "undefined" != typeof navigator && !function () {
        var originalSetTimeOut = setTimeout;
        window.setTimeout = function (fn, timer) {
            if ("function" != typeof fn) {
                throw new TypeError("setTimetout expects a function as first argument but got " + (typeof fn === "undefined" ? "undefined" : _typeof(fn)) + ".");
            }
            var callback = Reporter.surroundThirdByTryCatch(fn, "at setTimeout callback function");
            return originalSetTimeOut(callback, timer);
        };
        var originalSetInterval = setInterval;
        window.setInterval = function (fn, timer) {
            if ("function" != typeof fn) {
                throw new TypeError("setInterval expects a function as first argument but got " + (typeof fn === "undefined" ? "undefined" : _typeof(fn)) + ".");
            }
            Reporter.surroundThirdByTryCatch(fn, "at setInterval callback function");
            return originalSetInterval(fn, timer);
        };
    }();
}).call(exports, function () {
    return this;
}());

/***/ }),
/* 135 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _bridge = __webpack_require__(2);

var _bridge2 = _interopRequireDefault(_bridge);

var _utils = __webpack_require__(0);

var _utils2 = _interopRequireDefault(_utils);

var _configFlags = __webpack_require__(7);

var _configFlags2 = _interopRequireDefault(_configFlags);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

"undefined" != typeof __wxConfig__ && __wxConfig__.debug && "devtools" !== _utils2.default.getPlatform() && !function () {
    var logQueue = [],
        viewIds = [],
        consoleMethods = ["log", "warn", "error", "info", "debug"];
    consoleMethods.forEach(function (key) {
        var consoleMethod = console[key];
        console[key] = function () {
            logQueue.length > _configFlags2.default.LOG_LIMIT && logQueue.shift();
            var logArr = Array.prototype.slice.call(arguments);

            logQueue.push({
                method: key,
                log: logArr
            });

            consoleMethod.apply(console, arguments), viewIds.length > 0 && _bridge2.default.publish(key, { log: logArr }, viewIds);
        };
    });
    _bridge2.default.subscribe("DOMContentLoaded", function (n, viewId) {
        viewIds.push(viewId);
        _bridge2.default.publish("initLogs", { logs: logQueue }, [viewId]);
    });
}(), "undefined" == typeof console.group && (console.group = function () {}), "undefined" == typeof console.groupEnd && (console.groupEnd = function () {}); //1-11 线上针对debug相关函数做处理

/***/ }),
/* 136 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _pageInit = __webpack_require__(34);

var _pageInit2 = _interopRequireDefault(_pageInit);

var _initApp = __webpack_require__(144);

var _initApp2 = _interopRequireDefault(_initApp);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// 小程序service 接口api 导出
window.Page = _pageInit2.default.pageHolder;
window.App = _initApp2.default.appHolder;
window.getApp = _initApp2.default.getApp;
window.getCurrentPages = _pageInit2.default.getCurrentPages;

/***/ }),
/* 137 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _utils = __webpack_require__(8);

var _utils2 = _interopRequireDefault(_utils);

var _parsePath = __webpack_require__(138);

var parsePath = _interopRequireWildcard(_parsePath);

var _toAppView = __webpack_require__(139);

var _toAppView2 = _interopRequireDefault(_toAppView);

var _iteratorHandle = __webpack_require__(140);

var _iteratorHandle2 = _interopRequireDefault(_iteratorHandle);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var sysEventKeys = ["onLoad", "onReady", "onShow", "onRouteEnd", "onHide", "onUnload"];
var isSysAttr = function isSysAttr(key) {
    //校验e是否为系统事件或属性
    for (var i = 0; i < sysEventKeys.length; ++i) {
        if (sysEventKeys[i] === key) {
            return true;
        }
    }
    return "data" === key;
};
var baseAttrs = ["__wxWebviewId__", "__route__"];

var isBaseAttr = function isBaseAttr(name) {
    return baseAttrs.indexOf(name) !== -1;
};

var parsePage = function () {
    function parsePage() {
        _classCallCheck(this, parsePage);

        var pageObj = arguments.length <= 0 || void 0 === arguments[0] ? {} : arguments[0],
            curPage = this,
            webviewId = arguments[1],
            routePath = arguments[2];

        var pageBaseAttr = {
            __wxWebviewId__: webviewId,
            __route__: routePath
        };
        baseAttrs.forEach(function (key) {
            curPage.__defineSetter__(key, function () {
                _utils2.default.warn("关键字保护", "should not change the protected attribute " + key);
            });
            curPage.__defineGetter__(key, function () {
                return pageBaseAttr[key];
            });
        });
        pageObj.data = pageObj.data || {};
        _utils2.default.isPlainObject(pageObj.data) || _utils2.default.error("Page data error", "data must be an object, your data is " + JSON.stringify(pageObj.data));
        this.data = JSON.parse(JSON.stringify(pageObj.data));
        sysEventKeys.forEach(function (eventName) {
            //定义页面事件
            curPage[eventName] = function () {
                var eventFun = (pageObj[eventName] || _utils2.default.noop).bind(this),
                    res;
                _utils2.default.info(this.__route__ + ": " + eventName + " have been invoked");
                try {
                    var startTime = Date.now();
                    res = eventFun.apply(this, arguments);
                    var runTime = Date.now() - startTime;
                    runTime > 1e3 && Reporter.slowReport({
                        key: "pageInvoke",
                        cost: runTime,
                        extend: 'at "' + this.__route__ + '" page lifeCycleMethod ' + eventName + " function"
                    });
                } catch (err) {
                    Reporter.thirdErrorReport({
                        error: err,
                        extend: 'at "' + this.__route__ + '" page lifeCycleMethod ' + eventName + " function"
                    });
                }
                return res;
            }.bind(curPage);
        });
        var copyPageObjByKey = function copyPageObjByKey(attrName) {
            //定义页面其它方法与属性
            isBaseAttr(attrName) ? _utils2.default.warn("关键字保护", "Page's " + attrName + " is write-protected") : isSysAttr(attrName) || ("Function" === _utils2.default.getDataType(pageObj[attrName]) ? curPage[attrName] = function () {
                var res;
                try {
                    var startTime = Date.now();
                    res = pageObj[attrName].apply(this, arguments);
                    var runTime = Date.now() - startTime;
                    runTime > 1e3 && Reporter.slowReport({
                        key: "pageInvoke",
                        cost: runTime,
                        extend: "at " + this.__route__ + " page " + attrName + " function"
                    });
                } catch (err) {
                    Reporter.thirdErrorReport({
                        error: err,
                        extend: 'at "' + this.__route__ + '" page ' + attrName + " function"
                    });
                }
                return res;
            }.bind(curPage) : curPage[attrName] = (0, _iteratorHandle2.default)(pageObj[attrName]));
        };
        for (var key in pageObj) {
            copyPageObjByKey(key);
        }
        "function" == typeof pageObj.onShareAppMessage && ServiceJSBridge.invoke("showShareMenu", {}, _utils2.default.info);
    }

    _createClass(parsePage, [{
        key: 'update',
        value: function update() {
            _utils2.default.warn("将被废弃", "Page.update is deprecated, setData updates the view implicitly. [It will be removed in 2016.11]");
        }
    }, {
        key: 'forceUpdate',
        value: function forceUpdate() {
            _utils2.default.warn("将被废弃", "Page.forceUpdate is deprecated, setData updates the view implicitly. [It will be removed in 2016.11]");
        }
    }, {
        key: 'setData',
        value: function setData(dataObj) {
            try {
                var type = _utils2.default.getDataType(dataObj);
                "Object" !== type && _utils2.default.error("类型错误", "setData accepts an Object rather than some " + type);
                for (var key in dataObj) {
                    var curValue = parsePath.getObjectByPath(this.data, key),
                        curObj = curValue.obj,
                        curKey = curValue.key;
                    curObj && (curObj[curKey] = (0, _iteratorHandle2.default)(dataObj[key]));
                }
                _toAppView2.default.emit(dataObj, this.__wxWebviewId__);
            } catch (e) {
                _utils2.default.errorReport(e);
            }
        }
    }]);

    return parsePage;
}();

exports.default = parsePage;

/***/ }),
/* 138 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.parsePath = parsePath;
exports.getObjectByPath = getObjectByPath;

var _utils = __webpack_require__(8);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function parsePath(pathStr) {
    //解析data path
    for (var length = pathStr.length, paths = [], key = "", arrKey = 0, hasNum = false, arrStartFlag = false, index = 0; index < length; index++) {
        var curStr = pathStr[index];
        if ("\\" === curStr) {
            index + 1 < length && ("." === pathStr[index + 1] || "[" === pathStr[index + 1] || "]" === pathStr[index + 1]) ? (key += pathStr[index + 1], index++) : key += "\\";
        } else if ("." === curStr) {
            key && (paths.push(key), key = "");
        } else if ("[" === curStr) {
            if (key && (paths.push(key), key = ""), 0 === paths.length) {
                throw _utils2.default.error("数据路径错误", "Path can not start with []: " + pathStr);
                new _utils2.default.AppServiceEngineKnownError("Path can not start with []: " + pathStr);
            }
            arrStartFlag = true;
            hasNum = false;
        } else if ("]" === curStr) {
            if (!hasNum) {
                throw _utils2.default.error("数据路径错误", "Must have number in []: " + pathStr);
                new _utils2.default.AppServiceEngineKnownError("Must have number in []: " + pathStr);
            }
            arrStartFlag = false;
            paths.push(arrKey);
            arrKey = 0;
        } else if (arrStartFlag) {
            if (curStr < "0" || curStr > "9") {
                throw _utils2.default.error("数据路径错误", "Only number 0-9 could inside []: " + pathStr);
                new _utils2.default.AppServiceEngineKnownError("Only number 0-9 could inside []: " + pathStr);
            }
            hasNum = true;
            arrKey = 10 * arrKey + curStr.charCodeAt(0) - 48;
        } else {
            key += curStr;
        }
    }
    if (key && paths.push(key), 0 === paths.length) {
        throw _utils2.default.error("数据路径错误", "Path can not be empty");
        new _utils2.default.AppServiceEngineKnownError("Path can not be empty");
    }
    return paths;
}
function getObjectByPath(data, pathString) {
    var paths = parsePath(pathString),
        obj,
        curKey,
        curData = data;
    for (var index = 0; index < paths.length; index++) {
        Number(paths[index]) === paths[index] && paths[index] % 1 === 0 ? //isint
        Array.isArray(curData) || (curData = []) : _utils2.default.isPlainObject(curData) || (curData = {});
        curKey = paths[index]; //key
        obj = curData; //parentObj
        curData = curData[paths[index]]; //node value
    }
    return {
        obj: obj,
        key: curKey
    };
};

/***/ }),
/* 139 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _utils = __webpack_require__(8);

var _utils2 = _interopRequireDefault(_utils);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var toAppView = function () {
    function toAppView() {
        _classCallCheck(this, toAppView);
    }

    _createClass(toAppView, null, [{
        key: "emit",
        value: function emit(data, webviewId) {
            _utils2.default.publish("appDataChange", {
                data: {
                    data: data
                }
            }, [webviewId]);
        }
    }]);

    return toAppView;
}();

exports.default = toAppView;

/***/ }),
/* 140 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

var _copyUtils = __webpack_require__(141);

var _copyUtils2 = _interopRequireDefault(_copyUtils);

var _symbolHandle = __webpack_require__(142);

var _symbolHandle2 = _interopRequireDefault(_symbolHandle);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function emptyFn(e) {}
function copyHandle(data) {
    var method = arguments.length <= 1 || undefined === arguments[1] ? emptyFn : arguments[1];
    if (null === data) {
        return null;
    }
    var value = _copyUtils2.default.copyValue(data);
    if (null !== value) {
        return value;
    }
    var coll = _copyUtils2.default.copyCollection(data, method),
        newAttr = null !== coll ? coll : data,
        attrArr = [data],
        newAttrArr = [newAttr];
    return iteratorHandle(data, method, newAttr, attrArr, newAttrArr);
}
function iteratorHandle(data, method, newAttr, attrArr, newAttrArr) {
    //处理对象循环引用情况
    if (null === data) {
        return null;
    }
    var value = _copyUtils2.default.copyValue(data);
    if (null !== value) {
        return value;
    }
    var keys = _symbolHandle2.default.getKeys(data).concat(_symbolHandle2.default.getSymbols(data));
    var index, length, key, attrValue, attrValueIndex, newAttrValue, curAttrValue, tmpObj;
    for (index = 0, length = keys.length; index < length; ++index) {
        key = keys[index];
        attrValue = data[key];
        attrValueIndex = _symbolHandle2.default.indexOf(attrArr, attrValue); //确定data的子属性有没引用自身
        tmpObj = undefined;
        curAttrValue = undefined;
        newAttrValue = undefined;
        attrValueIndex === -1 ? (newAttrValue = _copyUtils2.default.copy(attrValue, method), curAttrValue = null !== newAttrValue ? newAttrValue : attrValue, null !== attrValue && /^(?:function|object)$/.test(typeof attrValue === 'undefined' ? 'undefined' : _typeof(attrValue)) && (attrArr.push(attrValue), newAttrArr.push(curAttrValue))) : tmpObj = newAttrArr[attrValueIndex];
        newAttr[key] = tmpObj || iteratorHandle(attrValue, method, curAttrValue, attrArr, newAttrArr);
    }
    return newAttr;
}

exports.default = copyHandle;

/***/ }),
/* 141 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

function copy(obj, customizerFn) {
    var res = copyValue(obj);
    return null !== res ? res : copyCollection(obj, customizerFn);
}
function copyCollection(obj, customizerFn) {
    if ("function" != typeof customizerFn) {
        throw new TypeError("customizer is must be a Function");
    }
    if ("function" == typeof obj) {
        return obj;
    }
    var typeString = toString.call(obj);
    if ("[object Array]" === typeString) {
        return [];
    }
    if ("[object Object]" === typeString && obj.constructor === Object) {
        return {};
    }
    if ("[object Date]" === typeString) {
        return new Date(obj.getTime());
    }
    if ("[object RegExp]" === typeString) {
        var toStr = String(obj),
            pos = toStr.lastIndexOf("/");
        return new RegExp(toStr.slice(1, pos), toStr.slice(pos + 1));
    }
    var res = customizerFn(obj);
    return undefined !== res ? res : null;
}
function copyValue(param) {
    var type = typeof param === "undefined" ? "undefined" : _typeof(param);
    return null !== param && "object" !== type && "function" !== type ? param : null;
}
var toString = Object.prototype.toString;
exports.default = {
    copy: copy,
    copyCollection: copyCollection,
    copyValue: copyValue
};

/***/ }),
/* 142 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

function indexOf(arr, element) {
    if ("[object Array]" !== toString.call(arr)) {
        throw new TypeError("array must be an Array");
    }
    var index = void 0,
        arrLen = void 0,
        cur = void 0;
    for (index = 0, arrLen = arr.length; index < arrLen; ++index) {
        cur = arr[index];
        if (cur === element || cur !== cur && element !== element) {
            return index;
        }
    }
    return -1;
}

var toString = Object.prototype.toString;
var getKeys = "function" == typeof Object.keys ? function (obj) {
    return Object.keys(obj);
} : function (obj) {
    var type = typeof obj === "undefined" ? "undefined" : _typeof(obj);
    if (null === obj || "function" !== type && "object" !== type) throw new TypeError("obj must be an Object");
    var res = [],
        key;
    for (key in obj) {
        Object.prototype.hasOwnProperty.call(obj, key) && res.push(key);
    }
    return res;
};
var getSymbols = "function" == typeof Symbol ? function (e) {
    return Object.getOwnPropertySymbols(e);
} : function () {
    return [];
};

exports.default = {
    getKeys: getKeys,
    getSymbols: getSymbols,
    indexOf: indexOf
};

/***/ }),
/* 143 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var DOM_READY_EVENT = "__DOMReady";
var UPDATE_APP_DATA = "__updateAppData";

exports.DOM_READY_EVENT = DOM_READY_EVENT;
exports.UPDATE_APP_DATA = UPDATE_APP_DATA;

/***/ }),
/* 144 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _utils = __webpack_require__(8);

var _utils2 = _interopRequireDefault(_utils);

var _pageInit = __webpack_require__(34);

var _pageInit2 = _interopRequireDefault(_pageInit);

var _logReport = __webpack_require__(35);

var reportRealtimeAction = _interopRequireWildcard(_logReport);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var events = ["onLaunch", "onShow", "onHide", "onUnlaunch"];

var firstRender = true;

var isSysEvent = function isSysEvent(key) {
    //判断是否为app 事件
    for (var index = 0; index < events.length; ++index) {
        if (events[index] === key) {
            return true;
        }
    }
    return false;
};
var isGetCurrentPage = function isGetCurrentPage(key) {
    return "getCurrentPage" === key;
};

var appClass = function () {
    function appClass(appObj) {
        _classCallCheck(this, appClass);

        //t:app
        var self = this;
        events.forEach(function (eventKey) {
            //给app绑定事件
            var tempFun = function tempFun() {
                var eventFun = (appObj[eventKey] || _utils2.default.noop).bind(this);
                _utils2.default.info("App: " + eventKey + " have been invoked");
                try {
                    eventFun.apply(this, arguments);
                } catch (t) {
                    Reporter.thirdErrorReport({
                        error: t,
                        extend: "App catch error in lifeCycleMethod " + eventKey + " function"
                    });
                }
            };
            self[eventKey] = tempFun.bind(self);
        });
        var bindApp = function bindApp(attrKey) {
            //给app绑定其它方法与属性
            isGetCurrentPage(attrKey) ? _utils2.default.warn("关键字保护", "App's " + attrKey + " is write-protected") : isSysEvent(attrKey) || ("[object Function]" === Object.prototype.toString.call(appObj[attrKey]) ? self[attrKey] = function () {
                var method;
                try {
                    method = appObj[attrKey].apply(this, arguments);
                } catch (t) {
                    Reporter.thirdErrorReport({
                        error: t,
                        extend: "App catch error in  " + attrKey + " function"
                    });
                }
                return method;
            }.bind(self) : self[attrKey] = appObj[attrKey]);
        };
        for (var attrKey in appObj) {
            bindApp(attrKey);
        }
        this.onError && Reporter.registerErrorListener(this.onError);
        this.onLaunch();
        reportRealtimeAction.triggerAnalytics("launch", null, '小程序启动');
        var hide = function hide() {
            //hide
            var pages = _pageInit2.default.getCurrentPages();
            pages.length && pages[pages.length - 1].onHide();
            this.onHide();
            reportRealtimeAction.triggerAnalytics("background", null, '小程序转到后台');
        };
        var show = function show() {
            //show
            this.onShow();
            if (firstRender) {
                firstRender = false;
            } else {
                var pages = _pageInit2.default.getCurrentPages();
                pages.length && (pages[pages.length - 1].onShow(), reportRealtimeAction.triggerAnalytics("foreground", null, '小程序转到前台'));
            }
        };
        wd.onAppEnterBackground(hide.bind(this));
        wd.onAppEnterForeground(show.bind(this));
    }

    _createClass(appClass, [{
        key: 'getCurrentPage',
        value: function getCurrentPage() {
            _utils2.default.warn("将被废弃", "App.getCurrentPage is deprecated, please use getCurrentPages. [It will be removed in 2016.11]");
            var currentPage = _pageInit2.default.getCurrentPage();
            if (currentPage) {
                return currentPage.page;
            }
        }
    }]);

    return appClass;
}();

var tempObj;

var appHolder = _utils2.default.surroundByTryCatch(function (appObj) {
    tempObj = new appClass(appObj);
}, "create app instance");
var getApp = function getApp() {
    return tempObj;
};

exports.default = { appHolder: appHolder, getApp: getApp };

/***/ }),
/* 145 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var statusDefineFlag = 1;
var statusRequireFlag = 2;
var moduleArr = {};

var define = function define(path, fun) {
  moduleArr[path] = {
    status: statusDefineFlag,
    factory: fun
  };
};

var getPathPrefix = function getPathPrefix(pathname) {
  // 返回path
  var res = pathname.match(/(.*)\/([^\/]+)?$/);
  return res && res[1] ? res[1] : './';
};

var getRequireFun = function getRequireFun(pathname) {
  // e:path 返回相对e的require
  var pathPrefix = getPathPrefix(pathname);
  return function (path) {
    if (typeof path !== 'string') {
      throw new Error('require args must be a string');
    }
    var floderArr = [];
    var folders = (pathPrefix + '/' + path).split('/');
    var pathLength = folders.length;
    for (var i = 0; i < pathLength; ++i) {
      var folder = folders[i];
      if (folder != '' && folder != '.') {
        if (folder == '..') {
          if (floderArr.length == 0) {
            throw new Error("can't find module : " + path);
          }
          floderArr.pop();
        } else {
          i + 1 < pathLength && folders[i + 1] == '..' ? i++ : floderArr.push(folder);
        }
      }
    }
    try {
      var pathname = floderArr.join('/');
      if (!/\.js$/.test(pathname)) {
        pathname += '.js';
      }
      return _require(pathname);
    } catch (e) {
      throw e;
    }
  };
};
var _require = function _require(path) {
  // exports o
  if (typeof path !== 'string') {
    throw new Error('require args must be a string');
  }
  var moduleObj = moduleArr[path];
  if (!moduleObj) throw new Error('module "' + path + '" is not defined');
  if (moduleObj.status === statusDefineFlag) {
    var factoryFun = moduleObj.factory;
    var module = {
      exports: {}
    };
    var exports;
    if (factoryFun) {
      exports = factoryFun(getRequireFun(path), module, module.exports);
    }

    moduleObj.exports = module.exports || exports;
    moduleObj.status = statusRequireFlag;
  }
  return moduleObj.exports;
};

exports.define = define;
exports.require = _require;

window.define = define;
window.require = _require;

wd.version = {
  updateTime: '2017.1.13 16:51:56',
  info: '',
  version: 32
  // 导出全局方法

};window.__WAServiceEndTime__ = Date.now();

/***/ })
/******/ ]);